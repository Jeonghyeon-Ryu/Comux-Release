# comux PowerShell Integration
# Injected automatically by comux

$env:COMUX = "1"

# UTF-8 I/O so multi-byte input (Korean, Japanese, Chinese, emoji, accents)
# survives the conpty round-trip cleanly.
try {
    [Console]::InputEncoding = [System.Text.UTF8Encoding]::new()
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
    $OutputEncoding = [System.Text.UTF8Encoding]::new()
    $PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'
} catch {}

# comux CLI shortcut — Claude Code and users can just type: comux browser open <url>
function comux { node "$env:COMUX_CLI" @args }

# Resolve the named-pipe name (without the \\.\pipe\ prefix). comux injects the
# full pipe path via COMUX_PIPE; dev / side-by-side instances use a suffix
# (e.g. comux-dev), so we must NOT hardcode "comux" — that sends reports to the
# wrong (or a non-existent) instance and the file tree / cwd never updates.
$_comux_pipe_name = if ($env:COMUX_PIPE) { ($env:COMUX_PIPE -split '\\')[-1] } else { "comux" }

# Named pipe client helper
function Send-ComuxMessage {
    param([string]$Message)
    try {
        $pipe = New-Object System.IO.Pipes.NamedPipeClientStream(".", $_comux_pipe_name, [System.IO.Pipes.PipeDirection]::InOut)
        $pipe.Connect(1000)
        $writer = New-Object System.IO.StreamWriter($pipe)
        $writer.AutoFlush = $true
        $writer.WriteLine($Message)
        $pipe.Close()
    } catch {
        # Silently ignore pipe errors
    }
}

# Report CWD
function Report-Cwd {
    $surfaceId = $env:COMUX_SURFACE_ID
    if ($surfaceId) {
        Send-ComuxMessage "report_pwd $surfaceId $PWD"
    }
}

# Report git branch — ASYNC so the prompt never blocks on git. `git status
# --porcelain` walks the whole worktree (100ms-to-seconds on big repos); running it
# synchronously in the prompt delayed EVERY prompt, including the first one at
# startup (the splash lifts on the first prompt). Instead we run rev-parse+status on
# a background in-process runspace (cheaper than Start-Job — no child pwsh) and
# report the result to comux over the pipe when it completes. Throttled to one check
# at a time so hammering Enter can't pile up runspaces. Matches the old behavior
# (re-checks every prompt so dirty refreshes) — only the blocking is removed.
$script:_comux_git_ps = $null
$script:_comux_git_async = $null
$script:_comux_git_started = 0
function Report-GitBranch {
    $surfaceId = $env:COMUX_SURFACE_ID
    if (-not $surfaceId) { return }

    # A check in flight is either reaped (done), abandoned (wedged), or skipped.
    # Throttle to ONE at a time so a terminal can never pile up runspaces (rapid
    # Enter, resize storms, etc.). Note: switching comux tabs does NOT re-run the
    # prompt, so tab-hopping generates no git checks at all — only real prompts do.
    if ($script:_comux_git_ps) {
        $done = $script:_comux_git_async -and $script:_comux_git_async.IsCompleted
        # Guard: if git wedges (e.g. a stalled network-mounted repo) it must not jam
        # the throttle forever — abandon it after 10s so the indicator self-recovers.
        $wedged = (-not $done) -and (([Environment]::TickCount - $script:_comux_git_started) -gt 10000)
        if ($done -or $wedged) {
            if ($done) { try { $script:_comux_git_ps.EndInvoke($script:_comux_git_async) } catch {} }
            else       { try { $script:_comux_git_ps.Stop() } catch {} }
            try { $script:_comux_git_ps.Runspace.Dispose(); $script:_comux_git_ps.Dispose() } catch {}
            $script:_comux_git_ps = $null
            $script:_comux_git_async = $null
        } else {
            return  # still running within budget → skip this prompt (throttle)
        }
    }

    try {
        $ps = [PowerShell]::Create()
        $null = $ps.AddScript({
            param($surfaceId, $cwd, $pipeName)
            try {
                $branch = git -C $cwd rev-parse --abbrev-ref HEAD 2>$null
                if ($LASTEXITCODE -eq 0 -and $branch) {
                    $status = git -C $cwd status --porcelain 2>$null
                    $dirty = if ($status) { "dirty" } else { "" }
                    $msg = "report_git_branch $surfaceId $branch $dirty"
                } else {
                    $msg = "clear_git_branch $surfaceId"
                }
            } catch { $msg = "clear_git_branch $surfaceId" }
            try {
                $pipe = New-Object System.IO.Pipes.NamedPipeClientStream(".", $pipeName, [System.IO.Pipes.PipeDirection]::InOut)
                $pipe.Connect(1000)
                $writer = New-Object System.IO.StreamWriter($pipe)
                $writer.AutoFlush = $true
                $writer.WriteLine($msg)
                $pipe.Close()
            } catch {}
        })
        $null = $ps.AddArgument($surfaceId).AddArgument("$PWD").AddArgument($_comux_pipe_name)
        $script:_comux_git_ps = $ps
        $script:_comux_git_started = [Environment]::TickCount
        $script:_comux_git_async = $ps.BeginInvoke()
    } catch {
        # Runspace creation failed — skip the git report this prompt (never break it).
        if ($script:_comux_git_ps) { try { $script:_comux_git_ps.Dispose() } catch {} }
        $script:_comux_git_ps = $null
        $script:_comux_git_async = $null
    }
}

# Report shell state
function Report-ShellState {
    param([string]$State)
    $surfaceId = $env:COMUX_SURFACE_ID
    if ($surfaceId) {
        Send-ComuxMessage "report_shell_state $surfaceId $State"
    }
}

# Report "running" when user executes a command (pre-execution hook)
if (Get-Module -Name PSReadLine -ErrorAction SilentlyContinue) {
    Set-PSReadLineKeyHandler -Key Enter -ScriptBlock {
        # Report running state before the command executes
        Report-ShellState "running"
        # Accept the line (execute the command)
        [Microsoft.PowerShell.PSConsoleReadLine]::AcceptLine()
    }
}

# Override prompt (fires AFTER command completes)
$_comux_original_prompt = $function:prompt
function prompt {
    Report-Cwd
    Report-GitBranch
    # Detect an interrupted command (Ctrl+C → -1073741510 = 0xC000013A, or 130).
    #
    # $LASTEXITCODE is only written by NATIVE commands and keeps its old value
    # afterwards, so a single Ctrl+C used to pin the surface to "interrupted" on
    # EVERY later prompt until some other native command happened to run — a dot
    # that never went away. Only report the interrupt when the code is new; an
    # unchanged code means we already reported it and the shell is idle now.
    $_comux_exit = $LASTEXITCODE
    if (($_comux_exit -eq -1073741510 -or $_comux_exit -eq 130) -and
        $_comux_exit -ne $script:_comux_last_exit) {
        Report-ShellState "interrupted"
    } else {
        Report-ShellState "idle"
    }
    $script:_comux_last_exit = $_comux_exit
    Send-ComuxMessage "ports_kick $env:COMUX_SURFACE_ID"

    # Call original prompt or default
    if ($_comux_original_prompt) {
        & $_comux_original_prompt
    } else {
        "PS $($executionContext.SessionState.Path.CurrentLocation)$('>' * ($nestedPromptLevel + 1)) "
    }
}

# PR polling background job (every 45 seconds), started LAZILY the first time the
# shell goes idle — i.e. AFTER the first prompt is on screen. Start-Job spawns a
# child PowerShell runspace (~0.3-1s cold); running it during script sourcing put
# that cost squarely on the path to the first prompt (and thus the startup splash).
# Deferring it is visually free: the loop sleeps 45s before its first report, so a
# ~1s-later start is imperceptible. -MaxTriggerCount 1 = one-shot, auto-unregisters.
# The Action is self-contained (reads $env, not sourcing-scope vars) so it works in
# the event subscriber's scope.
$null = Register-EngineEvent -SourceIdentifier PowerShell.OnIdle -MaxTriggerCount 1 -Action {
    $surfaceId = $env:COMUX_SURFACE_ID
    if (-not $surfaceId) { return }
    $pipeName = if ($env:COMUX_PIPE) { ($env:COMUX_PIPE -split '\\')[-1] } else { "comux" }
    # The job below never returns, so it has to be owned: give it a stable name,
    # refuse to start a second one, and tear it down when the shell exits.
    # Re-sourcing the profile (nested shells, `. $PROFILE`) otherwise stacked
    # another immortal child pwsh — each polling `gh pr view` every 45s forever.
    $jobName = "comux-pr-$surfaceId"
    if (Get-Job -Name $jobName -ErrorAction SilentlyContinue) { return }
    $null = Register-EngineEvent -SourceIdentifier PowerShell.Exiting -SupportEvent -Action {
        Get-Job -Name "comux-pr-$env:COMUX_SURFACE_ID" -ErrorAction SilentlyContinue |
            Stop-Job -PassThru -ErrorAction SilentlyContinue |
            Remove-Job -Force -ErrorAction SilentlyContinue
    }
    Start-Job -Name $jobName -ScriptBlock {
        param($surfaceId, $pipeName)
        while ($true) {
            Start-Sleep -Seconds 45
            try {
                $prJson = gh pr view --json number,state,title 2>$null
                if ($LASTEXITCODE -eq 0 -and $prJson) {
                    $pr = $prJson | ConvertFrom-Json
                    $pipe = New-Object System.IO.Pipes.NamedPipeClientStream(".", $pipeName, [System.IO.Pipes.PipeDirection]::InOut)
                    $pipe.Connect(1000)
                    $writer = New-Object System.IO.StreamWriter($pipe)
                    $writer.AutoFlush = $true
                    $writer.WriteLine("report_pr $surfaceId $($pr.number) $($pr.state) $($pr.title)")
                    $pipe.Close()
                }
            } catch { }
        }
    } -ArgumentList $surfaceId, $pipeName | Out-Null
}

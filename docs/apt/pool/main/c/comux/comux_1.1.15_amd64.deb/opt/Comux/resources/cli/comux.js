#!/usr/bin/env node
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const net_1 = __importDefault(require("net"));
const http_1 = __importDefault(require("http"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const os_1 = __importDefault(require("os"));
const child_process_1 = require("child_process");
const app_version_1 = require("../shared/app-version");
const systemd_unit_1 = require("../shared/systemd-unit");
const install_method_1 = require("../shared/install-method");
const update_check_1 = require("../shared/update-check");
const rest_config_1 = require("../shared/rest-config");
// Respect COMUX_PIPE when set (e.g. by a parent comux running with COMUX_INSTANCE),
// so the CLI talks to the same instance that spawned the shell.
//
// Outside a comux terminal COMUX_PIPE is unset and we must find the endpoint
// ourselves. Windows has one well-known named pipe. POSIX has two possible
// sockets — the headless comuxd daemon and an Electron GUI — so probe for one
// that exists, and fall back to the daemon path for the "not running" message.
function resolvePipePath() {
    if (process.env.COMUX_PIPE)
        return process.env.COMUX_PIPE;
    const sfx = (v) => (v && v.trim() ? `-${v.trim()}` : '');
    if (process.platform === 'win32')
        return `\\\\.\\pipe\\comux${sfx(process.env.COMUX_INSTANCE)}`;
    const base = process.env.XDG_RUNTIME_DIR || os_1.default.tmpdir();
    const candidates = [
        path_1.default.join(base, `comuxd${sfx(process.env.COMUXD_INSTANCE)}.sock`), // headless daemon
        path_1.default.join(base, `comux${sfx(process.env.COMUX_INSTANCE)}.sock`), // Electron GUI
    ];
    const live = candidates.find((p) => {
        try {
            return fs_1.default.statSync(p).isSocket();
        }
        catch {
            return false;
        }
    });
    return live ?? candidates[0];
}
const PIPE_PATH = resolvePipePath();
/** Read all of stdin. Resolves to '' when stdin is a TTY (nothing piped in). */
function readStdin() {
    return new Promise((resolve) => {
        if (process.stdin.isTTY) {
            resolve('');
            return;
        }
        let data = '';
        process.stdin.setEncoding('utf8');
        process.stdin.on('data', (c) => { data += c; });
        process.stdin.on('end', () => resolve(data));
        process.stdin.on('error', () => resolve(data));
        // A caller that opens the pipe but never closes it must not wedge the CLI.
        setTimeout(() => resolve(data), 2000).unref?.();
    });
}
function sendV1(command) {
    return new Promise((resolve, reject) => {
        const client = net_1.default.connect({ path: PIPE_PATH }, () => {
            client.write(command + '\n');
        });
        let data = '';
        client.on('data', (chunk) => { data += chunk.toString(); });
        client.on('end', () => resolve(data.trim()));
        client.on('error', (err) => reject(err));
        setTimeout(() => { client.end(); resolve(data.trim()); }, 5000);
    });
}
// 5s suits every call that only touches in-memory state. A git checkout does
// not — `worktree.create` on a large repo, or a remove that waits out a dying
// shell's lock on its folder — so those callers pass their own budget.
//
// The timer is cleared once the call settles. It used to stay armed, and as a
// live timer it held the process open: EVERY command printed its answer and
// then sat for the rest of the 5s before exiting — which the orchestrator,
// calling `comux` dozens of times per wave, paid in full each time.
function sendV2(method, params = {}, timeoutMs = 5000) {
    return new Promise((resolve, reject) => {
        let settled = false;
        const settle = (fn) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            fn();
        };
        const client = net_1.default.connect({ path: PIPE_PATH }, () => {
            // COMUX_PIPE_TOKEN is injected by comuxd into its shells; harmless (ignored)
            // against a server without auth (GUI / default daemon).
            const request = JSON.stringify({ method, params, id: 1, token: process.env.COMUX_PIPE_TOKEN });
            client.write(request + '\n');
        });
        let data = '';
        client.on('data', (chunk) => {
            data += chunk.toString();
            if (data.includes('\n')) {
                client.end();
                try {
                    const response = JSON.parse(data.trim());
                    if (response.error)
                        settle(() => reject(new Error(response.error.message)));
                    else
                        settle(() => resolve(response.result));
                }
                catch {
                    settle(() => resolve(data.trim()));
                }
            }
        });
        client.on('error', (err) => settle(() => reject(err)));
        client.on('close', () => settle(() => reject(new Error('comux closed the connection without answering'))));
        const timer = setTimeout(() => { client.end(); settle(() => reject(new Error('timeout'))); }, timeoutMs);
    });
}
// Simple flag helpers shared across commands.
function getFlag(args, name) {
    const i = args.indexOf(name);
    if (i < 0 || i === args.length - 1)
        return undefined;
    return args[i + 1];
}
function stripFlag(args, name) {
    const i = args.indexOf(name);
    if (i < 0)
        return args;
    const copy = args.slice();
    copy.splice(i, i === args.length - 1 ? 1 : 2);
    return copy;
}
/**
 * The surface this command is running inside, as a param hint.
 *
 * comux sets COMUX_SURFACE_ID in every shell it spawns, but only send/send-key/
 * read-screen/`layout grid` ever used it. Without it the hosts had nothing to
 * aim at, so `split`/`new-surface` targeted pane 1 and `close-pane` targeted
 * nothing at all. Spread it into the params of any verb that acts on "a pane" —
 * an explicit id in the same params still wins host-side.
 */
function callerSurface() {
    const id = process.env.COMUX_SURFACE_ID;
    return id ? { surfaceId: id } : {};
}
/** Same, for verbs whose target IS the surface. Exits with usage when neither. */
function callerSurfaceId(usage) {
    const id = process.env.COMUX_SURFACE_ID;
    if (!id) {
        console.error(`${usage} — pass a surface id, or run inside a comux pane. See: comux ls`);
        process.exit(1);
    }
    return id;
}
/**
 * Where the TUI client lives, across every way comux is installed.
 *
 * electron-builder copies `dist/cli` and `dist/shared` OUT of the asar but not
 * `dist/tui`, so on a deb/AppImage the CLI runs from resources/cli and the old
 * unconditional `<dirname>/../tui/tui-client.js` pointed at a file that is only
 * inside the archive — `comux attach` died with MODULE_NOT_FOUND on exactly the
 * installs where `comux service install` is supported. Same resolution order as
 * shared/systemd-unit.ts uses for comuxd.js; Electron's asar-aware fs (the CLI
 * runs under ELECTRON_RUN_AS_NODE there) makes the in-archive path loadable.
 */
function resolveTuiEntry() {
    const candidates = [
        path_1.default.join(__dirname, '..', 'tui', 'tui-client.js'), // dev + linux bundle
        path_1.default.join(__dirname, '..', 'app.asar', 'dist', 'tui', 'tui-client.js'), // deb/AppImage: resources/cli → resources/app.asar
        path_1.default.join(process.resourcesPath || '', 'app.asar', 'dist', 'tui', 'tui-client.js'),
    ];
    for (const c of candidates) {
        try {
            if (fs_1.default.existsSync(c))
                return c;
        }
        catch { /* asar probing can throw on odd layouts */ }
    }
    return null;
}
/** A required positional argument, or a usage error (never a silent no-op). */
function requireArg(value, usage, discover) {
    if (!value) {
        console.error(`Usage: ${usage}${discover ? ` — list them with: ${discover}` : ''}`);
        process.exit(1);
    }
    return value;
}
/** Render `comux ls` as a human-friendly tree: workspace › pane › terminal. */
function printLsTable(workspaces, surfaces) {
    if (surfaces.length === 0) {
        console.log('comux: no terminals — the daemon is empty. Start one with: comux new-workspace');
        return;
    }
    const byWs = new Map();
    for (const s of surfaces) {
        if (!byWs.has(s.workspaceId))
            byWs.set(s.workspaceId, []);
        byWs.get(s.workspaceId).push(s);
    }
    // Prefer workspace.list order/metadata; fall back to what the surfaces carry.
    const order = workspaces.length
        ? workspaces
        : [...byWs.keys()].map((id) => ({ id, title: byWs.get(id)[0].workspaceTitle || id, isActive: byWs.get(id)[0].workspaceActive }));
    const terms = surfaces.filter((s) => s.type === 'terminal').length;
    console.log(`comux — ${order.length} workspace(s), ${surfaces.length} surface(s) (${terms} terminal)  ·  re-attach: comux attach`);
    console.log('');
    for (const ws of order) {
        const list = byWs.get(ws.id) || [];
        const meta = [ws.cwd, ws.shell ? `(${ws.shell})` : ''].filter(Boolean).join('  ');
        console.log(`${ws.isActive ? '●' : '○'} ${ws.title}${meta ? '   ' + meta : ''}`);
        const paneIdx = new Map();
        list.forEach((s, i) => {
            if (!paneIdx.has(s.paneId))
                paneIdx.set(s.paneId, paneIdx.size + 1);
            const branch = i === list.length - 1 ? '└─' : '├─';
            const active = s.activeTab ? '*' : ' ';
            console.log(`   ${branch} ${active} ${s.type.padEnd(8)} ${s.id}  [pane ${paneIdx.get(s.paneId)}]`);
        });
    }
    console.log('');
    console.log('● active workspace   ○ inactive   * active tab');
}
async function main() {
    const args = process.argv.slice(2);
    const command = args[0];
    if (!command) {
        printUsage();
        process.exit(0);
    }
    // These answer from the local install and must work with no daemon running.
    if (command === 'version' || command === '--version' || command === '-v') {
        printVersion();
        return;
    }
    if (command === 'upgrade') {
        await printUpgrade();
        return;
    }
    // Local config surgery for the external REST API. Handled before the pipe
    // connection on purpose: this edits a file rather than driving a running server,
    // and `comux rest enable` is precisely what you run when there is no server yet.
    if (command === 'rest') {
        await restCommand(args.slice(1));
        return;
    }
    // Same rationale as `rest`: this writes a unit file and drives systemctl, so
    // it must work with no daemon running — installing the service is exactly
    // what you do before there is one.
    if (command === 'service') {
        await serviceCommand(args.slice(1));
        return;
    }
    try {
        switch (command) {
            // System
            case 'ping':
                console.log(await sendV1('ping'));
                break;
            // Internal: the shell-integration transport of last resort. Reads V1 report
            // lines from stdin and sends them over one connection. bash cannot write to
            // a Unix socket (or a Windows named pipe) itself, so it prefers `nc -U` /
            // `socat` and falls back to this when neither exists — which is always the
            // case on Windows. Silent by design: a shell prompt must not be able to
            // print anything, so failures are swallowed.
            case 'report': {
                const lines = await readStdin();
                const payload = lines.split('\n').map((l) => l.trim()).filter(Boolean);
                if (payload.length === 0)
                    break;
                try {
                    await sendV1(payload.join('\n'));
                }
                catch { /* comux is gone; nothing to do */ }
                break;
            }
            case 'identify':
                console.log(JSON.stringify(await sendV2('system.identify'), null, 2));
                break;
            case 'capabilities':
                console.log(JSON.stringify(await sendV2('system.capabilities'), null, 2));
                break;
            // Attach a full-screen TUI multiplexer to a running comuxd (the SSH story:
            // `ssh -t host comux attach`). Hands the terminal to the TUI client, which
            // owns its own control+attach connections; env (COMUXD_INSTANCE/…) passes
            // through. This is the ONLY command that takes over stdio.
            case 'attach': {
                const entry = resolveTuiEntry();
                if (!entry) {
                    console.error('comux attach: the TUI client is missing from this install (looked beside the CLI and inside app.asar).');
                    process.exit(1);
                }
                const child = (0, child_process_1.spawn)(process.execPath, [entry, ...args.slice(1)], { stdio: 'inherit', env: process.env });
                child.on('exit', (code) => process.exit(code == null ? 0 : code));
                child.on('error', (e) => { console.error(`comux attach: ${e.message}`); process.exit(1); });
                return; // the child owns the terminal now — don't fall through
            }
            case 'list-windows':
                console.log(JSON.stringify(await sendV2('window.list'), null, 2));
                break;
            case 'focus-window':
                console.log(JSON.stringify(await sendV2('window.focus', { id: args[1] }), null, 2));
                break;
            // Workspace
            case 'new-workspace': {
                // --worktree <branch> is `comux worktree create <branch>` spelled the
                // way someone reaching for a new workspace would look for it.
                const wtBranch = getFlag(args, '--worktree');
                if (wtBranch) {
                    await runWorktreeCommand(['create', wtBranch, ...args.slice(1).filter((a, i, all) => a !== '--worktree' && all[i - 1] !== '--worktree')]);
                    break;
                }
                const params = {};
                for (let i = 1; i < args.length; i += 2) {
                    if (args[i] === '--title')
                        params.title = args[i + 1];
                    if (args[i] === '--shell')
                        params.shell = args[i + 1];
                    if (args[i] === '--cwd')
                        params.cwd = args[i + 1];
                }
                console.log(JSON.stringify(await sendV2('workspace.create', params), null, 2));
                break;
            }
            // These three used to be sent with `id: undefined` when called bare — the
            // form the usage text and CLAUDE.md both showed — and every host reduced
            // over nothing and answered {ok:true}. Caught here so the message names
            // the command that lists the ids.
            case 'close-workspace':
                console.log(JSON.stringify(await sendV2('workspace.close', { id: requireArg(args[1], 'comux close-workspace <workspaceId>', 'comux list-workspaces') }), null, 2));
                break;
            case 'select-workspace':
                console.log(JSON.stringify(await sendV2('workspace.select', { id: requireArg(args[1], 'comux select-workspace <workspaceId>', 'comux list-workspaces') }), null, 2));
                break;
            case 'rename-workspace':
                console.log(JSON.stringify(await sendV2('workspace.rename', {
                    id: requireArg(args[1], 'comux rename-workspace <workspaceId> <title>', 'comux list-workspaces'),
                    title: requireArg(args[2], 'comux rename-workspace <workspaceId> <title>'),
                }), null, 2));
                break;
            case 'list-workspaces':
                console.log(JSON.stringify(await sendV2('workspace.list'), null, 2));
                break;
            // Surface
            case 'new-surface': {
                const type = getFlag(args, '--type') || 'terminal';
                const colorScheme = getFlag(args, '--color-scheme');
                // callerSurface() → the new tab opens in the pane this ran from.
                console.log(JSON.stringify(await sendV2('surface.create', { type, ...callerSurface(), ...(colorScheme ? { colorScheme } : {}) }), null, 2));
                break;
            }
            case 'close-surface':
                console.log(JSON.stringify(await sendV2('surface.close', { id: args[1] || callerSurfaceId('comux close-surface [surfaceId]') }), null, 2));
                break;
            case 'focus-surface':
                console.log(JSON.stringify(await sendV2('surface.focus', { id: args[1] || callerSurfaceId('comux focus-surface [surfaceId]') }), null, 2));
                break;
            case 'ls': { // tmux-style human view: every terminal across ALL workspaces
                const [wl, sl] = await Promise.all([
                    sendV2('workspace.list'),
                    sendV2('surface.list', { all: true }),
                ]);
                const surfaces = (sl?.surfaces ?? []);
                if (args.includes('--json')) {
                    console.log(JSON.stringify({ surfaces }, null, 2));
                    break;
                }
                printLsTable(wl?.workspaces ?? [], surfaces);
                break;
            }
            case 'list-surfaces':
                console.log(JSON.stringify(await sendV2('surface.list', {
                    all: args.includes('--all'),
                    paneId: getFlag(args, '--pane'),
                    workspaceId: getFlag(args, '--workspace'),
                }), null, 2));
                break;
            // Surface: per-pane color scheme override (issue #4)
            case 'set-color-scheme': {
                // Two forms:
                //   comux set-color-scheme <scheme>            → apply to current surface
                //   comux set-color-scheme <surfaceId> <scheme> → apply to a specific surface
                let surfaceId = args[1];
                let scheme = args[2];
                if (!scheme) {
                    scheme = surfaceId;
                    surfaceId = process.env.COMUX_SURFACE_ID || '';
                }
                if (!surfaceId) {
                    console.error('No surface id. Pass one as argument or run inside a comux pane.');
                    process.exit(1);
                }
                if (!scheme) {
                    console.error('Usage: comux set-color-scheme [surfaceId] <scheme>');
                    process.exit(1);
                }
                console.log(JSON.stringify(await sendV2('surface.set_color_scheme', { surfaceId, colorScheme: scheme }), null, 2));
                break;
            }
            case 'clear-color-scheme': {
                const surfaceId = args[1] || process.env.COMUX_SURFACE_ID || '';
                if (!surfaceId) {
                    console.error('No surface id. Pass one as argument or run inside a comux pane.');
                    process.exit(1);
                }
                console.log(JSON.stringify(await sendV2('surface.set_color_scheme', { surfaceId, colorScheme: null }), null, 2));
                break;
            }
            case 'list-themes':
            case 'themes': {
                // Discovery for users writing scripts: what names are valid for --color-scheme?
                console.log(JSON.stringify(await sendV2('theme.list'), null, 2));
                break;
            }
            // User config (~/.comux/config.toml)
            case 'reload-config': {
                // Re-read the TOML dotfile and broadcast the new prefs to every window.
                console.log(JSON.stringify(await sendV2('config.reload'), null, 2));
                break;
            }
            case 'config': {
                const sub = args[1];
                if (sub === 'show' || sub === 'get') {
                    console.log(JSON.stringify(await sendV2('config.get'), null, 2));
                }
                else if (sub === 'reload') {
                    console.log(JSON.stringify(await sendV2('config.reload'), null, 2));
                }
                else if (sub === 'path') {
                    const home = process.env.USERPROFILE || process.env.HOME || '';
                    console.log(`${home}\\.comux\\config.toml`);
                }
                else {
                    console.error('Usage: comux config <show|reload|path>');
                    process.exit(1);
                }
                break;
            }
            // Pane
            case 'split': {
                const direction = args.includes('--down') ? 'down' : 'right';
                const type = getFlag(args, '--type') || 'terminal';
                const colorScheme = getFlag(args, '--color-scheme');
                // Without callerSurface() the hosts had nothing to target and split
                // pane 1 — so `comux split` in pane 3 split someone else's pane.
                console.log(JSON.stringify(await sendV2('pane.split', { direction, type, ...callerSurface(), ...(colorScheme ? { colorScheme } : {}) }), null, 2));
                break;
            }
            // "pane <sub>" verb form — mirrors the syntax from the issue example.
            case 'pane': {
                const sub = args[1];
                if (sub === 'new' || sub === 'split') {
                    const rest = args.slice(2);
                    const direction = rest.includes('--down') ? 'down' : 'right';
                    const type = getFlag(rest, '--type') || 'terminal';
                    const colorScheme = getFlag(rest, '--color-scheme');
                    console.log(JSON.stringify(await sendV2('pane.split', { direction, type, ...callerSurface(), ...(colorScheme ? { colorScheme } : {}) }), null, 2));
                }
                else if (sub === 'close') {
                    console.log(JSON.stringify(await sendV2('pane.close', { id: args[2], ...callerSurface() }), null, 2));
                }
                else if (sub === 'focus') {
                    console.log(JSON.stringify(await sendV2('pane.focus', { id: args[2], ...callerSurface() }), null, 2));
                }
                else if (sub === 'list') {
                    console.log(JSON.stringify(await sendV2('pane.list', { workspaceId: getFlag(args, '--workspace') }), null, 2));
                }
                else {
                    console.error(`Unknown pane subcommand: ${sub}`);
                    process.exit(1);
                }
                break;
            }
            // Bare forms act on the CALLING pane (resolved host-side from the surface
            // id); with neither an argument nor COMUX_SURFACE_ID the host answers
            // -32602 instead of the old {ok:true}-and-nothing-happened.
            case 'close-pane':
                console.log(JSON.stringify(await sendV2('pane.close', { id: args[1], ...callerSurface() }), null, 2));
                break;
            case 'focus-pane':
                console.log(JSON.stringify(await sendV2('pane.focus', { id: args[1], ...callerSurface() }), null, 2));
                break;
            case 'zoom-pane':
                console.log(JSON.stringify(await sendV2('pane.zoom', { id: args[1], ...callerSurface() }), null, 2));
                break;
            case 'list-panes':
                console.log(JSON.stringify(await sendV2('pane.list', { workspaceId: getFlag(args, '--workspace') }), null, 2));
                break;
            case 'tree':
                console.log(JSON.stringify(await sendV2('system.tree'), null, 2));
                break;
            // Layout
            case 'layout': {
                const sub = args[1];
                if (sub === 'grid') {
                    const params = {};
                    for (let i = 2; i < args.length; i += 2) {
                        if (args[i] === '--count')
                            params.count = parseInt(args[i + 1], 10);
                        if (args[i] === '--type')
                            params.type = args[i + 1];
                        if (args[i] === '--anchor-surface')
                            params.anchorSurfaceId = args[i + 1];
                        if (args[i] === '--anchor-pane')
                            params.anchorPaneId = args[i + 1];
                        if (args[i] === '--workspace')
                            params.workspaceId = args[i + 1];
                    }
                    if (!params.count || params.count < 1) {
                        console.error('--count <N> is required and must be >= 1');
                        process.exit(1);
                    }
                    // If no explicit anchor, fall back to the current shell's surface so the command "just works" from inside a pane.
                    if (!params.anchorSurfaceId && !params.anchorPaneId && process.env.COMUX_SURFACE_ID) {
                        params.anchorSurfaceId = process.env.COMUX_SURFACE_ID;
                    }
                    console.log(JSON.stringify(await sendV2('layout.grid', params), null, 2));
                }
                else {
                    console.error(`Unknown layout command: ${sub}`);
                    process.exit(1);
                }
                break;
            }
            // Terminal interaction
            case 'send': {
                // Drop --surface <id> (and its value) from the free-form text args.
                const surfaceId = getFlag(args, '--surface') || process.env.COMUX_SURFACE_ID;
                const textArgs = stripFlag(args.slice(1), '--surface');
                const payload = { text: textArgs.join(' ') };
                if (surfaceId)
                    payload.surfaceId = surfaceId;
                console.log(JSON.stringify(await sendV2('surface.send_text', payload), null, 2));
                break;
            }
            case 'send-key': {
                const key = args[1];
                const modifiers = [];
                if (args.includes('--ctrl'))
                    modifiers.push('ctrl');
                if (args.includes('--shift'))
                    modifiers.push('shift');
                if (args.includes('--alt'))
                    modifiers.push('alt');
                const surfaceId = getFlag(args, '--surface') || process.env.COMUX_SURFACE_ID;
                const payload = { key, modifiers };
                if (surfaceId)
                    payload.surfaceId = surfaceId;
                console.log(JSON.stringify(await sendV2('surface.send_key', payload), null, 2));
                break;
            }
            case 'read-screen': {
                const lines = args.find((a, i) => args[i - 1] === '--lines');
                // `--surface` was accepted on the command line and then dropped, so
                // read-screen always answered with the ACTIVE surface — silently the
                // wrong pane. Both hosts resolve a surfaceId; only the CLI failed to
                // send one, which left no way to read a specific pane over SSH.
                const surfaceId = getFlag(args, '--surface') || process.env.COMUX_SURFACE_ID;
                const payload = { lines: lines ? parseInt(lines) : 50 };
                if (surfaceId)
                    payload.surfaceId = surfaceId;
                console.log(JSON.stringify(await sendV2('surface.read_text', payload), null, 2));
                break;
            }
            case 'trigger-flash':
                console.log(JSON.stringify(await sendV2('surface.trigger_flash', { id: args[1] }), null, 2));
                break;
            // Browser
            case 'browser': {
                // Drive the browser of the workspace this shell lives in, not the active one.
                const here = callerSurface();
                const sub = args[1];
                // Page loads (navigate waits up to 30s) and the click/fill checks that
                // wait for an element to become usable take longer than the 5s every
                // other call gets — that budget cut `browser open` off mid-load.
                const T = BROWSER_TIMEOUT_MS;
                const print = (r) => console.log(JSON.stringify(r, null, 2));
                switch (sub) {
                    case 'open':
                        print(await sendV2('browser.navigate', { ...here, url: args[2] }, T));
                        break;
                    case 'snapshot':
                        print(await sendV2('browser.snapshot', { ...here }, T));
                        break;
                    // click waits (≤5s) until the element is visible, enabled, settled and
                    // not covered; --force skips that for the odd case it gets wrong.
                    case 'click':
                        print(await sendV2('browser.click', { ...here, ref: args[2], force: args.includes('--force') }, T));
                        break;
                    case 'hover':
                        print(await sendV2('browser.hover', { ...here, ref: args[2] }, T));
                        break;
                    case 'type':
                        print(await sendV2('browser.type', { ...here, ref: args[2], text: args.slice(3).join(' ') }, T));
                        break;
                    // press: `browser type` clicks first, so a bare key needs its own verb —
                    // submitting a form after typing had no expression at all before this.
                    case 'press':
                        print(await sendV2('browser.press', { ...here, key: args[2], ref: args[3] }, T));
                        break;
                    case 'fill':
                        print(await sendV2('browser.fill', { ...here, ref: args[2], value: args.slice(3).join(' ') }, T));
                        break;
                    // select @eN <value|label>… — one argument per option.
                    case 'select':
                        print(await sendV2('browser.select', { ...here, ref: args[2], values: args.slice(3) }, T));
                        break;
                    // upload @eN <file>… — resolved here, where the relative paths mean something.
                    case 'upload':
                        print(await sendV2('browser.upload', { ...here, ref: args[2], files: args.slice(3).map((f) => path_1.default.resolve(f)) }, T));
                        break;
                    case 'scroll':
                        print(await sendV2('browser.scroll', { ...here, target: args[2] || 'down' }, T));
                        break;
                    case 'screenshot':
                        print(await sendV2('browser.screenshot', { ...here, fullPage: args.includes('--full') }, T));
                        break;
                    case 'get-text':
                        print(await sendV2('browser.get_text', { ...here, ref: args[2] }, T));
                        break;
                    case 'eval':
                        print(await sendV2('browser.eval', { ...here, js: args.slice(2).join(' ') }, T));
                        break;
                    // wait @eN [ms] | wait --text T | --selector CSS | --url PART [--gone] [--timeout ms]
                    case 'wait': {
                        const ref = args[2] && !args[2].startsWith('--') ? args[2] : undefined;
                        const legacyMs = ref && args[3] && !args[3].startsWith('--') ? parseInt(args[3], 10) : undefined;
                        print(await sendV2('browser.wait', {
                            ...here, ref,
                            text: getFlag(args, '--text'), selector: getFlag(args, '--selector'), url: getFlag(args, '--url'),
                            gone: args.includes('--gone'),
                            timeout: parseInt(getFlag(args, '--timeout') || '', 10) || legacyMs || undefined,
                        }, T));
                        break;
                    }
                    // console [--errors|--warnings] [--clear] [--limit N] [--json]
                    case 'console': {
                        const r = await sendV2('browser.console', {
                            ...here,
                            level: args.includes('--errors') ? 'error' : args.includes('--warnings') ? 'warn' : undefined,
                            clear: args.includes('--clear'),
                            limit: parseInt(getFlag(args, '--limit') || '', 10) || undefined,
                        }, T);
                        if (args.includes('--json')) {
                            print(r);
                            break;
                        }
                        const msgs = r?.messages ?? [];
                        if (!msgs.length) {
                            console.log('(no console messages)');
                            break;
                        }
                        for (const m of msgs)
                            console.log(`[${m.level}] ${m.text}${m.url ? `  (${m.url}${m.line ? `:${m.line}` : ''})` : ''}`);
                        if (r.dropped)
                            console.log(`(${r.dropped} older message(s) dropped)`);
                        break;
                    }
                    case 'dialogs':
                        print(await sendV2('browser.dialogs', { ...here }, T));
                        break;
                    // dialog accept|dismiss|default [--text T] [--always] — for the next one (or every one).
                    case 'dialog':
                        print(await sendV2('browser.dialog', {
                            ...here, action: args[2], text: getFlag(args, '--text'), always: args.includes('--always'),
                        }, T));
                        break;
                    // resize 390x844 [--mobile] | resize reset
                    case 'resize': {
                        if (args[2] === 'reset') {
                            print(await sendV2('browser.resize', { ...here, reset: true }, T));
                            break;
                        }
                        const m = /^(\d+)\s*[x×*,]\s*(\d+)$/i.exec(args[2] || '');
                        if (!m) {
                            console.error('Usage: comux browser resize <width>x<height> [--mobile] | reset');
                            process.exit(1);
                        }
                        print(await sendV2('browser.resize', { ...here, width: Number(m[1]), height: Number(m[2]), mobile: args.includes('--mobile') }, T));
                        break;
                    }
                    case 'back':
                        print(await sendV2('browser.back', { ...here }, T));
                        break;
                    case 'forward':
                        print(await sendV2('browser.forward', { ...here }, T));
                        break;
                    case 'reload':
                        print(await sendV2('browser.reload', { ...here }, T));
                        break;
                    // pick: ask the USER to click the element they mean ("which button?").
                    // Prints a block the agent can read as-is; --json for the structure.
                    case 'pick': {
                        const timeoutS = parseInt(getFlag(args, '--timeout') || '', 10) || 120;
                        const prompt = args.slice(2).filter((a, i, all) => !a.startsWith('--') && all[i - 1] !== '--timeout').join(' ');
                        const r = await sendV2('browser.pick', {
                            ...here, prompt, timeoutMs: timeoutS * 1000, screenshot: !args.includes('--no-screenshot'),
                        }, timeoutS * 1000 + 15_000);
                        if (args.includes('--json')) {
                            print(r);
                            break;
                        }
                        if (!r?.picked) {
                            console.error('comux browser pick: nothing was picked (Esc, or timed out)');
                            process.exit(2);
                        }
                        console.log(r.text);
                        break;
                    }
                    default:
                        console.error(`Unknown browser command: ${sub}`);
                        process.exit(1);
                }
                break;
            }
            // Git worktrees — the host runs git in the cwd this CLI was started in.
            case 'worktree':
                await runWorktreeCommand(args.slice(1));
                break;
            // Agent
            case 'agent': {
                const sub = args[1];
                switch (sub) {
                    case 'spawn': {
                        const params = {};
                        for (let i = 2; i < args.length; i += 2) {
                            if (args[i] === '--cmd')
                                params.cmd = args[i + 1];
                            if (args[i] === '--label')
                                params.label = args[i + 1];
                            if (args[i] === '--cwd')
                                params.cwd = args[i + 1];
                            if (args[i] === '--pane')
                                params.paneId = args[i + 1];
                            if (args[i] === '--workspace')
                                params.workspaceId = args[i + 1];
                        }
                        if (!params.cmd) {
                            console.error('--cmd is required');
                            process.exit(1);
                        }
                        if (!params.label)
                            params.label = params.cmd.split(/\s+/)[0];
                        // --worktree <branch>: give the agent its own checkout first, so
                        // parallel agents never write to the same files. The agent stays
                        // in this workspace (a pane here), only its cwd moves.
                        const wtBranch = getFlag(args, '--worktree');
                        if (wtBranch) {
                            const wt = await sendV2('worktree.create', {
                                cwd: params.cwd || process.cwd(), branch: wtBranch, base: getFlag(args, '--base'), workspace: false,
                            }, WORKTREE_TIMEOUT_MS);
                            params.cwd = wt.path;
                            const spawned = await sendV2('agent.spawn', params);
                            console.log(JSON.stringify({ ...spawned, worktree: { path: wt.path, branch: wt.branch, reused: wt.reused } }, null, 2));
                            break;
                        }
                        console.log(JSON.stringify(await sendV2('agent.spawn', params), null, 2));
                        break;
                    }
                    case 'spawn-batch': {
                        const jsonIdx = args.indexOf('--json');
                        if (jsonIdx === -1) {
                            console.error('Usage: comux agent spawn-batch --json \'[...]\'');
                            process.exit(1);
                        }
                        const json = args[jsonIdx + 1];
                        const parsed = JSON.parse(json);
                        const strategy = args.find((a, i) => args[i - 1] === '--strategy') || 'distribute';
                        console.log(JSON.stringify(await sendV2('agent.spawn_batch', { agents: parsed, strategy }), null, 2));
                        break;
                    }
                    case 'status':
                        console.log(JSON.stringify(await sendV2('agent.status', { agentId: args[2] }), null, 2));
                        break;
                    case 'list':
                        console.log(JSON.stringify(await sendV2('agent.list', { workspaceId: args.find((a, i) => args[i - 1] === '--workspace') }), null, 2));
                        break;
                    case 'kill':
                        console.log(JSON.stringify(await sendV2('agent.kill', { agentId: args[2] }), null, 2));
                        break;
                    default:
                        console.error(`Unknown agent command: ${sub}`);
                        process.exit(1);
                }
                break;
            }
            // Markdown
            // Every wrong usage used to exit 0 with no output at all — an unknown
            // subcommand and a missing --content/--file both fell out of the `if`
            // chain, so a typo looked exactly like success.
            case 'markdown': {
                const sub = args[1];
                if (sub !== 'set') {
                    console.error(`Usage: comux markdown set <surfaceId> (--content <text> | --file <path>)`);
                    process.exit(1);
                }
                const surfaceId = args[2];
                const contentFlag = args.indexOf('--content');
                const fileFlag = args.indexOf('--file');
                if (contentFlag !== -1) {
                    console.log(JSON.stringify(await sendV2('markdown.set_content', { surfaceId, markdown: args.slice(contentFlag + 1).join(' ') }), null, 2));
                }
                else if (fileFlag !== -1) {
                    const filePath = args[fileFlag + 1];
                    if (!filePath) {
                        console.error('comux markdown set: --file needs a path');
                        process.exit(1);
                    }
                    console.log(JSON.stringify(await sendV2('markdown.load_file', { surfaceId, filePath }), null, 2));
                }
                else {
                    console.error('comux markdown set: pass --content <text> or --file <path>');
                    process.exit(1);
                }
                break;
            }
            // Notifications
            case 'notify': {
                // Was a V1 `notify` line that NOTHING listened for — it printed
                // "Notification sent" and no notification ever appeared. V2 has a real
                // handler, and --title is now passed through instead of parsed and
                // discarded.
                const titleIdx = args.indexOf('--title');
                const bodyIdx = args.indexOf('--body');
                const title = titleIdx !== -1 ? args[titleIdx + 1] : undefined;
                const body = bodyIdx !== -1 ? args[bodyIdx + 1] : undefined;
                const text = args.filter((_, i) => i > 0 && ![titleIdx, titleIdx + 1, bodyIdx, bodyIdx + 1].includes(i)).join(' ') || body || '';
                if (!text) {
                    console.error('comux notify: nothing to say (pass text, or --body)');
                    process.exit(1);
                }
                const payload = { text };
                if (title)
                    payload.title = title;
                if (process.env.COMUX_SURFACE_ID)
                    payload.surfaceId = process.env.COMUX_SURFACE_ID;
                console.log(JSON.stringify(await sendV2('notification.fire', payload), null, 2));
                break;
            }
            case 'list-notifications':
                console.log(JSON.stringify(await sendV2('notification.list'), null, 2));
                break;
            // The documented form takes no argument, and it used to send `{id: undefined}`
            // — which cleared NOTHING on the GUI (the `all` branch was unreachable dead
            // code) and cleared EVERYTHING on comuxd (which ignored the id). Same input,
            // opposite results. Bare form now means "clear all" on both, explicitly.
            case 'clear-notifications':
                console.log(JSON.stringify(await sendV2('notification.clear', args[1] ? { id: args[1] } : { all: true }), null, 2));
                break;
            // Sidebar
            case 'set-status':
                console.log(JSON.stringify(await sendV2('sidebar.set_status', { key: args[1], value: args[2] }), null, 2));
                break;
            case 'set-progress': {
                const label = args.find((a, i) => args[i - 1] === '--label');
                console.log(JSON.stringify(await sendV2('sidebar.set_progress', { value: parseFloat(args[1]), label }), null, 2));
                break;
            }
            case 'log':
                console.log(JSON.stringify(await sendV2('sidebar.log', { level: args[1], message: args.slice(2).join(' ') }), null, 2));
                break;
            case 'sidebar-state':
                console.log(JSON.stringify(await sendV2('sidebar.get_state'), null, 2));
                break;
            case 'diff': {
                const file = args.find((a, i) => args[i - 1] === '--file') || '';
                console.log(JSON.stringify(await sendV2('diff.refresh', { file }), null, 2));
                break;
            }
            case 'hook': {
                const params = {};
                for (let i = 1; i < args.length; i += 2) {
                    if (args[i] === '--event')
                        params.event = args[i + 1];
                    if (args[i] === '--tool')
                        params.tool = args[i + 1];
                    if (args[i] === '--agent')
                        params.agentId = args[i + 1];
                    if (args[i] === '--surface')
                        params.surfaceId = args[i + 1];
                }
                // Attribute the event to the originating terminal so the status
                // machine can credit the right surface/workspace.
                if (!params.surfaceId && process.env.COMUX_SURFACE_ID)
                    params.surfaceId = process.env.COMUX_SURFACE_ID;
                await sendV2('hook.event', params);
                break;
            }
            case 'agent-activity': {
                const surfaceId = getFlag(args, '--surface') || process.env.COMUX_SURFACE_ID;
                if (!surfaceId) {
                    console.error('agent-activity: --surface or COMUX_SURFACE_ID required');
                    process.exit(1);
                }
                const params = { surfaceId };
                const tool = getFlag(args, '--tool');
                if (tool)
                    params.tool = tool;
                const skill = getFlag(args, '--skill');
                if (skill)
                    params.skill = skill;
                if (args.includes('--done'))
                    params.done = true;
                if (args.includes('--active'))
                    params.done = false;
                await sendV2('agent.activity', params);
                break;
            }
            default:
                console.error(`Unknown command: ${command}`);
                printUsage();
                process.exit(1);
        }
    }
    catch (err) {
        if (err.code === 'ENOENT' || err.code === 'ECONNREFUSED') {
            console.error('comux is not running (could not connect to pipe)');
        }
        else {
            console.error(`Error: ${err.message}`);
        }
        process.exit(1);
    }
}
/** navigate waits up to 30s for a load; click/fill wait up to 5s for a usable element. */
const BROWSER_TIMEOUT_MS = 45_000;
/** A checkout plus copying `.worktreeinclude` files can take a while on a big repo. */
const WORKTREE_TIMEOUT_MS = 180_000;
const WORKTREE_USAGE = `Usage:
  comux worktree create <branch> [--base REF] [--path DIR] [--title T] [--setup] [--no-workspace] [--no-select]
  comux worktree list [--status]
  comux worktree remove <branch|path> [--force] [--delete-branch] [--keep-workspace]
  comux worktree remove --workspace <workspaceId> [--force] [--delete-branch]

create  makes <branch> (from --base, default HEAD) in its own checkout beside the
        repo (<repo>.worktrees/<branch>) and opens a workspace on it. An existing
        branch is checked out instead; a branch that already has a worktree gets
        that one back. Untracked files listed in .worktreeinclude are copied in.
        --setup types the repo's .comux/worktree.json setup commands into the new
        workspace's terminal (never run without it).
remove  refuses while the checkout has uncommitted changes (--force discards
        them), closes the workspace on it, and keeps the branch unless
        --delete-branch (which only deletes a merged branch).`;
/** First non-flag argument, skipping each flag's value. */
function positionalArg(args, valueFlags) {
    for (let i = 0; i < args.length; i++) {
        if (valueFlags.includes(args[i])) {
            i++;
            continue;
        }
        if (!args[i].startsWith('--'))
            return args[i];
    }
    return undefined;
}
async function runWorktreeCommand(args) {
    const sub = args[0];
    const rest = args.slice(1);
    const cwd = path_1.default.resolve(getFlag(rest, '--cwd') || process.cwd());
    switch (sub) {
        case 'create':
        case 'new': {
            const branch = positionalArg(rest, ['--base', '--path', '--title', '--cwd']);
            if (!branch) {
                console.error(WORKTREE_USAGE);
                process.exit(1);
            }
            const r = await sendV2('worktree.create', {
                cwd, branch,
                base: getFlag(rest, '--base'),
                path: getFlag(rest, '--path'),
                title: getFlag(rest, '--title'),
                setup: rest.includes('--setup'),
                workspace: !rest.includes('--no-workspace'),
                select: !rest.includes('--no-select'),
            }, WORKTREE_TIMEOUT_MS);
            console.log(JSON.stringify(r, null, 2));
            if (r?.setup?.length && !r.setupStarted && !r.reused) {
                console.error(`comux: this repo defines setup commands (${r.setup.join(' ; ')}) — not run. Add --setup to run them.`);
            }
            return;
        }
        case 'list':
        case 'ls':
            console.log(JSON.stringify(await sendV2('worktree.list', { cwd, status: rest.includes('--status') }, WORKTREE_TIMEOUT_MS), null, 2));
            return;
        case 'remove':
        case 'rm': {
            const target = positionalArg(rest, ['--workspace', '--cwd']);
            const workspaceId = getFlag(rest, '--workspace');
            if (!target && !workspaceId) {
                console.error(WORKTREE_USAGE);
                process.exit(1);
            }
            // A folder that exists is a path; anything else is a branch name.
            const asPath = !!target && (path_1.default.isAbsolute(target) || fs_1.default.existsSync(path_1.default.resolve(cwd, target)));
            const r = await sendV2('worktree.remove', {
                cwd,
                ...(workspaceId ? { workspaceId } : asPath ? { path: path_1.default.resolve(cwd, target) } : { branch: target }),
                force: rest.includes('--force'),
                deleteBranch: rest.includes('--delete-branch'),
                closeWorkspace: !rest.includes('--keep-workspace'),
            }, WORKTREE_TIMEOUT_MS);
            console.log(JSON.stringify(r, null, 2));
            return;
        }
        default:
            console.error(WORKTREE_USAGE);
            process.exit(sub === 'help' || sub === '--help' ? 0 : 1);
    }
}
function printVersion() {
    const install = (0, install_method_1.detectInstallMethod)();
    console.log(`comux ${(0, app_version_1.appVersion)()}  (${install.method}, ${install.root})`);
}
/**
 * `comux upgrade` — report, never act. An apt install must not be overwritten by
 * install.sh and vice versa, and silently swapping the binary under a live
 * daemon is a good way to lose someone's session, so we print the one command
 * that fits this install and let the user run it.
 */
async function printUpgrade() {
    const install = (0, install_method_1.detectInstallMethod)();
    const current = (0, app_version_1.appVersion)();
    console.log(`comux ${current}  (${install.method} install at ${install.root})`);
    process.stdout.write('checking for updates… ');
    const info = await (0, update_check_1.checkForUpdate)({
        currentVersion: current,
        method: install.method,
        upgradeCommand: install.upgradeCommand,
        autoInstallable: install.autoInstallable,
    });
    if (!info) {
        console.log('already on the latest release.');
        return;
    }
    console.log(`v${info.version} available.\n`);
    if (info.upgradeCommand) {
        console.log('  Upgrade with:\n');
        console.log(`    ${info.upgradeCommand}\n`);
        console.log('  Detach any TUI session first (Ctrl+B q) — the daemon keeps your shells running.');
    }
    else if (install.autoInstallable) {
        console.log('  Open comux and click the version badge in the title bar to update in place.');
    }
    else {
        console.log(`  Download the new build from:\n\n    ${info.downloadPage}`);
    }
    console.log(`\n  Release notes: ${info.url}`);
}
// ─── comux service ──────────────────────────────────────────────────────────
// Install comuxd as a systemd USER service. See shared/systemd-unit.ts for why
// user and not system, and why linger matters.
function systemctl(args) {
    const r = (0, child_process_1.spawnSync)('systemctl', ['--user', ...args], { encoding: 'utf-8' });
    const out = `${r.stdout ?? ''}${r.stderr ?? ''}`.trim();
    return { ok: r.status === 0, out };
}
/**
 * systemd is only usable here if the USER BUS answers, not merely if the binary
 * exists. Containers and bare SSH sessions without a login seat have systemctl
 * on PATH but no bus, where every call fails with "Failed to connect to bus" —
 * printing that raw is how the status output ends up unreadable.
 */
function hasSystemd() {
    if (process.platform !== 'linux')
        return false;
    if ((0, child_process_1.spawnSync)('systemctl', ['--user', '--version'], { encoding: 'utf-8' }).status !== 0)
        return false;
    // `is-system-running` is NOT a bus probe — without a bus it still answers
    // "offline" on stdout. `show` has to reach the manager, so it is the one that
    // actually reports the bus being absent.
    const probe = (0, child_process_1.spawnSync)('systemctl', ['--user', 'show', '--property=Version'], { encoding: 'utf-8' });
    if (probe.status === 0)
        return true;
    const out = `${probe.stdout ?? ''}${probe.stderr ?? ''}`;
    return !/Failed to connect to bus|No medium found|Refusing to operate/i.test(out);
}
function lingerEnabled() {
    const user = process.env.USER || process.env.LOGNAME || '';
    if (!user)
        return false;
    const r = (0, child_process_1.spawnSync)('loginctl', ['show-user', user, '--property=Linger'], { encoding: 'utf-8' });
    return (r.stdout ?? '').includes('Linger=yes');
}
async function serviceCommand(args) {
    const sub = args[0] && !args[0].startsWith('-') ? args[0] : 'status';
    const plan = (0, systemd_unit_1.planUnit)();
    if (process.platform !== 'linux') {
        console.error('comux service: systemd units are Linux-only.');
        console.error(process.platform === 'win32'
            ? '  On Windows the GUI starts its own background process; there is nothing to install.'
            : '  On macOS use a launchd agent instead.');
        process.exit(1);
    }
    switch (sub) {
        case 'path':
            console.log(plan.unitPath);
            return;
        case 'print':
            // The unit on stdout, for anyone who would rather place it themselves.
            process.stdout.write((0, systemd_unit_1.renderUnit)(plan));
            return;
        case 'install': {
            // Writing a unit that works once and then breaks is worse than not writing
            // one, so the AppImage case stops here rather than looking installed.
            if (plan.unsupported) {
                console.error('comux service: cannot install a unit from this build.');
                console.error(`  ${plan.unsupported}`);
                process.exitCode = 1;
                return;
            }
            fs_1.default.mkdirSync(path_1.default.dirname(plan.unitPath), { recursive: true });
            fs_1.default.writeFileSync(plan.unitPath, (0, systemd_unit_1.renderUnit)(plan), 'utf-8');
            console.log(`comux service: wrote ${plan.unitPath}`);
            console.log(`  ExecStart  ${plan.execStart}`);
            if (!hasSystemd()) {
                console.error('  no systemd user bus here — the unit is written but NOT enabled.');
                console.error('  Run this again from a real login session, or enable it yourself:');
                console.error(`    systemctl --user daemon-reload && systemctl --user enable --now ${plan.unitName}`);
                return;
            }
            systemctl(['daemon-reload']);
            const en = systemctl(['enable', '--now', plan.unitName]);
            if (!en.ok) {
                console.error(`  could not enable it: ${en.out}`);
                return;
            }
            console.log(`  enabled and started ${plan.unitName}`);
            // The part that decides whether this was worth doing.
            if (!lingerEnabled()) {
                const user = process.env.USER || process.env.LOGNAME || '$USER';
                console.log('');
                console.log('  NOTE: your user manager stops when your last session ends, which would');
                console.log('        stop comuxd and kill every shell it owns — the thing you installed');
                console.log('        this to prevent. Keep it running across logouts with:');
                console.log('');
                console.log(`          sudo loginctl enable-linger ${user}`);
            }
            return;
        }
        case 'uninstall': {
            if (hasSystemd()) {
                systemctl(['disable', '--now', plan.unitName]);
            }
            try {
                fs_1.default.unlinkSync(plan.unitPath);
                console.log(`comux service: removed ${plan.unitPath}`);
            }
            catch {
                console.log(`comux service: no unit at ${plan.unitPath}`);
            }
            if (hasSystemd())
                systemctl(['daemon-reload']);
            return;
        }
        case 'status': {
            const installed = fs_1.default.existsSync(plan.unitPath);
            console.log(`comux service — ${installed ? 'installed' : 'not installed'}`);
            console.log('');
            console.log(`  unit       ${plan.unitPath}`);
            console.log(`  ExecStart  ${plan.execStart}`);
            if (plan.instance)
                console.log(`  instance   ${plan.instance}`);
            if (plan.unsupported) {
                console.log('');
                console.log(`  UNSUPPORTED  ${plan.unsupported}`);
                return;
            }
            if (!hasSystemd()) {
                console.log('  systemd    no user bus here — the unit is written, but nothing can');
                console.log('             start it until you have a real login session');
                console.log('             (containers and `ssh host <cmd>` have no seat).');
                return;
            }
            const active = systemctl(['is-active', plan.unitName]);
            const enabled = systemctl(['is-enabled', plan.unitName]);
            console.log(`  state      ${active.out || 'unknown'} (${enabled.out || 'not enabled'})`);
            console.log(`  linger     ${lingerEnabled() ? 'on — survives logout' : 'OFF — comuxd stops when your last session ends'}`);
            console.log('');
            if (!installed)
                console.log('  Install it:  comux service install');
            return;
        }
        default:
            console.log('usage: comux service [status|install|uninstall|print|path]');
            return;
    }
}
// ─── comux rest ─────────────────────────────────────────────────────────────
// rest-api.json is plain JSON in this instance's appData dir, so everything here
// is read-modify-write on a local file — which is why these subcommands answer
// with nothing running. The only remote step is asking a live GUI/daemon to
// re-read the file (`rest.reload`), sparing a restart that would kill every shell
// the daemon owns.
/** Enough of the token to recognise, not enough to reuse — `status` is the kind of
 *  output that ends up in a screenshare. `comux rest token` prints the real one. */
function maskToken(token) {
    if (!token)
        return '(none)';
    return token.length <= 12 ? '••••' : `${token.slice(0, 6)}…${token.slice(-4)}  (${token.length} chars)`;
}
/**
 * Ask a running comux (GUI or comuxd) to re-read rest-api.json and re-apply the
 * server. "Nothing is running" is a normal outcome — the next start reads the file
 * anyway — so this reports on stderr and never fails the command. stderr keeps
 * `TOKEN=$(comux rest token --rotate)` clean.
 */
async function applyRestConfigLive() {
    try {
        const r = await sendV2('rest.reload');
        if (r && typeof r === 'object' && r.enabled) {
            // `listening` is absent on a comux from before the bind result was
            // reported; treat that as "it said yes" rather than inventing a failure.
            if (r.listening === false) {
                console.error(`  applied to the running comux — but it FAILED to listen on http://${r.host}:${r.port}`);
                if (r.error)
                    console.error(`  ${r.error}`);
            }
            else {
                console.error(`  applied to the running comux — listening on http://${r.host}:${r.port}`);
            }
        }
        else {
            console.error('  applied to the running comux — server stopped');
        }
    }
    catch (err) {
        if (err?.code === 'ENOENT' || err?.code === 'ECONNREFUSED') {
            console.error('  no comux running — this applies the next time one starts.');
        }
        else if (/not (found|implemented)/i.test(err?.message || '')) {
            // A GUI/daemon from before rest.reload existed.
            console.error('  the running comux predates live reload — restart it to apply.');
        }
        else {
            console.error(`  could not reach the running comux (${err?.message || err}) — restart it to apply.`);
        }
    }
}
/**
 * `GET /health` against the configured listener, so `status` can tell "enabled in
 * the file" apart from "actually accepting requests". Worth the round trip: a port
 * clash is only console.error'd by the server, leaving the config claiming enabled
 * with nothing bound.
 */
function probeRestHealth(config) {
    return new Promise((resolve) => {
        // 0.0.0.0 / :: are bind addresses, not destinations.
        const host = config.host === '0.0.0.0' || config.host === '::' ? '127.0.0.1' : config.host;
        const req = http_1.default.request({
            host,
            port: config.port,
            path: '/health',
            method: 'GET',
            headers: { Authorization: `Bearer ${config.token}` },
            timeout: 2000,
        }, (res) => {
            res.resume();
            resolve(res.statusCode === 200 ? 'listening' : `responded HTTP ${res.statusCode}`);
        });
        req.on('timeout', () => { req.destroy(); resolve('no response (timed out)'); });
        req.on('error', () => resolve('NOT listening'));
        req.end();
    });
}
/**
 * Explain a listener that isn't answering. `probeRestHealth` can only report
 * silence; the running comux knows the difference between "the port was already
 * taken" and "there is no comux running", so ask it. Returns display lines.
 */
async function restServerReason() {
    try {
        const st = await sendV2('rest.status');
        if (st && typeof st === 'object') {
            if (st.listening)
                return ['(comux says it IS listening — something else is intercepting the port)'];
            if (st.error)
                return ['the running comux could not start it:', st.error];
            if (!st.enabled)
                return ['the running comux read this config as DISABLED — try: comux rest enable'];
        }
        return ['the running comux reports no listener — try: comux rest enable'];
    }
    catch (err) {
        if (err?.code === 'ENOENT' || err?.code === 'ECONNREFUSED') {
            return ['no comux/comuxd is running — the API only exists while one is up'];
        }
        if (/not (found|implemented)/i.test(err?.message || '')) {
            return ['(this comux predates rest.status — restart it, or check its log for a port clash)'];
        }
        return [`could not ask the running comux (${err?.message || err})`];
    }
}
/** The `comux rest` flags that consume the following word. Anything else starting
 *  with `-` is a boolean, so the word after it is still a positional. */
const REST_VALUE_FLAGS = new Set(['--host', '--port', '--agent', '--mode', '--cwd', '--prompt', '--prompt-file']);
/**
 * Read the `<name>` positional of a rest subcommand — the first word that is
 * neither a flag nor a flag's value, so `add-endpoint --agent codex review` and
 * `add-endpoint review --agent codex` both find `review`.
 */
function restPositional(args) {
    for (let i = 0; i < args.length; i++) {
        if (args[i].startsWith('-')) {
            if (REST_VALUE_FLAGS.has(args[i]))
                i++; // skip its value
            continue;
        }
        return args[i];
    }
    return undefined;
}
async function restCommand(args) {
    const sub = args[0] && !args[0].startsWith('-') ? args[0] : 'status';
    const rest = args[0] && !args[0].startsWith('-') ? args.slice(1) : args;
    switch (sub) {
        case 'help':
            printRestUsage();
            return;
        case 'path':
            console.log((0, rest_config_1.restConfigPath)());
            return;
        case 'status': {
            // getRestConfig() creates the file and a token on first run — so `status` is
            // also the "initialise it for me" command.
            const c = (0, rest_config_1.getRestConfig)();
            console.log(`comux REST API — ${c.enabled ? 'ENABLED' : 'disabled'}`);
            console.log('');
            console.log(`  config     ${(0, rest_config_1.restConfigPath)()}`);
            console.log(`  address    http://${c.host}:${c.port}`);
            console.log(`  token      ${rest.includes('--show-token') ? c.token : maskToken(c.token)}`);
            if (c.enabled) {
                const state = await probeRestHealth(c);
                console.log(`  listener   ${state}`);
                if (state !== 'listening') {
                    // The probe only says "nothing answered". Ask the running comux WHY —
                    // it knows whether the bind failed (and with what errno) or whether
                    // there is simply no comux running at all.
                    const reason = await restServerReason();
                    for (const line of reason)
                        console.log(`             ${line}`);
                }
            }
            console.log('');
            if (c.endpoints.length === 0) {
                console.log('  endpoints  (none)');
                console.log('             POST /api/<name> needs one; the /terminals routes do not.');
            }
            else {
                console.log('  endpoints  name              agent    mode     cwd');
                for (const e of c.endpoints) {
                    console.log(`             ${e.name.padEnd(17)} ${e.agent.padEnd(8)} ${e.mode.padEnd(8)} ${e.cwd || '(daemon cwd)'}`);
                }
            }
            console.log('');
            if (!c.enabled) {
                console.log('  Enable it:   comux rest enable');
            }
            else {
                console.log(`  Terminals:   curl -H "Authorization: Bearer $(comux rest token)" http://127.0.0.1:${c.port}/terminals`);
            }
            console.log('  Docs:        docs/rest-api.md');
            return;
        }
        case 'token': {
            if (rest.includes('--rotate')) {
                const c = (0, rest_config_1.regenerateRestToken)();
                console.error('comux: token rotated — every existing client credential is now invalid.');
                console.log(c.token); // stdout stays just the token
                await applyRestConfigLive();
                return;
            }
            // Bare value so `TOKEN=$(comux rest token)` works.
            console.log((0, rest_config_1.getRestConfig)().token);
            return;
        }
        case 'enable':
        case 'disable': {
            const enabled = sub === 'enable';
            const patch = { enabled };
            const host = getFlag(rest, '--host');
            if (host)
                patch.host = host;
            const portRaw = getFlag(rest, '--port');
            if (portRaw !== undefined) {
                const port = Number(portRaw);
                // updateRestConfig silently resets an out-of-range port to 7878; rejecting
                // it here turns a typo into an error instead of a mystery.
                if (!Number.isInteger(port) || port < 1 || port > 65535) {
                    console.error(`comux rest: --port must be an integer 1-65535 (got "${portRaw}")`);
                    process.exit(1);
                }
                patch.port = port;
            }
            const c = (0, rest_config_1.updateRestConfig)(patch);
            if (!enabled) {
                console.log('comux REST API disabled.');
                await applyRestConfigLive();
                return;
            }
            console.log(`comux REST API enabled on http://${c.host}:${c.port}`);
            console.log(`  token  ${maskToken(c.token)}   (full value: comux rest token)`);
            if (c.host !== '127.0.0.1' && c.host !== 'localhost' && c.host !== '::1') {
                console.log('');
                console.log(`  WARNING: bound to ${c.host}, not loopback. The token types straight into`);
                console.log('  your terminals, so it is equivalent to remote shell access, and there is');
                console.log('  no TLS or IP allowlist behind it. Prefer loopback + SSH forwarding:');
                console.log(`      ssh -N -L ${c.port}:127.0.0.1:${c.port} <host>`);
            }
            await applyRestConfigLive();
            return;
        }
        case 'endpoints': {
            const c = (0, rest_config_1.getRestConfig)();
            if (c.endpoints.length === 0) {
                console.log('comux: no REST endpoints yet. Add one with:');
                console.log('  comux rest add-endpoint review --agent claude --mode plan \\');
                console.log('    --prompt "Review this and answer concisely:\\n\\n{input}"');
                return;
            }
            console.log(`comux REST endpoints — POST http://${c.host}:${c.port}/api/<name>`);
            for (const e of c.endpoints) {
                const prompt = e.prompt
                    ? JSON.stringify(e.prompt.length > 120 ? `${e.prompt.slice(0, 117)}…` : e.prompt)
                    : '(none — body.text is sent verbatim)';
                console.log('');
                console.log(`  ${e.name}`);
                console.log(`     agent   ${e.agent}    mode ${e.mode}`);
                console.log(`     cwd     ${e.cwd || '(daemon cwd)'}`);
                console.log(`     prompt  ${prompt}`);
            }
            return;
        }
        case 'add-endpoint': {
            const name = restPositional(rest);
            if (!name) {
                console.error('comux rest add-endpoint: <name> is required');
                printRestUsage();
                process.exit(1);
            }
            const spec = { name };
            const agent = getFlag(rest, '--agent');
            if (agent !== undefined) {
                if (!rest_config_1.VALID_AGENTS.includes(agent)) {
                    console.error(`comux rest: --agent must be ${rest_config_1.VALID_AGENTS.join(' | ')} (got "${agent}")`);
                    process.exit(1);
                }
                spec.agent = agent;
            }
            const mode = getFlag(rest, '--mode');
            if (mode !== undefined) {
                if (!rest_config_1.VALID_MODES.includes(mode)) {
                    console.error(`comux rest: --mode must be ${rest_config_1.VALID_MODES.join(' | ')} (got "${mode}")`);
                    process.exit(1);
                }
                spec.mode = mode;
            }
            const cwd = getFlag(rest, '--cwd');
            if (cwd !== undefined)
                spec.cwd = path_1.default.resolve(cwd);
            // --prompt-file wins: a template with newlines/quotes is painful to pass as
            // one shell argument, and that is exactly the shape a useful template has.
            const promptFile = getFlag(rest, '--prompt-file');
            const prompt = getFlag(rest, '--prompt');
            if (promptFile !== undefined) {
                try {
                    spec.prompt = fs_1.default.readFileSync(promptFile, 'utf-8');
                }
                catch (e) {
                    console.error(`comux rest: could not read --prompt-file ${promptFile} (${e.message})`);
                    process.exit(1);
                }
            }
            else if (prompt !== undefined) {
                spec.prompt = prompt;
            }
            const before = (0, rest_config_1.getRestConfig)();
            const key = (0, rest_config_1.normalizeEndpointName)(name).toLowerCase();
            const existed = before.endpoints.some((e) => e.name.toLowerCase() === key);
            const c = (0, rest_config_1.updateRestConfig)({ endpoints: (0, rest_config_1.upsertEndpoint)(before.endpoints, spec) });
            const saved = c.endpoints.find((e) => e.name.toLowerCase() === key);
            if (!saved) {
                // sanitizeEndpoints rejected it — the only way in is an unusable name.
                console.error(`comux rest: "${name}" is not a usable endpoint name.`);
                process.exit(1);
            }
            console.log(`comux: endpoint "${saved.name}" ${existed ? 'updated' : 'added'}`);
            console.log(`  POST http://${c.host}:${c.port}/api/${saved.name}`);
            console.log(`  agent ${saved.agent}   mode ${saved.mode}   cwd ${saved.cwd || '(daemon cwd)'}`);
            if (!saved.prompt) {
                console.log('  no prompt template — body.text is sent to the agent verbatim.');
            }
            else if (!saved.prompt.includes('{input}')) {
                console.log('  note: template has no {input} — body.text is appended after it.');
            }
            if (saved.mode === 'auto') {
                console.log('');
                console.log('  WARNING: mode "auto" runs the agent with its safety rails off');
                console.log('  (claude --permission-mode bypassPermissions, codex');
                console.log('  --dangerously-bypass-approvals-and-sandbox, gemini --approval-mode yolo).');
                console.log('  Anyone holding the token gets that.');
            }
            if (!c.enabled)
                console.log('  The API itself is still off — run: comux rest enable');
            await applyRestConfigLive();
            return;
        }
        case 'rm-endpoint': {
            const name = restPositional(rest);
            if (!name) {
                console.error('comux rest rm-endpoint: <name> is required');
                process.exit(1);
            }
            const before = (0, rest_config_1.getRestConfig)();
            const { endpoints, removed } = (0, rest_config_1.removeEndpoint)(before.endpoints, name);
            if (!removed) {
                const known = before.endpoints.map((e) => e.name).join(', ') || '(none)';
                console.error(`comux rest: no endpoint named "${name}". Known: ${known}`);
                process.exit(1);
            }
            (0, rest_config_1.updateRestConfig)({ endpoints });
            console.log(`comux: endpoint "${removed.name}" removed.`);
            await applyRestConfigLive();
            return;
        }
        default:
            console.error(`comux rest: unknown subcommand "${sub}"`);
            printRestUsage();
            process.exit(1);
    }
}
function printRestUsage() {
    console.log(`comux rest — external REST API (drive an in-terminal agent over HTTP)

  comux rest [status] [--show-token]   config, listener state, endpoints
  comux rest path                      print the rest-api.json path
  comux rest token [--rotate]          print the bearer token (stdout = token only)
  comux rest enable [--host H] [--port P]     turn it on (default 127.0.0.1:7878)
  comux rest disable                   turn it off
  comux rest endpoints                 list the POST /api/<name> endpoints
  comux rest add-endpoint <name> [--agent claude|codex|gemini]
                                [--mode plan|accept|auto] [--cwd DIR]
                                [--prompt TEXT | --prompt-file FILE]
  comux rest rm-endpoint <name>

Edits apply to a running comux/comuxd immediately — no restart, no lost shells.
Routes, curl examples and the security notes: docs/rest-api.md`);
}
function printUsage() {
    console.log(`comux CLI — terminal multiplexer for AI agents

Usage: comux <command> [options]

System:     ping, identify, capabilities, list-windows, focus-window <id>
Version:    version (--version, -v), upgrade   (report the upgrade command for this install)
Daemon TUI: attach                          (full-screen multiplexer over comuxd; SSH: ssh -t host comux attach)
Workspace:  new-workspace [--worktree <branch>], close-workspace <id>, select-workspace <id>, rename-workspace <id> <title>, list-workspaces
Surface:    new-surface [--type T] [--color-scheme NAME], close-surface [id], focus-surface [id]
            ls | list-surfaces [--all | --workspace <id> | --pane <id>]   (ls = all terminals in the daemon)
            set-color-scheme [surfaceId] <scheme>, clear-color-scheme [surfaceId], list-themes
Pane:       split [--down] [--type T] [--color-scheme NAME], close-pane [id], focus-pane [id], zoom-pane [id], list-panes, tree
            (split / new-surface / close-pane / *-surface with no id act on the pane you run them in)
            pane new|close|focus|list   (verb form, mirrors issue #4 example)
Layout:     layout grid --count <N> [--type terminal] [--anchor-surface <id>]
Terminal:   send <text>, send-key <key>, read-screen, trigger-flash
Browser:    browser open|snapshot|click [--force]|hover|type|press|fill|select|upload|scroll|screenshot|get-text|eval
            browser wait [@eN] [--text T|--selector CSS|--url PART] [--gone] | console [--errors] [--clear]
            browser dialogs | dialog accept|dismiss|default [--text T] [--always] | resize WxH|reset | pick [what]
            browser back|forward|reload
Agent:      agent spawn|spawn-batch|status|list|kill   (spawn --worktree <branch>: own checkout)
Worktree:   worktree create <branch> [--base REF] [--setup] | list | remove <branch|path>   ('comux worktree help')
Markdown:   markdown set <id> --content <text> | --file <path>
Diff:       diff [--file <path>]
Notify:     notify <text>, list-notifications, clear-notifications
Sidebar:    set-status, set-progress, log, sidebar-state
Hook:       hook --event <type> --tool <name> [--agent <id>]
Config:     config show|reload|path   (edits ~/.comux/config.toml — see docs)
            reload-config             (shorthand for 'config reload')
REST API:   rest status|enable|disable|token|endpoints|add-endpoint|rm-endpoint
Service:    service status|install|uninstall|print|path   (systemd user unit, Linux)
            (drive an in-terminal claude/codex over HTTP — 'comux rest help')
`);
}
main();

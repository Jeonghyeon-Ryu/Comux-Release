import { ThemeConfig } from './types';
/**
 * Parse a Ghostty-style theme file (key = value pairs) into a ThemeConfig.
 * Returns null if the content cannot be meaningfully parsed.
 */
export declare function parseThemeFileContent(name: string, content: string): ThemeConfig | null;
export declare function loadBundledThemes(): Map<string, ThemeConfig>;
/**
 * Resolve a theme by name. Tries bundled themes first, then falls back to
 * the built-in Monokai default. Name lookup is case-insensitive.
 */
export declare function getThemeByName(name: string | undefined | null): ThemeConfig;
/**
 * Returns the built-in Monokai default theme.
 */
export declare function getDefaultTheme(): ThemeConfig;

#!/usr/bin/env bash
# Detect if comux is running and available.
# Exit 0 + print "available" if comux responds; exit 1 + print "unavailable" otherwise.
#
# Notes for Windows / Git Bash:
#  - `comux` is NOT a PATH binary — comux defines it as a shell function
#    (`comux() { node "$COMUX_CLI" "$@"; }`) that only exists in interactive
#    shells, so `command -v comux` fails in the non-interactive shell Claude
#    Code spawns. We invoke the CLI directly via $COMUX_CLI instead.
#  - `[ -e //./pipe/comux ]` cannot stat a Win32 named pipe in Git Bash and
#    always returns false, so we probe the pipe with a real connection (node).

# 1. Strongest signal: comux injects COMUX_CLI into every PTY it spawns, and it
#    is inherited by child processes (unlike the `comux` shell function).
if [ -n "$COMUX_CLI" ] && command -v node >/dev/null 2>&1; then
  result=$(node "$COMUX_CLI" ping 2>/dev/null)
  if [ "$result" = "pong" ]; then
    echo "available"
    exit 0
  fi
fi

# 2. `comux` exposed as a PATH command or an exported shell function.
if command -v comux >/dev/null 2>&1; then
  result=$(comux ping 2>/dev/null)
  if [ "$result" = "pong" ]; then
    echo "available"
    exit 0
  fi
fi

# 3. Fallback: probe the named pipe with a real connection. The Git Bash
#    `[ -e ]` test cannot see Win32 named pipes, so connect for real via node.
if command -v node >/dev/null 2>&1; then
  pipe="${COMUX_PIPE:-\\\\.\\pipe\\comux}"
  probe=$(node -e '
    const net = require("net");
    const s = net.connect(process.argv[1]);
    s.on("connect", () => { console.log("ok"); s.destroy(); process.exit(0); });
    s.on("error", () => process.exit(1));
    setTimeout(() => process.exit(1), 1500);
  ' "$pipe" 2>/dev/null)
  if [ "$probe" = "ok" ]; then
    echo "available"
    exit 0
  fi
fi

echo "unavailable"
exit 1

/**
 * The agent is mid-turn.
 *
 * Claude Code prints "esc to interrupt" on its live status line. "interrupt" is
 * load-bearing here and the wording may NOT be relaxed to cover more CLIs: a
 * menu footer reads "Enter to select · esc to cancel", so accepting "esc to
 * cancel" as a working signal inverts every waiting screen into a working one.
 * (Tried it; two tests caught it immediately, and rest-server already classifies
 * that exact string as menu chrome.) Only affordances that are specific to an
 * interruptible, in-flight turn belong here.
 */
export declare const WORKING_RE: RegExp;
/**
 * Detect that the agent has paused mid-turn waiting for the user — a permission
 * prompt ("Do you want to proceed?" with a numbered ❯ menu), a y/n confirmation,
 * or any selection list. In `accept`/`plan` mode Claude still stops here for
 * non-edit actions, so callers need to know the turn isn't finished — it's blocked.
 *
 * Only the tail is inspected (the live prompt is at the bottom of the screen),
 * and the working spinner is excluded — a prompt is only "waiting" once the
 * agent has stopped processing.
 */
export declare function detectWaitingForInput(text: string): boolean;

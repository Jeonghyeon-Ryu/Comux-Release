"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfigPath = getConfigPath;
exports.loadUserConfig = loadUserConfig;
/**
 * user-config.ts — Loads `~/.comux/config.toml` and maps it to partial
 * TerminalPrefs + named user color schemes.
 *
 * Shape (matches issue #4):
 *
 *   [terminal]
 *   font-family     = "Consolas"
 *   font-size       = 14
 *   cursor-style    = "block"       # block | underline | bar
 *   cursor-blink    = true
 *   scrollback-lines = 10000
 *
 *   [terminal.colors]
 *   default = "Dracula"
 *
 *   [terminal.colors.schemes.prod]
 *   background = "#2b0b0b"
 *   foreground = "#ffdddd"
 *   cursor     = "#ff5555"
 *
 *   [terminal.colors.schemes.dev]
 *   background = "#0b1f0b"
 *   foreground = "#ccffcc"
 *   palette    = ["#000", "#ff5555", ...] # optional, up to 16 entries
 *
 * File-wins-at-startup, app-wins-at-runtime: this data seeds the store
 * on boot; users can still tweak via the Settings UI afterwards.
 * A `comux reload-config` command re-applies the file over runtime state.
 */
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const toml_parser_1 = require("./toml-parser");
function getConfigPath() {
    const home = os.homedir();
    return path.join(home, '.comux', 'config.toml');
}
function loadUserConfig(filePath = getConfigPath()) {
    const errors = [];
    if (!fs.existsSync(filePath)) {
        return { path: filePath, errors };
    }
    let text;
    try {
        text = fs.readFileSync(filePath, 'utf-8');
    }
    catch (e) {
        return { path: filePath, errors: [`read failed: ${e?.message || e}`] };
    }
    let parsed;
    try {
        parsed = (0, toml_parser_1.parseToml)(text);
    }
    catch (e) {
        return { path: filePath, errors: [`parse failed: ${e?.message || e}`] };
    }
    return { ...mapToConfig(parsed, errors), path: filePath, errors };
}
// ---------------------------------------------------------------------------
// Mapping helpers — everything here is defensive: a bad key is skipped with
// a warning, not a throw.
// ---------------------------------------------------------------------------
function asTable(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v))
        return undefined;
    return v;
}
function asString(v) {
    return typeof v === 'string' ? v : undefined;
}
function asNumber(v) {
    return typeof v === 'number' ? v : undefined;
}
function asBool(v) {
    return typeof v === 'boolean' ? v : undefined;
}
function asStringArray(v) {
    if (!Array.isArray(v))
        return undefined;
    const out = [];
    for (const item of v) {
        if (typeof item === 'string')
            out.push(item);
    }
    return out.length ? out : undefined;
}
function mapToConfig(root, errors) {
    const out = {};
    const terminal = asTable(root.terminal);
    if (!terminal)
        return out;
    const t = {};
    const fontFamily = asString(terminal['font-family'] ?? terminal.fontFamily);
    if (fontFamily !== undefined)
        t.fontFamily = fontFamily;
    const fontSize = asNumber(terminal['font-size'] ?? terminal.fontSize);
    if (fontSize !== undefined)
        t.fontSize = fontSize;
    const cursorStyleRaw = asString(terminal['cursor-style'] ?? terminal.cursorStyle);
    if (cursorStyleRaw) {
        if (cursorStyleRaw === 'block' || cursorStyleRaw === 'underline' || cursorStyleRaw === 'bar') {
            t.cursorStyle = cursorStyleRaw;
        }
        else {
            errors.push(`terminal.cursor-style: "${cursorStyleRaw}" not one of block|underline|bar`);
        }
    }
    const cursorBlink = asBool(terminal['cursor-blink'] ?? terminal.cursorBlink);
    if (cursorBlink !== undefined)
        t.cursorBlink = cursorBlink;
    const scrollbackLines = asNumber(terminal['scrollback-lines'] ?? terminal.scrollbackLines);
    if (scrollbackLines !== undefined)
        t.scrollbackLines = scrollbackLines;
    const colors = asTable(terminal.colors);
    if (colors) {
        const defaultName = asString(colors.default ?? colors.theme);
        if (defaultName)
            t.theme = defaultName;
        const schemes = asTable(colors.schemes);
        if (schemes) {
            const userSchemes = {};
            for (const [name, value] of Object.entries(schemes)) {
                const schemeTable = asTable(value);
                if (!schemeTable) {
                    errors.push(`terminal.colors.schemes.${name}: expected table`);
                    continue;
                }
                const scheme = {};
                const bg = asString(schemeTable.background);
                if (bg)
                    scheme.background = bg;
                const fg = asString(schemeTable.foreground);
                if (fg)
                    scheme.foreground = fg;
                const cursor = asString(schemeTable.cursor ?? schemeTable['cursor-color']);
                if (cursor)
                    scheme.cursor = cursor;
                const cursorText = asString(schemeTable['cursor-text'] ?? schemeTable.cursorText);
                if (cursorText)
                    scheme.cursorText = cursorText;
                const selBg = asString(schemeTable['selection-background'] ?? schemeTable.selectionBackground);
                if (selBg)
                    scheme.selectionBackground = selBg;
                const selFg = asString(schemeTable['selection-foreground'] ?? schemeTable.selectionForeground);
                if (selFg)
                    scheme.selectionForeground = selFg;
                const palette = asStringArray(schemeTable.palette);
                if (palette)
                    scheme.palette = palette.slice(0, 16);
                if (Object.keys(scheme).length)
                    userSchemes[name] = scheme;
            }
            if (Object.keys(userSchemes).length)
                t.userColorSchemes = userSchemes;
        }
    }
    if (Object.keys(t).length)
        out.terminal = t;
    return out;
}

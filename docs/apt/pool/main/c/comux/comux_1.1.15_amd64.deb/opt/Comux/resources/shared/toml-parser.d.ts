/**
 * toml-parser.ts — Minimal TOML parser.
 *
 * Supports the subset we need for ~/.comux/config.toml:
 *   [table], [nested.table], [with."quoted.segment"]
 *   key = "string" | 'literal' | number | true | false | [array]
 *   # comments (ignored; preserved inside strings)
 *
 * Not supported (intentionally, to keep this hand-rolled parser small):
 *   Inline tables `{ a = 1 }`, datetime literals, multi-line strings,
 *   hex/oct/bin numbers, underscores inside numbers.
 *
 * Throws on malformed input so callers can decide whether to fall back
 * to defaults or surface an error.
 */
export type TomlValue = string | number | boolean | TomlValue[] | TomlTable;
export interface TomlTable {
    [key: string]: TomlValue;
}
export declare function parseToml(input: string): TomlTable;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROMPT_CLI_MAX_BYTES = void 0;
exports.shellQuoting = shellQuoting;
exports.quoteForShell = quoteForShell;
exports.buildAgentCommand = buildAgentCommand;
exports.seedAgentBaseline = seedAgentBaseline;
exports.planPromptDelivery = planPromptDelivery;
/**
 * Prompts longer than this (UTF-8 bytes) are pasted into the agent's TUI rather
 * than passed as a launch-command argument, which truncates long values. Kept
 * well under the Windows cmd.exe ~8 KB command-line limit for safety margin.
 */
exports.PROMPT_CLI_MAX_BYTES = 1500;
/** Pick a quoting dialect from a shell command/path. */
function shellQuoting(shell) {
    const s = (shell || '').toLowerCase();
    if (/(^|[\\/])(pwsh|powershell)(\.exe)?$/.test(s) || s.includes('powershell'))
        return 'powershell';
    if (/(^|[\\/])cmd(\.exe)?$/.test(s))
        return 'cmd';
    if (!s)
        return process.platform === 'win32' ? 'powershell' : 'posix';
    // bash/zsh/sh/fish/dash, including Git Bash on Windows.
    return 'posix';
}
/**
 * Quote `text` as a single argument for `style`.
 *
 * This used to be one hardcoded rule — wrap in single quotes, double any inner
 * single quote — which is PowerShell's convention. Under POSIX that rule is not
 * merely wrong, it is *silently* wrong: `'it''s'` is two adjacent quoted strings
 * that concatenate to `its`, so the apostrophe disappears from the prompt with no
 * error anywhere. Since the headless daemon's whole reason to exist is Linux/SSH,
 * that was the common case, not the exotic one. cmd.exe was worse still: single
 * quotes are not quoting characters there at all, so the agent received them as
 * literal text.
 */
function quoteForShell(text, style) {
    if (style === 'powershell')
        return `'${text.replace(/'/g, "''")}'`;
    if (style === 'cmd') {
        // cmd.exe's own convention for a literal quote inside a quoted string.
        // Caveat with no clean fix: cmd expands %VAR% even inside double quotes, so a
        // prompt naming a DEFINED environment variable can still be substituted.
        // Undefined names are passed through untouched, which covers ordinary prose.
        return `"${text.replace(/"/g, '""')}"`;
    }
    // POSIX: end the quoted run, emit an escaped quote, start a new run.
    return `'${text.replace(/'/g, "'\\''")}'`;
}
/** Build the shell command that starts `agent` in `mode`, optionally pre-seeded. */
function buildAgentCommand(agent, mode, prompt, 
/** Quoting dialect of the terminal this will be typed into. Callers should pass
 *  the shell they actually spawned; the default only guesses from the platform. */
quoting = shellQuoting(undefined)) {
    const quoted = prompt ? quoteForShell(prompt, quoting) : '';
    if (agent === 'codex') {
        const flags = mode === 'plan' ? '--sandbox read-only --ask-for-approval on-request'
            : mode === 'accept' ? '--full-auto'
                : '--dangerously-bypass-approvals-and-sandbox';
        let cmd = `codex ${flags}`;
        // `--` so a prompt starting with '-' is taken as the positional prompt, not
        // parsed as an option flag (else the CLI errors with "unknown option '-X'").
        if (quoted)
            cmd += ` -- ${quoted}`;
        return cmd;
    }
    if (agent === 'gemini') {
        const approval = mode === 'plan' ? 'default' : mode === 'accept' ? 'auto_edit' : 'yolo';
        let cmd = `gemini --approval-mode ${approval}`;
        // gemini seeds an interactive session from a prompt via -i.
        if (quoted)
            cmd += ` -i ${quoted}`;
        return cmd;
    }
    // claude (default)
    const permission = mode === 'plan' ? 'plan' : mode === 'accept' ? 'acceptEdits' : 'bypassPermissions';
    let cmd = `claude --permission-mode ${permission}`;
    // `--` so a prompt starting with '-' is taken as the positional prompt, not
    // parsed as an option flag (else claude errors with "unknown option '-X'").
    if (quoted)
        cmd += ` -- ${quoted}`;
    return cmd;
}
const READY_RE = /\?\s*for shortcuts|[│┃]\s*>|Welcome to Claude/i;
const WORKING_RE = /esc to interrupt/i;
const READY_TIMEOUT_MS = 25_000;
const START_TIMEOUT_MS = 20_000;
const NUDGE_INTERVAL_MS = 1_500;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/**
 * Deliver the prompt (pasting when it was too long for the command line), wait
 * until the agent is actually working, and return that screen as the baseline the
 * response wait diffs against. `promptToPaste` is null when the prompt already
 * went in on the launch command line.
 */
async function seedAgentBaseline(host, surfaceId, promptToPaste) {
    if (promptToPaste !== null) {
        // Wait for the idle input UI (Claude's shortcuts footer / input box).
        const t0 = Date.now();
        while (Date.now() - t0 < READY_TIMEOUT_MS) {
            if (!host.hasPty(surfaceId))
                return '';
            if (READY_RE.test(await host.readScreen(surfaceId)))
                break;
            await sleep(300);
        }
        await sleep(500); // let the input box finish painting / enable bracketed paste
        if (!host.hasPty(surfaceId))
            return '';
        // ESC[200~ … ESC[201~ — bracketed paste; the agent inserts it as one block.
        host.write(surfaceId, '\x1b[200~' + promptToPaste + '\x1b[201~');
        // Claude commits a large multi-line paste asynchronously; an Enter racing that
        // commit is dropped and the "[Pasted text … +N lines]" block sits unsubmitted.
        // Wait, then submit — the retry loop below re-sends Enter until it takes.
        await sleep(450);
        if (!host.hasPty(surfaceId))
            return '';
        host.write(surfaceId, '\r');
    }
    // Wait for the turn to actually start, then snapshot as the baseline. While the
    // paste may still be stranded in the input (Enter raced the paste commit), keep
    // nudging Enter until the agent reacts.
    const start = Date.now();
    let lastNudge = Date.now();
    while (Date.now() - start < START_TIMEOUT_MS) {
        if (!host.hasPty(surfaceId))
            return '';
        const screen = await host.readScreen(surfaceId);
        if (WORKING_RE.test(screen))
            return screen;
        // Re-send Enter every ~1.5s if nothing has started yet (only when we pasted).
        if (promptToPaste !== null && Date.now() - lastNudge >= NUDGE_INTERVAL_MS) {
            host.write(surfaceId, '\r');
            lastNudge = Date.now();
        }
        await sleep(250);
    }
    return await host.readScreen(surfaceId);
}
/**
 * Split a prompt into the part that can ride on the launch command line and the
 * part that must be pasted. Newlines are flattened for the command-line path — a
 * bare newline would submit early or break the single-quoted argument — while the
 * paste path keeps them, since bracketed paste inserts them literally.
 */
function planPromptDelivery(prompt) {
    if (!prompt)
        return { cliPrompt: '', pastePrompt: null };
    if (Buffer.byteLength(prompt, 'utf8') > exports.PROMPT_CLI_MAX_BYTES) {
        return { cliPrompt: '', pastePrompt: prompt };
    }
    return { cliPrompt: prompt.replace(/\r?\n/g, ' '), pastePrompt: null };
}

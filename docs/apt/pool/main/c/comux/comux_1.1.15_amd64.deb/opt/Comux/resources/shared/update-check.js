"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RELEASE_REPO = void 0;
exports.compareVersions = compareVersions;
exports.pickAsset = pickAsset;
exports.fetchLatestRelease = fetchLatestRelease;
exports.updateFrom = updateFrom;
exports.checkForUpdate = checkForUpdate;
exports.startUpdatePolling = startUpdatePolling;
/**
 * "Is there a newer comux?" — for every target, not just the Electron GUI.
 *
 * update-checker.ts (main) used to own this, but it imports electron and only
 * ever looked for the Windows zip. The headless daemon and the CLI need the same
 * answer, so the polling and the asset picking live here on plain `https`, and
 * the asset we care about follows the *install method* rather than the platform:
 * a deb install wants the .deb, an SSH bundle wants the tarball.
 *
 * Notify-only. Nothing here downloads or installs — see install-method.ts for
 * the command a given install upgrades with.
 */
const https_1 = __importDefault(require("https"));
const install_method_1 = require("./install-method");
exports.RELEASE_REPO = 'Jeonghyeon-Ryu/Comux-Release';
const LATEST_URL = `https://api.github.com/repos/${exports.RELEASE_REPO}/releases/latest`;
const DEFAULT_INTERVAL_MS = 6 * 60 * 60 * 1000;
const DEFAULT_FIRST_DELAY_MS = 5_000;
const FETCH_TIMEOUT_MS = 10_000;
const MAX_BODY_BYTES = 1_000_000;
/** `a` newer than `b` → 1, older → -1, same → 0. Ignores a leading "v". */
function compareVersions(a, b) {
    const parts = (v) => v.replace(/^v/, '').split('.').map((n) => parseInt(n, 10) || 0);
    const pa = parts(a);
    const pb = parts(b);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const x = pa[i] || 0;
        const y = pb[i] || 0;
        if (x > y)
            return 1;
        if (x < y)
            return -1;
    }
    return 0;
}
/** The asset a given install should be pointed at. */
const ASSET_PATTERN = {
    zip: /win.*x64.*\.zip$/i,
    deb: /_amd64\.deb$/i,
    appimage: /\.AppImage$/i,
    script: /^comux-tui-.*-linux-x64\.tar\.gz$/i,
    tarball: /^comux-tui-.*-linux-x64\.tar\.gz$/i,
    dev: null,
    unknown: null,
};
function pickAsset(assets, method) {
    const pattern = ASSET_PATTERN[method];
    if (!pattern)
        return undefined;
    return assets.find((a) => pattern.test(a.name));
}
function fetchLatestRelease(userAgent) {
    return new Promise((resolve) => {
        let settled = false;
        const done = (v) => { if (!settled) {
            settled = true;
            resolve(v);
        } };
        const req = https_1.default.get(LATEST_URL, { headers: { Accept: 'application/vnd.github+json', 'User-Agent': userAgent }, timeout: FETCH_TIMEOUT_MS }, (res) => {
            if (res.statusCode !== 200) {
                res.resume();
                done(null);
                return;
            }
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => {
                body += chunk;
                if (body.length > MAX_BODY_BYTES) {
                    req.destroy();
                    done(null);
                }
            });
            res.on('end', () => {
                try {
                    done(JSON.parse(body));
                }
                catch {
                    done(null);
                }
            });
            res.on('error', () => done(null));
        });
        req.on('timeout', () => req.destroy());
        req.on('error', () => done(null));
    });
}
/** Resolve `release` against the running version. null when already current. */
function updateFrom(release, opts) {
    if (!release || release.draft || release.prerelease || !release.tag_name)
        return null;
    if (compareVersions(release.tag_name, opts.currentVersion) <= 0)
        return null;
    const asset = pickAsset(release.assets ?? [], opts.method);
    // A release that ships nothing this install can use is not an update for it.
    // Releases here are per-platform (v1.1.1 was Linux-only), and the version line
    // is shared, so a Windows 1.0.19 saw "1.1.1 > 1.0.19" and offered an update
    // whose page has no Windows build on it. Only stay quiet when we KNOW what to
    // look for — 'dev'/'unknown' have no pattern and are still told.
    if (ASSET_PATTERN[opts.method] && !asset)
        return null;
    return {
        version: release.tag_name.replace(/^v/, ''),
        url: release.html_url,
        body: release.body,
        publishedAt: release.published_at,
        assetUrl: asset?.browser_download_url,
        assetName: asset?.name,
        method: opts.method,
        upgradeCommand: opts.upgradeCommand,
        autoInstallable: opts.autoInstallable,
        downloadPage: install_method_1.DOWNLOAD_PAGE,
    };
}
async function checkForUpdate(opts) {
    return updateFrom(await fetchLatestRelease(`comux/${opts.currentVersion}`), opts);
}
/**
 * Poll for updates until the returned stop() is called. Fires `onUpdate` each
 * time a *newer* version than the last one reported is seen, so a long-running
 * daemon picks up a second release without a restart.
 */
function startUpdatePolling(opts) {
    let last = null;
    const tick = async () => {
        const info = await checkForUpdate(opts).catch(() => null);
        if (!info)
            return;
        if (last && compareVersions(info.version, last) <= 0)
            return;
        last = info.version;
        opts.onUpdate(info);
    };
    const first = setTimeout(() => { void tick(); }, opts.firstDelayMs ?? DEFAULT_FIRST_DELAY_MS);
    const timer = setInterval(() => { void tick(); }, opts.intervalMs ?? DEFAULT_INTERVAL_MS);
    first.unref?.();
    timer.unref?.();
    return () => { clearTimeout(first); clearInterval(timer); };
}

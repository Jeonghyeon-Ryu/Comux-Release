export type ShellKind = 'powershell' | 'cmd' | 'wsl' | 'bash' | 'zsh' | 'unknown';
/** Classify a shell command/path. Matches on the basename so a directory that
 *  happens to contain "cmd" or "zsh" cannot misclassify the shell. */
export declare function shellKind(shell: string): ShellKind;
export interface ShellActivation {
    /** Extra argv for the shell process. */
    args: string[];
    /** Extra environment for the shell process. */
    env: Record<string, string>;
}
/**
 * Argv + env that make `shell` load the integration from `integrationDir`.
 * Returns nothing to add when the shell is not bash/zsh, or when the files are
 * missing (a dev tree without a build, a bundle that did not stage them) — a
 * missing integration must degrade to a plain shell, never to a broken one.
 */
export declare function activateShellIntegration(shell: string, integrationDir: string): ShellActivation;

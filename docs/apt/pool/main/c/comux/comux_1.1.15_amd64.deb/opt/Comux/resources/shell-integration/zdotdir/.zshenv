# comux zsh shim — first of four; see .zshrc for the whole story.
#
# NOTE: ZDOTDIR deliberately still points at this directory. zsh re-reads it
# before every startup file, so restoring the user's value here would make zsh
# look for .zshrc next to their own files and skip our shim entirely. .zshrc
# restores it once the integration is loaded.

if [ -f "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zshenv" ]; then
    source "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zshenv"
fi

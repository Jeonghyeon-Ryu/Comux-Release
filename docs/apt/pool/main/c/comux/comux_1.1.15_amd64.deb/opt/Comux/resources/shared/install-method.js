"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DOWNLOAD_PAGE = void 0;
exports.detectInstallMethod = detectInstallMethod;
/**
 * How was this copy of comux installed?
 *
 * comux ships five ways — a Windows portable zip, a Linux .deb (APT), a Linux
 * AppImage, the headless TUI bundle via install.sh, and the same bundle unpacked
 * by hand — and each upgrades differently. Only the Windows zip can replace
 * itself in place (update-installer.ts); everything else needs the user to run
 * one command, and telling them the *wrong* one is worse than saying nothing.
 *
 * Kept electron-free so the headless daemon and the CLI can use it too.
 */
const path_1 = __importDefault(require("path"));
const os_1 = __importDefault(require("os"));
const fs_1 = __importDefault(require("fs"));
exports.DOWNLOAD_PAGE = 'https://jeonghyeon-ryu.github.io/Comux-Release/';
const INSTALL_SH = `curl -fsSL ${exports.DOWNLOAD_PAGE}install.sh | sh`;
const APT_UPGRADE = 'sudo apt update && sudo apt install --only-upgrade comux';
const UPGRADE = {
    zip: null, // handled in-process
    deb: APT_UPGRADE,
    appimage: null, // no package manager — download the new AppImage
    script: INSTALL_SH, // re-running the installer overwrites in place
    tarball: INSTALL_SH,
    dev: null,
    unknown: null,
};
function defaultEnv() {
    return {
        platform: process.platform,
        execPath: process.execPath,
        moduleDir: __dirname,
        home: os_1.default.homedir(),
        appImage: process.env.APPIMAGE,
        electron: !!process.versions.electron,
    };
}
function detectInstallMethod(partial = {}) {
    const env = { ...defaultEnv(), ...partial };
    const exists = env.exists ?? fs_1.default.existsSync;
    const method = classify(env, exists);
    return {
        method,
        upgradeCommand: UPGRADE[method],
        autoInstallable: method === 'zip',
        root: env.electron ? path_1.default.dirname(env.execPath) : bundleRoot(env),
    };
}
/** …/dist/shared → the bundle/repo root two levels up. */
function bundleRoot(env) {
    return path_1.default.resolve(env.moduleDir, '..', '..');
}
function classify(env, exists) {
    // The AppImage runtime advertises itself, and its mount point is a temp dir —
    // so check this before anything path-based.
    if (env.appImage)
        return 'appimage';
    if (env.electron) {
        if (env.packaged === false)
            return 'dev';
        if (env.platform === 'win32')
            return 'zip';
        // electron-builder's deb installs under /opt/<ProductName>. An unpacked
        // build run straight out of a build dir lands nowhere in particular.
        if (env.platform === 'linux') {
            return isInside(env.execPath, '/opt') ? 'deb' : 'unknown';
        }
        return 'unknown';
    }
    // Plain Node: the headless bundle, a source checkout, or the GUI's packaged
    // CLI — which ships at <install>/resources/cli and is run by a shim, so
    // `electron` is false even though it belongs to a desktop install.
    const root = bundleRoot(env);
    if (exists(path_1.default.join(root, 'src')) && exists(path_1.default.join(root, 'tsconfig.json')))
        return 'dev';
    if (samePath(root, path_1.default.join(env.home, '.local', 'share', 'comux')))
        return 'script';
    if (exists(path_1.default.join(root, 'run.sh')))
        return 'tarball';
    // …<install>/resources/shared → two levels up is the app folder itself.
    if (env.platform === 'win32' && exists(path_1.default.join(root, 'comux.exe')))
        return 'zip';
    if (env.platform === 'linux' && isInside(root, '/opt'))
        return 'deb';
    return 'unknown';
}
function normalize(p) {
    const n = path_1.default.resolve(p).replace(/[\\/]+$/, '');
    return process.platform === 'win32' ? n.toLowerCase() : n;
}
function samePath(a, b) {
    return normalize(a) === normalize(b);
}
function isInside(child, parent) {
    const rel = path_1.default.relative(normalize(parent), normalize(child));
    return !!rel && !rel.startsWith('..') && !path_1.default.isAbsolute(rel);
}

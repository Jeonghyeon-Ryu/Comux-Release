import { branchSlug } from './worktree-names';
export { branchSlug };
export type WorktreeErrorCode = 'no_git' | 'not_a_repo' | 'bad_branch' | 'path_exists' | 'in_use' | 'dirty' | 'not_found' | 'busy' | 'git';
export declare class WorktreeError extends Error {
    readonly code: WorktreeErrorCode;
    readonly changes?: number | undefined;
    constructor(message: string, code?: WorktreeErrorCode, changes?: number | undefined);
}
/** Same file system path? Case-insensitive on Windows, where git prints `C:/x` and node `C:\x`. */
export declare function samePath(a: string, b: string): boolean;
/** The folder new worktrees of this repo go in. */
export declare function worktreeRootFor(mainRoot: string, dir?: string): string;
/** `<root>/<slug>`, or `<slug>-2`, `-3`… when that folder is already taken. */
export declare function uniqueChildPath(root: string, slug: string, exists?: (p: string) => boolean): string;
export interface RepoInfo {
    /** Top of the checkout `cwd` is in — may itself be a worktree. */
    root: string;
    /** Main checkout every worktree of this repo hangs off. */
    mainRoot: string;
    /** Current branch of `root`; null when detached. */
    branch: string | null;
}
export declare function resolveRepo(cwd: string): Promise<RepoInfo>;
export interface WorktreeEntry {
    path: string;
    head: string | null;
    branch: string | null;
    bare: boolean;
    detached: boolean;
    locked: boolean;
    prunable: boolean;
}
/** Parse `git worktree list --porcelain`. Paths are returned as git printed them. */
export declare function parseWorktreeList(out: string): WorktreeEntry[];
export declare function listWorktrees(cwd: string): Promise<WorktreeEntry[]>;
/** Tracked-file changes + untracked files (ignored files do not count). */
export declare function worktreeChanges(dir: string): Promise<number>;
export interface WorktreeConfig {
    /** Setup commands for this platform, in order. */
    setup: string[];
    /** Where new worktrees go, relative to the main checkout. */
    dir?: string;
    /** Set when `.comux/worktree.json` exists but could not be used. */
    error?: string;
}
export declare const WORKTREE_CONFIG_FILE: string;
export declare const WORKTREE_INCLUDE_FILE = ".worktreeinclude";
export declare function readWorktreeConfig(root: string, platform?: NodeJS.Platform): WorktreeConfig;
/** Untracked files in `sourceRoot` that `.worktreeinclude` asks to carry over. */
export declare function listIncludeFiles(sourceRoot: string): Promise<string[]>;
export interface CopyLimits {
    maxFiles: number;
    maxBytes: number;
}
export declare const DEFAULT_COPY_LIMITS: CopyLimits;
/** Copy `files` (relative) from one checkout to another. Never overwrites. */
export declare function copyIncludeFiles(sourceRoot: string, destRoot: string, files: string[], limits?: CopyLimits): Promise<{
    copied: number;
    skipped: number;
    bytes: number;
}>;
export interface CreateWorktreeOptions {
    /** Any folder inside the repository (the CLI sends its own cwd). */
    cwd: string;
    branch: string;
    /** Start point for a NEW branch. Default: HEAD of the checkout `cwd` is in. */
    base?: string;
    /** Explicit folder. Default: `<repo>.worktrees/<branch-slug>`. */
    path?: string;
    copyLimits?: CopyLimits;
}
export interface CreateWorktreeResult {
    path: string;
    branch: string;
    /** Main checkout. */
    repoRoot: string;
    /** Checkout the worktree was made from (where `.worktreeinclude` was read). */
    sourceRoot: string;
    /** Ref a new branch started from; null when an existing branch was checked out. */
    base: string | null;
    createdBranch: boolean;
    /** The branch already had a worktree — it is returned instead of a second one. */
    reused: boolean;
    copied: number;
    copySkipped: number;
    /** Setup commands the repo defines (NOT run here). */
    setup: string[];
    configError?: string;
}
export declare function createWorktree(o: CreateWorktreeOptions): Promise<CreateWorktreeResult>;
export interface RemoveWorktreeOptions {
    path: string;
    /** Remove even with uncommitted changes (they are lost). */
    force?: boolean;
    /** Also `git branch -d` — only succeeds when the branch is merged. */
    deleteBranch?: boolean;
    /** Retries for Windows file locks; a dying shell can hold its cwd a moment. */
    retries?: number;
    retryDelayMs?: number;
}
export interface RemoveWorktreeResult {
    path: string;
    branch: string | null;
    branchDeleted: boolean;
    /** Why the branch was kept, when deletion was asked for. */
    branchKept?: string;
}
/** Find the worktree a path names, from inside it or from its repository. */
export declare function findWorktree(target: string, repoHint?: string): Promise<{
    entry: WorktreeEntry;
    mainRoot: string;
}>;
export declare function removeWorktree(o: RemoveWorktreeOptions & {
    repoHint?: string;
}): Promise<RemoveWorktreeResult>;

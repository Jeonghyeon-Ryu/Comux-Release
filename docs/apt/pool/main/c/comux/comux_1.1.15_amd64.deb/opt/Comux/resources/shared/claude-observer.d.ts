/**
 * Claude Code terminal output observer.
 * Parses PTY data streams for Claude Code patterns (agents, skills, tools,
 * spinner/turn-summary lines) and feeds edge-triggered signals into the
 * surface-status state machine — the single source of truth every consumer
 * (tab dots, fleet dashboard, attention router, REST API) reads.
 *
 * This module is a pure parser: it owns no status state of its own (only the
 * per-surface tail buffer for waiting detection and the parsed agents list).
 */
import { SurfaceId } from './types';
export type { AgentActivity } from './surface-status';
/**
 * Process a chunk of PTY data for Claude Code patterns.
 * Called from the main process whenever PTY data flows through.
 */
export declare function observePtyData(surfaceId: SurfaceId, data: string): void;
/**
 * Clear parser state for a surface (when its terminal closes). The machine's
 * record is cleared separately via surface-status.clearSurface().
 */
export declare function clearActivity(surfaceId: SurfaceId): void;

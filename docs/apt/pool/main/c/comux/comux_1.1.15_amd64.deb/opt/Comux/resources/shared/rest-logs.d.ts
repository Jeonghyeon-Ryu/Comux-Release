import { RestApiLogEntry } from './types';
/**
 * Rough token estimate (no tokenizer is bundled). Latin-ish text averages ~4
 * chars/token; CJK/Hangul averages closer to ~1 token/char. Good enough for a
 * usage gauge, intentionally labeled "estimated" in the UI.
 */
export declare function estimateTokens(text: string): number;
/** Append one usage event. id + timestamp are filled in here. */
export declare function appendRestLog(entry: Omit<RestApiLogEntry, 'id' | 'timestamp'>): void;
/** Return all logs, newest first. */
export declare function getRestLogs(): RestApiLogEntry[];
/** Wipe the log. */
export declare function clearRestLogs(): void;

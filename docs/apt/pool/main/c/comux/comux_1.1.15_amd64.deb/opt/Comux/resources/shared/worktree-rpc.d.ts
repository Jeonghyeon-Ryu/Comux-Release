/**
 * The `worktree.*` V2 methods, written once for both hosts.
 *
 * main and comuxd each supply a small WorktreeHost (how to make a workspace,
 * how to type into its shell); everything else — which checkout, which
 * workspace owns it, when it is safe to delete — lives here, so the two hosts
 * cannot drift the way markdown.set_content once did.
 */
import type { WorkspaceId, WorkspaceInfo, WorkspaceWorktree } from './types';
export interface WorktreeHost {
    workspaces(): readonly WorkspaceInfo[];
    /** Create a workspace on `cwd`; returns it and its first terminal. */
    createWorkspace(o: {
        title: string;
        cwd: string;
        worktree: WorkspaceWorktree;
    }): {
        workspaceId: WorkspaceId;
        surfaceId: string | null;
    };
    selectWorkspace(id: WorkspaceId): void;
    closeWorkspace(id: WorkspaceId): void;
    /** Type `text` into a terminal once its shell is at a prompt. */
    typeWhenReady(surfaceId: string, text: string): void;
    /** How long a closed workspace's shells take to die (they hold the folder open). */
    ptyReleaseMs: number;
}
export declare const WORKTREE_METHODS: readonly ["worktree.create", "worktree.list", "worktree.remove", "worktree.inspect"];
/** JSON-RPC error carrying a WorktreeError's code, so the CLI can say why. */
export declare class WorktreeRpcError extends Error {
    readonly rpcCode: number;
    readonly data?: Record<string, unknown> | undefined;
    constructor(message: string, rpcCode: number, data?: Record<string, unknown> | undefined);
}
/** Lines to type into a shell: one command per line works in every shell, `&&` does not (PowerShell 5.1). */
export declare function setupKeystrokes(commands: string[]): string;
export declare function handleWorktreeRpc(method: string, p: Record<string, any>, host: WorktreeHost): Promise<unknown>;

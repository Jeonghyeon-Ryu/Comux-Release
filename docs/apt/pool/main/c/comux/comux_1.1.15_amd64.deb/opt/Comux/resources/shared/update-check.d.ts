import { InstallMethod } from './install-method';
export declare const RELEASE_REPO = "Jeonghyeon-Ryu/Comux-Release";
export interface ReleaseAsset {
    name: string;
    browser_download_url: string;
}
export interface Release {
    tag_name: string;
    html_url: string;
    body?: string;
    published_at?: string;
    draft?: boolean;
    prerelease?: boolean;
    assets?: ReleaseAsset[];
}
export interface UpdateInfo {
    /** Version of the newest release, without the leading "v". */
    version: string;
    /** GitHub release page. */
    url: string;
    body?: string;
    publishedAt?: string;
    /** Download URL of the asset matching how comux was installed, if published. */
    assetUrl?: string;
    assetName?: string;
    /** How this copy was installed, and the command that upgrades it. */
    method: InstallMethod;
    upgradeCommand: string | null;
    /** True when comux can install this itself (Windows portable zip only). */
    autoInstallable: boolean;
    /** Where to send someone with no upgrade command. */
    downloadPage: string;
}
/** `a` newer than `b` → 1, older → -1, same → 0. Ignores a leading "v". */
export declare function compareVersions(a: string, b: string): number;
export declare function pickAsset(assets: ReleaseAsset[], method: InstallMethod): ReleaseAsset | undefined;
export declare function fetchLatestRelease(userAgent: string): Promise<Release | null>;
export interface CheckOptions {
    currentVersion: string;
    method: InstallMethod;
    upgradeCommand: string | null;
    autoInstallable: boolean;
}
/** Resolve `release` against the running version. null when already current. */
export declare function updateFrom(release: Release | null, opts: CheckOptions): UpdateInfo | null;
export declare function checkForUpdate(opts: CheckOptions): Promise<UpdateInfo | null>;
export interface PollOptions extends CheckOptions {
    onUpdate: (info: UpdateInfo) => void;
    intervalMs?: number;
    firstDelayMs?: number;
}
/**
 * Poll for updates until the returned stop() is called. Fires `onUpdate` each
 * time a *newer* version than the last one reported is seen, so a long-running
 * daemon picks up a second release without a restart.
 */
export declare function startUpdatePolling(opts: PollOptions): () => void;

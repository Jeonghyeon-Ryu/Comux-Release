#!/usr/bin/env node
// orch.js — the comux orchestration scheduler.
//
//   node orch.js start    <orch-dir>          validate the plan, lay out panes, start every ready agent
//   node orch.js wait     <orch-dir> [--timeout S]   block until something happens (the orchestrator's loop)
//   node orch.js status   <orch-dir>          one table of every agent
//   node orch.js complete <orch-dir> <agent> [--failed REASON]   mark an agent done by hand
//   node orch.js resolved <orch-dir> <agent>  a merge conflict was fixed by hand — continue
//   node orch.js finish   <orch-dir>          mark the run complete
//   node orch.js cleanup  <orch-dir> [--keep-worktrees]   stop agents, remove their worktrees
//   node orch.js stop-hook | tool-use         Claude Code hooks (read the hook JSON on stdin)
//
// Agents are a dependency graph (orch-core.js): one starts as soon as the
// agents it depends on are done — no wave barrier. "Done" is EVENT-driven: a
// Claude worker's Stop hook reports it the moment it finishes (after checking
// its result file exists — the evidence gate), and any CLI's result file is
// noticed by `wait`. Interactive agents never exit on their own, so waiting
// for the process to end (the old loop) never ended.
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync, spawnSync } = require('child_process');
const core = require('./orch-core');

const MAX_STOP_BLOCKS = 2;

// ─── small I/O helpers ────────────────────────────────────────────────────────

const now = () => new Date().toISOString();
const sleep = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);

function statePath(dir) { return path.join(dir, 'state.json'); }

function readState(dir) {
  return JSON.parse(fs.readFileSync(statePath(dir), 'utf8'));
}

function writeState(dir, state) {
  const tmp = statePath(dir) + `.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, statePath(dir));
}

/** The same lock file json-tool.js / orchestration-state.sh use. */
function withState(dir, fn) {
  const lock = path.join(dir, 'state.lock');
  const until = Date.now() + 10_000;
  for (;;) {
    try { fs.writeFileSync(lock, String(process.pid), { flag: 'wx' }); break; } catch {
      try { if (Date.now() - fs.statSync(lock).mtimeMs > 30_000) { fs.rmSync(lock, { force: true }); continue; } } catch { continue; }
      if (Date.now() > until) throw new Error(`state is locked (${lock})`);
      sleep(50);
    }
  }
  try {
    const state = readState(dir);
    const out = fn(state);
    writeState(dir, state);
    return out;
  } finally {
    try { fs.rmSync(lock, { force: true }); } catch { /* */ }
  }
}

function emit(dir, ev) {
  fs.appendFileSync(path.join(dir, 'events.jsonl'), JSON.stringify({ at: now(), ...ev }) + '\n');
}

function readEvents(dir) {
  try {
    return fs.readFileSync(path.join(dir, 'events.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  } catch { return []; }
}

/** The comux CLI: COMUX_CLI (set in every comux shell) is the script itself. */
function comux(args, { json = true, timeout = 60_000 } = {}) {
  const cliJs = process.env.COMUX_CLI;
  let out;
  if (cliJs && fs.existsSync(cliJs)) {
    out = execFileSync(process.execPath, [cliJs, ...args], { encoding: 'utf8', timeout, stdio: ['ignore', 'pipe', 'pipe'] });
  } else if (process.platform === 'win32') {
    const line = ['comux', ...args].map((a) => `"${String(a).replace(/"/g, '\\"')}"`).join(' ');
    out = execFileSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `"${line}"`], { encoding: 'utf8', timeout, windowsVerbatimArguments: true, stdio: ['ignore', 'pipe', 'pipe'] });
  } else {
    out = execFileSync('comux', args, { encoding: 'utf8', timeout, stdio: ['ignore', 'pipe', 'pipe'] });
  }
  return json ? JSON.parse(out) : out;
}

function comuxAvailable() {
  try { return comux(['ping'], { json: false, timeout: 8000 }).trim() === 'pong'; } catch { return false; }
}

function git(cwd, args) {
  const r = spawnSync('git', args, { cwd, encoding: 'utf8', windowsHide: true });
  return { code: r.status ?? -1, out: (r.stdout || '').trim(), err: (r.stderr || '').trim() };
}

const installedCache = new Map();
function isInstalled(cli) {
  if (installedCache.has(cli)) return installedCache.get(cli);
  const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [cli], { encoding: 'utf8', windowsHide: true });
  const ok = r.status === 0;
  installedCache.set(cli, ok);
  return ok;
}

/** Category → CLI lists: ~/.comux/orchestrator.json, overridden by <project>/.comux/orchestrator.json. */
function loadConfig(cwd) {
  const read = (p) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return {}; } };
  const user = read(path.join(os.homedir(), '.comux', 'orchestrator.json'));
  const proj = cwd ? read(path.join(cwd, '.comux', 'orchestrator.json')) : {};
  return { ...user, ...proj, categories: { ...(user.categories || {}), ...(proj.categories || {}) } };
}

function fileInfo(p) {
  try { const st = fs.statSync(p); return { text: fs.readFileSync(p, 'utf8'), mtimeMs: st.mtimeMs }; } catch { return { text: null, mtimeMs: 0 }; }
}

// ─── spawning ─────────────────────────────────────────────────────────────────

/** A pane from the run's grid with nothing of ours running in it (or the least busy one). */
function pickPane(state) {
  const panes = state.agentPanes || [];
  if (!panes.length) return null;
  const busy = new Map(panes.map((p) => [p, 0]));
  for (const a of core.allAgents(state)) if (a.status === 'running' && busy.has(a.paneId)) busy.set(a.paneId, busy.get(a.paneId) + 1);
  if (state.reviewer && state.reviewer.status === 'running' && busy.has(state.reviewer.paneId)) busy.set(state.reviewer.paneId, busy.get(state.reviewer.paneId) + 1);
  return [...busy.entries()].sort((a, b) => a[1] - b[1])[0][0];
}

const RUNTIME_MARK = '<!-- comux-orch runtime -->';

/** Tell the worker what the scheduler set up for it (once, at the end of its prompt). */
function addRuntimeNotes(promptFile, state, agent) {
  const text = fs.readFileSync(promptFile, 'utf8');
  if (text.includes(RUNTIME_MARK)) return;
  const lines = ['', RUNTIME_MARK, '## Runtime'];
  if (agent.worktreePath) {
    lines.push(`You work in your OWN git worktree: \`${agent.worktreePath}\` (branch \`${agent.branch}\`). Other agents cannot see your edits until you finish — the orchestrator then commits everything in this folder and merges your branch. Do not \`cd\` back to the main checkout, and do not switch branches.`);
  }
  lines.push(`You are finished only when your result file exists at \`${agent.resultFile}\` with the sections above. Stopping without it sends you back to work.`);
  fs.writeFileSync(promptFile, text.replace(/\s*$/, '\n') + lines.join('\n') + '\n');
}

function spawnOne(dir, state, agent, config, promptFile, label) {
  const { cli, why } = core.chooseCli(agent, config, isInstalled);
  let cwd = state.cwd || process.cwd();
  if (state.useWorktrees && agent.id !== 'reviewer') {
    if (!agent.worktreePath) {
      const wt = comux(['worktree', 'create', `orch/${state.id}/${agent.id}`, '--no-workspace', '--cwd', state.cwd], { timeout: 180_000 });
      agent.worktreePath = wt.path;
      agent.branch = wt.branch;
    }
    cwd = agent.worktreePath;
  }
  if (!fs.existsSync(promptFile)) throw new Error(`missing prompt file ${promptFile}`);
  if (agent.id !== 'reviewer') addRuntimeNotes(promptFile, state, agent);
  const launcher = path.join(__dirname, 'launch-agent.js');
  const cmd = `node "${launcher}" "${promptFile}" --cli ${cli} --orch-dir "${dir}" --orch-agent ${agent.id}`;
  const pane = pickPane(state);
  const r = comux(['agent', 'spawn', '--cmd', cmd, '--label', label, '--cwd', cwd, ...(pane ? ['--pane', pane] : [])]);
  Object.assign(agent, {
    status: 'running', startedAt: now(), finishedAt: null, paneId: pane, surfaceId: r.surfaceId,
    comuxAgentId: r.agentId, cli, cliReason: why, stopBlocks: 0, toolUses: agent.toolUses || 0,
  });
  emit(dir, { type: 'started', agent: agent.id, cli, ...(agent.branch ? { branch: agent.branch } : {}) });
}

function spawnAgent(dir, state, agent, config) {
  if (!agent.resultFile) agent.resultFile = path.join(dir, `agent-${agent.id}-result.md`);
  spawnOne(dir, state, agent, config, path.join(dir, `agent-${agent.id}-prompt.md`), agent.label || agent.id);
}

function reviewerPrompt(dir, state) {
  const parts = [
    `# Mission: Review orchestration ${state.id}`,
    '',
    `The task was: ${state.task}`,
    '',
    'Several agents worked on it in parallel. Their own reports are below — treat every claim in them as unverified until you have checked it in the code.',
    '',
  ];
  for (const a of core.allAgents(state)) {
    const r = fileInfo(a.resultFile || '');
    parts.push(`## ${a.label || a.id} (${a.id}) — ${a.status}${a.mergeStatus ? `, merge: ${a.mergeStatus}` : ''}`, '', r.text ? r.text.trim() : '_No result file._', '');
  }
  parts.push(
    '## What to do',
    '1. Read the diff of the whole run (`git diff` / `git log` in this repository) against the task.',
    '2. Run the project\'s build and tests.',
    '3. Check the pieces fit: names, types and interfaces the agents shared, nothing half-done (TODOs, stubs), nothing outside the task.',
    '4. Fix only small, certain problems yourself; list everything else.',
    '',
    `Write your report to \`${state.reviewer.reportFile}\`: a "### Summary", a "### Findings" list (each with file:line and why), a "### Tests" section with the commands you ran and their results, and as the LAST line exactly \`VERDICT: PASS\` or \`VERDICT: FAIL — <the failed criterion>\`. Approve unless you can name a concrete failed criterion.`,
  );
  const file = path.join(dir, 'reviewer-prompt.md');
  fs.writeFileSync(file, parts.join('\n') + '\n');
  return file;
}

// ─── merging (worktree mode) ──────────────────────────────────────────────────

/**
 * Commit everything the agent left in its worktree and merge its branch into
 * the main checkout. Bookkeeping commits skip the repo's hooks (`--no-verify`):
 * they are intermediate commits on a throwaway branch — the review and the
 * user's own commit run the hooks. A conflict aborts the merge and stops this
 * agent's dependents until `orch.js resolved`.
 */
function mergeAgent(state, agent) {
  const wt = agent.worktreePath;
  if (!wt || !agent.branch) return;
  git(wt, ['add', '-A']);
  if (git(wt, ['diff', '--cached', '--quiet']).code !== 0) {
    const c = git(wt, ['commit', '--no-verify', '-m', `orch(${state.id}): ${agent.label || agent.id}`]);
    if (c.code !== 0) { agent.mergeStatus = 'conflict'; agent.mergeError = `commit failed: ${c.err || c.out}`; return; }
  }
  const ahead = git(state.cwd, ['rev-list', '--count', `HEAD..${agent.branch}`]);
  if (ahead.code === 0 && ahead.out === '0') { agent.mergeStatus = 'empty'; return; }
  const m = git(state.cwd, ['merge', '--no-ff', '--no-edit', '-m', `orch(${state.id}): merge ${agent.label || agent.id}`, agent.branch]);
  if (m.code === 0) { agent.mergeStatus = 'merged'; delete agent.mergeError; return; }
  git(state.cwd, ['merge', '--abort']);
  agent.mergeStatus = 'conflict';
  agent.mergeError = (m.out + '\n' + m.err).trim().split('\n').slice(-8).join('\n');
}

// ─── state transitions ────────────────────────────────────────────────────────

function finishAgent(dir, state, agent, { failed, reason, source }) {
  agent.status = failed ? 'failed' : 'exited';
  agent.exitCode = failed ? 1 : 0;
  agent.finishedAt = now();
  if (reason) agent.failReason = reason;
  emit(dir, { type: failed ? 'failed' : 'done', agent: agent.id, ...(reason ? { reason } : {}), source });
  if (!failed && state.useWorktrees) {
    mergeAgent(state, agent);
    emit(dir, { type: `merge-${agent.mergeStatus}`, agent: agent.id, ...(agent.mergeError ? { detail: agent.mergeError } : {}) });
  }
}

/** Start whatever became ready; when nothing can move any more, say so (once). */
function advance(dir) {
  let summary = null;
  withState(dir, (state) => {
    if (state.status !== 'running') return;
    const config = loadConfig(state.cwd);
    for (const agent of core.readyAgents(state)) {
      try { spawnAgent(dir, state, agent, config); } catch (e) {
        agent.status = 'failed';
        agent.exitCode = 1;
        agent.failReason = `could not start: ${e.message}`;
        emit(dir, { type: 'failed', agent: agent.id, reason: agent.failReason, source: 'spawn' });
      }
    }
    core.refreshWaves(state);
    if (!core.settled(state) || state.settledAt) return;
    state.settledAt = now();
    const all = core.allAgents(state);
    const failed = all.filter(core.isFailed).map((a) => a.id);
    const blocked = all.filter((a) => a.status === 'pending').map((a) => `${a.id} (${core.blockedReason(state, a)})`);
    const conflicts = all.filter((a) => a.mergeStatus === 'conflict').map((a) => a.id);
    if (failed.length || blocked.length || conflicts.length) {
      emit(dir, { type: 'stuck', failed, blocked, conflicts });
      return;
    }
    const rv = state.reviewer;
    if (rv && rv.status === 'pending') {
      if (rv.mode === 'agent') {
        try {
          const prompt = reviewerPrompt(dir, state);
          const reviewerAgent = { id: 'reviewer', cli: rv.cli, category: rv.cli ? undefined : 'review' };
          spawnOne(dir, state, reviewerAgent, config, prompt, 'reviewer');
          Object.assign(rv, { status: 'running', surfaceId: reviewerAgent.surfaceId, paneId: reviewerAgent.paneId, comuxAgentId: reviewerAgent.comuxAgentId, cli: reviewerAgent.cli, startedAt: reviewerAgent.startedAt });
        } catch (e) {
          rv.status = 'ready';
          emit(dir, { type: 'review-failed-to-start', reason: e.message });
        }
      } else {
        rv.status = 'ready';
      }
    }
    emit(dir, { type: 'all-done', reviewer: rv ? rv.status : null });
    summary = 'all-done';
  });
  updateDashboard(dir);
  if (summary) notify(dir, 'All orchestration agents are done.');
  return summary;
}

function notify(dir, text) {
  try { comux(['notify', text], { json: false, timeout: 8000 }); } catch { /* not in comux */ }
}

/** Complete agents whose result appeared (non-Claude CLIs), or whose process ended. */
function poll(dir) {
  const changed = [];
  withState(dir, (state) => {
    for (const agent of core.allAgents(state)) {
      if (agent.status !== 'running') continue;
      const r = fileInfo(agent.resultFile || '');
      const res = core.checkResult(r.text, r.mtimeMs, Date.parse(agent.startedAt || '') || 0);
      // A Claude worker is completed by its Stop hook, which also gates on the
      // result — a report written early must not release its dependents while
      // it is still working. Other CLIs have no such hook: a valid result that
      // has stopped changing is their signal.
      const stable = r.mtimeMs && Date.now() - r.mtimeMs > 4000;
      let exited = false;
      if (agent.comuxAgentId) {
        try { exited = comux(['agent', 'status', agent.comuxAgentId], { timeout: 8000 }).status === 'exited'; } catch { /* */ }
      }
      if (res.ok && (exited || (agent.cli && agent.cli !== 'claude' && stable))) {
        finishAgent(dir, state, agent, { failed: false, source: exited ? 'exit' : 'result-file' });
        changed.push(agent.id);
      } else if (exited) {
        finishAgent(dir, state, agent, { failed: true, reason: `the agent exited without a valid result (${res.reason || 'unknown'})`, source: 'exit' });
        changed.push(agent.id);
      }
    }
    const rv = state.reviewer;
    if (rv && rv.status === 'running' && rv.reportFile) {
      const r = fileInfo(rv.reportFile);
      const verdict = r.text && (r.text.match(/^VERDICT:.*$/m) || [])[0];
      if (verdict && Date.now() - r.mtimeMs > 4000) {
        rv.status = 'complete';
        rv.verdict = verdict.trim();
        rv.finishedAt = now();
        emit(dir, { type: 'review-done', verdict: rv.verdict });
        changed.push('reviewer');
      }
    }
  });
  if (changed.length) advance(dir);
  return changed;
}

// ─── dashboard ────────────────────────────────────────────────────────────────

function dashboardMarkdown(state) {
  const all = core.allAgents(state);
  const done = all.filter(core.isDone).length;
  const lines = [`# Orchestration: ${state.task || state.id}`, ''];
  lines.push(`**${done}/${all.length} done** · running ${all.filter((a) => a.status === 'running').length} · failed ${all.filter(core.isFailed).length}${state.useWorktrees ? ' · worktrees on' : ''}`);
  const cp = core.criticalPath(state);
  if (cp.length > 1) lines.push(`Critical path: ${cp.join(' → ')}`);
  lines.push('', '| Agent | Status | CLI | After | Merge | Tools |', '|---|---|---|---|---|---|');
  for (const a of all) {
    const blocked = a.status === 'pending' ? core.blockedReason(state, a) : null;
    const st = blocked ? `blocked (${blocked})` : a.status;
    lines.push(`| ${a.label || a.id} | ${st} | ${a.cli || a.category || '-'} | ${(a.dependsOn || []).join(', ') || '-'} | ${a.mergeStatus || '-'} | ${a.toolUses || 0} |`);
  }
  if (state.reviewer) lines.push('', `Reviewer: ${state.reviewer.status}${state.reviewer.cli ? ` (${state.reviewer.cli})` : ''}${state.reviewer.verdict ? ` — ${state.reviewer.verdict}` : ''}`);
  return lines.join('\n') + '\n';
}

function updateDashboard(dir) {
  try {
    const state = readState(dir);
    const md = dashboardMarkdown(state);
    const file = path.join(dir, 'dashboard.md');
    fs.writeFileSync(file, md);
    if (state.dashboardSurfaceId) comux(['markdown', 'set', state.dashboardSurfaceId, '--file', file], { json: false, timeout: 8000 });
  } catch { /* best effort */ }
}

function statusTable(state) {
  const rows = core.allAgents(state).map((a) => {
    const blocked = a.status === 'pending' ? core.blockedReason(state, a) : null;
    const waiting = a.status === 'pending' && !blocked ? (a.dependsOn || []).filter((id) => { const f = core.findAgent(state, id); return f && !core.depSatisfied(state, f.agent); }) : [];
    const what = blocked ? `blocked: ${blocked}` : waiting.length ? `waiting for ${waiting.join(', ')}` : a.status;
    return `  ${a.id.padEnd(12)} ${what.padEnd(34)} ${(a.cli || '').padEnd(7)} ${a.mergeStatus ? `merge ${a.mergeStatus}` : ''}${a.failReason ? `  (${a.failReason})` : ''}`;
  });
  const rv = state.reviewer ? `  reviewer     ${state.reviewer.status}${state.reviewer.verdict ? ` — ${state.reviewer.verdict}` : ''}` : '';
  return [`Orchestration ${state.id}: ${state.status}`, ...rows, rv].filter(Boolean).join('\n');
}

// ─── commands ─────────────────────────────────────────────────────────────────

/** A Git Bash `/c/Users/...` path means nothing to node.exe or git on Windows. */
function nativePath(p) {
  if (process.platform === 'win32' && typeof p === 'string') {
    const m = /^\/([a-zA-Z])(\/.*)?$/.exec(p);
    if (m) return `${m[1].toUpperCase()}:${m[2] || '/'}`;
  }
  return p;
}

function cmdStart(dir) {
  withState(dir, (state) => {
    core.normalizePlan(state);
    if (state.cwd) state.cwd = nativePath(state.cwd);
    const config = loadConfig(state.cwd);
    state.maxParallel = state.maxParallel || config.maxParallel || 5;
    state.status = 'running';
    state.startedAt = state.startedAt || now();
    if (!state.cwd) state.cwd = process.cwd();
    if (process.env.COMUX_SURFACE_ID) state.orchestratorSurfaceId = process.env.COMUX_SURFACE_ID;
    for (const a of core.allAgents(state)) {
      if (!a.status) a.status = 'pending';
      if (!a.resultFile) a.resultFile = path.join(dir, `agent-${a.id}-result.md`);
    }
    if (state.reviewer && !state.reviewer.reportFile) state.reviewer.reportFile = path.join(dir, 'review-report.md');
    delete state.settledAt;
    if (!state.agentPanes || !state.agentPanes.length) {
      // One grid for the whole run, sized to how many can run at once — the
      // orchestrator keeps its cell; agents reuse freed cells as they go.
      const cells = Math.min(state.maxParallel, Math.max(1, core.maxWidth(state)));
      try {
        const g = comux(['layout', 'grid', '--count', String(cells + 1), '--type', 'terminal']);
        state.agentPanes = g.newPaneIds || [];
      } catch (e) {
        state.agentPanes = [];
        emit(dir, { type: 'note', detail: `layout grid failed, agents go into existing panes: ${e.message}` });
      }
    }
    emit(dir, { type: 'run-started', agents: core.allAgents(state).length, worktrees: !!state.useWorktrees });
  });
  advance(dir);
  // start already printed what it did; the first `wait` reports what happens NEXT.
  fs.writeFileSync(path.join(dir, '.wait-cursor'), String(readEvents(dir).length));
  console.log(statusTable(readState(dir)));
}

function cmdWait(dir, timeoutS) {
  const cursorFile = path.join(dir, '.wait-cursor');
  let cursor = 0;
  try { cursor = Number(fs.readFileSync(cursorFile, 'utf8')) || 0; } catch { /* */ }
  const until = Date.now() + timeoutS * 1000;
  for (;;) {
    poll(dir);
    const events = readEvents(dir);
    const fresh = events.slice(cursor);
    const state = readState(dir);
    if (fresh.length) {
      fs.writeFileSync(cursorFile, String(events.length));
      console.log('Events:');
      for (const e of fresh) console.log(`  ${e.at.slice(11, 19)} ${e.type}${e.agent ? ` ${e.agent}` : ''}${e.cli ? ` [${e.cli}]` : ''}${e.reason ? ` — ${e.reason}` : ''}${e.detail ? `\n      ${String(e.detail).replace(/\n/g, '\n      ')}` : ''}${e.verdict ? ` — ${e.verdict}` : ''}${e.failed ? ` failed=[${e.failed}] blocked=[${e.blocked}] conflicts=[${e.conflicts}]` : ''}`);
      console.log('');
      console.log(statusTable(state));
      return;
    }
    if (Date.now() > until) {
      console.log(`No change in ${timeoutS}s — still working.`);
      console.log(statusTable(state));
      return;
    }
    sleep(3000);
  }
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

/**
 * Claude Code Stop hook. In a worker: the evidence gate, then completion. In
 * the orchestrator's own session: the old warning about running agents.
 */
function cmdStopHook() {
  let input = {};
  try { input = JSON.parse(readStdin() || '{}'); } catch { /* */ }
  const dir = process.env.COMUX_ORCH_DIR;
  const id = process.env.COMUX_ORCH_AGENT;
  if (!dir || !id || !fs.existsSync(statePath(dir))) return;

  let decision = null;
  let complete = false;
  withState(dir, (state) => {
    if (id === 'reviewer') return; // the reviewer is completed by its report (poll)
    const f = core.findAgent(state, id);
    if (!f || f.agent.status !== 'running') return;
    const agent = f.agent;
    const r = fileInfo(agent.resultFile || '');
    const res = core.checkResult(r.text, r.mtimeMs, Date.parse(agent.startedAt || '') || 0);
    if (res.ok) { complete = true; return; }
    // Capped, so a worker that stopped to ask the USER something is not
    // shoved back in forever; it stays running and is completed later.
    if ((agent.stopBlocks || 0) >= MAX_STOP_BLOCKS || (input.stop_hook_active && (agent.stopBlocks || 0) >= 1)) {
      emit(dir, { type: 'needs-attention', agent: id, reason: `stopped without a result file (${res.reason}) — it may be waiting for you` });
      return;
    }
    agent.stopBlocks = (agent.stopBlocks || 0) + 1;
    decision = {
      decision: 'block',
      reason: `You are not finished: ${res.reason}. Write your result file at ${agent.resultFile} using the format from your mission (### Summary, ### Files Modified, ### Interfaces/Types Changed, ### Tests, ### Risks), then stop. If you cannot complete the mission, write the result file anyway and explain why under ### Risks.`,
    };
  });
  if (complete) {
    withState(dir, (state) => {
      const f = core.findAgent(state, id);
      if (f && f.agent.status === 'running') finishAgent(dir, state, f.agent, { failed: false, source: 'stop-hook' });
    });
    advance(dir);
  }
  if (decision) process.stdout.write(JSON.stringify(decision));
}

function cmdToolUse() {
  const dir = process.env.COMUX_ORCH_DIR;
  const id = process.env.COMUX_ORCH_AGENT;
  if (!dir || !id || !fs.existsSync(statePath(dir))) return;
  let input = {};
  try { input = JSON.parse(readStdin() || '{}'); } catch { /* */ }
  let changed = false;
  withState(dir, (state) => {
    const f = core.findAgent(state, id);
    if (!f) return;
    f.agent.toolUses = (f.agent.toolUses || 0) + 1;
    if (input.tool_name) f.agent.lastTool = input.tool_name;
    changed = true;
  });
  if (changed) updateDashboard(dir);
}

function cmdComplete(dir, id, failedReason) {
  withState(dir, (state) => {
    const f = core.findAgent(state, id);
    if (!f) throw new Error(`no agent ${id}`);
    finishAgent(dir, state, f.agent, { failed: failedReason != null, reason: failedReason || undefined, source: 'manual' });
  });
  advance(dir);
  console.log(statusTable(readState(dir)));
}

function cmdResolved(dir, id) {
  withState(dir, (state) => {
    const f = core.findAgent(state, id);
    if (!f) throw new Error(`no agent ${id}`);
    f.agent.mergeStatus = 'merged';
    delete f.agent.mergeError;
    delete state.settledAt;
    emit(dir, { type: 'merge-resolved', agent: id });
  });
  advance(dir);
  console.log(statusTable(readState(dir)));
}

function cmdFinish(dir) {
  withState(dir, (state) => {
    state.status = core.allAgents(state).some(core.isFailed) ? 'failed' : 'complete';
    state.finishedAt = now();
  });
  updateDashboard(dir);
  console.log(statusTable(readState(dir)));
}

function cmdCleanup(dir, keepWorktrees) {
  const state = readState(dir);
  const out = [];
  const targets = [...core.allAgents(state), ...(state.reviewer ? [state.reviewer] : [])];
  for (const a of targets) {
    if (a.comuxAgentId) { try { comux(['agent', 'kill', a.comuxAgentId], { timeout: 8000 }); out.push(`stopped ${a.id || 'reviewer'}`); } catch { /* already gone */ } }
  }
  if (!keepWorktrees) {
    for (const a of core.allAgents(state)) {
      if (!a.branch) continue;
      try {
        comux(['worktree', 'remove', a.branch, '--delete-branch', '--cwd', state.cwd], { timeout: 120_000 });
        out.push(`removed worktree ${a.branch}`);
      } catch (e) { out.push(`kept worktree ${a.branch}: ${String(e.stderr || e.message).split('\n').find(Boolean)}`); }
    }
  }
  console.log(out.join('\n') || 'nothing to clean up');
}

function main() {
  const [cmd, dir, ...rest] = process.argv.slice(2);
  const flag = (n) => { const i = rest.indexOf(n); return i === -1 ? undefined : rest[i + 1]; };
  switch (cmd) {
    case 'start': return cmdStart(dir);
    case 'wait': return cmdWait(dir, Math.min(Number(flag('--timeout')) || 540, 580));
    case 'poll': poll(dir); return console.log(statusTable(readState(dir)));
    case 'advance': advance(dir); return console.log(statusTable(readState(dir)));
    case 'status': return console.log(statusTable(readState(dir)));
    case 'complete': return cmdComplete(dir, rest[0], rest.includes('--failed') ? (flag('--failed') || 'marked failed') : null);
    case 'resolved': return cmdResolved(dir, rest[0]);
    case 'finish': return cmdFinish(dir);
    case 'cleanup': return cmdCleanup(dir, rest.includes('--keep-worktrees'));
    case 'dashboard': return process.stdout.write(dashboardMarkdown(readState(dir)));
    case 'stop-hook': return cmdStopHook();
    case 'tool-use': return cmdToolUse();
    default:
      console.error('usage: orch.js start|wait|status|poll|advance|complete|resolved|finish|cleanup|dashboard <orch-dir> …  |  orch.js stop-hook|tool-use');
      process.exit(1);
  }
}

if (require.main === module) {
  try { main(); } catch (e) {
    // A hook must never fail the session it runs in.
    if (process.argv[2] === 'stop-hook' || process.argv[2] === 'tool-use') process.exit(0);
    console.error(`orch.js: ${e.message}`);
    process.exit(1);
  }
}

module.exports = { dashboardMarkdown, statusTable, mergeAgent };

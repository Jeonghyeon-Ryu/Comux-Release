#!/usr/bin/env bash
# PostToolUse hook: count tool uses for the orchestrated worker this session is.
# COMUX_ORCH_AGENT (set by launch-agent.js) names the plan entry — comux's own
# COMUX_AGENT_ID is the process id comux gave it and never matched the plan,
# which is why this counter used to stay at 0 in comux mode.
[ -z "${COMUX_ORCH_AGENT:-}" ] && exit 0
[ -z "${COMUX_ORCH_DIR:-}" ] && exit 0
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
node "$SCRIPT_DIR/orch.js" tool-use
exit 0

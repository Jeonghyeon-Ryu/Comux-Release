"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMPTY_BUCKETS = void 0;
exports.emptyBuckets = emptyBuckets;
exports.addBuckets = addBuckets;
exports.bucketsTotal = bucketsTotal;
exports.bucketsInput = bucketsInput;
exports.EMPTY_BUCKETS = { fresh: 0, cachedRead: 0, cacheWrite: 0, output: 0 };
function emptyBuckets() {
    return { fresh: 0, cachedRead: 0, cacheWrite: 0, output: 0 };
}
/** Add `src` into `dst` in place. */
function addBuckets(dst, src) {
    dst.fresh += src.fresh;
    dst.cachedRead += src.cachedRead;
    dst.cacheWrite += src.cacheWrite;
    dst.output += src.output;
}
/**
 * Every token the model actually processed for this work.
 *
 * Includes `cachedRead`: a cache hit is cheaper, not absent — the tokens are
 * still part of the prompt the model read. This is the number to show when the
 * question is "how much did I use", as distinct from a cost estimate, where the
 * four buckets carry different per-token rates and must stay separate.
 */
function bucketsTotal(b) {
    return b.fresh + b.cachedRead + b.cacheWrite + b.output;
}
/** Input-side only (everything that was in the prompt, cached or not). */
function bucketsInput(b) {
    return b.fresh + b.cachedRead + b.cacheWrite;
}

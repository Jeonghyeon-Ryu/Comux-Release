"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.instanceSuffix = instanceSuffix;
exports.getPipePath = getPipePath;
exports.getAppDataDir = getAppDataDir;
/**
 * comux instance identity.
 *
 * Set COMUX_INSTANCE=<name> to run comux as a separate, side-by-side instance:
 * the named pipe and APPDATA directory get a "-<name>" suffix, so a dev build
 * can run alongside an installed production comux without colliding on the
 * pipe (Windows pipes are exclusive) or overwriting session.json.
 */
const path_1 = __importDefault(require("path"));
const os_1 = __importDefault(require("os"));
/** "-<name>" for an isolated instance (COMUX_INSTANCE, or any dev run); "" for the installed app. */
function instanceSuffix() {
    const name = process.env.COMUX_INSTANCE?.trim();
    if (name)
        return `-${name}`;
    // Auto-isolate dev runs. Electron sets `process.defaultApp` only when launched
    // as `electron .` (unpackaged) — never in a packaged build — so a dev session
    // gets its own `comux-dev` data dir + `\\.\pipe\comux-dev` and can NEVER clobber
    // the installed production comux's session.json (the "npm run dev wipes my
    // sessions" bug). Packaged releases fall through to the unsuffixed prod paths.
    if (process.defaultApp)
        return '-dev';
    return '';
}
function getPipePath() {
    // Windows: named pipe (exclusive; the OS reclaims it when the owner exits).
    if (process.platform === 'win32') {
        return `\\\\.\\pipe\\comux${instanceSuffix()}`;
    }
    // POSIX: a Unix-domain-socket path. Node's net.createServer/net.connect treat
    // this exactly like the Windows pipe path, so every server/client that calls
    // getPipePath() follows automatically. Prefer the per-user runtime dir
    // ($XDG_RUNTIME_DIR — tmpfs, mode 0700) so the socket isn't world-readable;
    // fall back to os.tmpdir() on systems without it (non-systemd/remote sessions).
    const runtimeBase = process.env.XDG_RUNTIME_DIR || os_1.default.tmpdir();
    return path_1.default.join(runtimeBase, `comux${instanceSuffix()}.sock`);
}
function getAppDataDir() {
    // Windows: %APPDATA%\comux (unchanged — byte-identical to the original path).
    if (process.platform === 'win32') {
        const base = process.env.APPDATA || path_1.default.join(os_1.default.homedir(), 'AppData', 'Roaming');
        return path_1.default.join(base, `comux${instanceSuffix()}`);
    }
    // macOS: ~/Library/Application Support/comux.
    if (process.platform === 'darwin') {
        return path_1.default.join(os_1.default.homedir(), 'Library', 'Application Support', `comux${instanceSuffix()}`);
    }
    // Linux/other POSIX: XDG base-dir spec ($XDG_CONFIG_HOME, default ~/.config).
    const base = process.env.XDG_CONFIG_HOME || path_1.default.join(os_1.default.homedir(), '.config');
    return path_1.default.join(base, `comux${instanceSuffix()}`);
}

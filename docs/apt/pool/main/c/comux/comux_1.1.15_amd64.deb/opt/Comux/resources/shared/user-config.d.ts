export interface UserColorScheme {
    background?: string;
    foreground?: string;
    cursor?: string;
    cursorText?: string;
    selectionBackground?: string;
    selectionForeground?: string;
    palette?: string[];
}
export interface UserConfig {
    terminal?: {
        fontFamily?: string;
        fontSize?: number;
        theme?: string;
        cursorStyle?: 'block' | 'underline' | 'bar';
        cursorBlink?: boolean;
        scrollbackLines?: number;
        userColorSchemes?: Record<string, UserColorScheme>;
    };
    /** Absolute path the config was read from (for diagnostics). */
    path?: string;
    /** Any parse or mapping errors — non-fatal, surfaced to the renderer. */
    errors?: string[];
}
export declare function getConfigPath(): string;
export declare function loadUserConfig(filePath?: string): UserConfig;

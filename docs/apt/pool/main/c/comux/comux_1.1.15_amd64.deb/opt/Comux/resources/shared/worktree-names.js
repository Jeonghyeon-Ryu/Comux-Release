"use strict";
/**
 * Pure worktree naming, split from worktree.ts (which needs child_process and
 * fs) so the renderer's new-worktree dialog can preview the exact folder name
 * the host will use.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.branchSlug = branchSlug;
const WINDOWS_RESERVED = /^(con|prn|aux|nul|com\d|lpt\d)$/i;
/** A branch name as one folder name: `feature/login` → `feature-login`. */
function branchSlug(branch) {
    let s = branch
        .replace(/^refs\/heads\//, '')
        .replace(/[\\/]+/g, '-')
        .replace(/[^A-Za-z0-9._-]+/g, '-')
        .replace(/-{2,}/g, '-')
        .replace(/^[-.]+|[-.]+$/g, '');
    if (!s)
        s = 'worktree';
    if (WINDOWS_RESERVED.test(s))
        s = `wt-${s}`;
    return s.slice(0, 60).replace(/[-.]+$/, '') || 'worktree';
}

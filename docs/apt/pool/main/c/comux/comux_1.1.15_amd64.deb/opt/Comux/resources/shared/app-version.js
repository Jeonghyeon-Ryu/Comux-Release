"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.appVersion = appVersion;
/**
 * The running comux version, without needing electron's `app.getVersion()`.
 *
 * package.json sits at the root of every shipped layout — the asar, the headless
 * TUI bundle, and a source checkout — and this module compiles to dist/shared, so
 * the root is normally two levels up.
 *
 * The exception is the GUI's packaged CLI: electron-builder copies it out to
 * `resources/cli/comux.js`, where nothing sits two levels up but the real version
 * lives inside the asar. Whoever launches that copy (cli-delegate, pty-manager)
 * passes COMUX_APP_VERSION, which wins.
 */
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
let cached = null;
function appVersion() {
    if (cached)
        return cached;
    const injected = process.env.COMUX_APP_VERSION?.trim();
    if (injected) {
        cached = injected;
        return cached;
    }
    try {
        const pkg = path_1.default.resolve(__dirname, '..', '..', 'package.json');
        const parsed = JSON.parse(fs_1.default.readFileSync(pkg, 'utf8'));
        cached = parsed.version || '0.0.0';
    }
    catch {
        cached = '0.0.0';
    }
    return cached;
}

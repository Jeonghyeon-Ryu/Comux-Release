interface GitState {
    branch: string | null;
    dirty: boolean;
}
export declare class GitPoller {
    private watchers;
    private callback;
    onUpdate(callback: (cwd: string, state: GitState) => void): void;
    /**
     * Start watching a directory's .git/HEAD for branch changes.
     */
    watch(cwd: string): void;
    unwatch(cwd: string): void;
    unwatchAll(): void;
    private pollGitState;
}
export {};

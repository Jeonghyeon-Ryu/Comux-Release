---
name: comux-detect
description: Detect if comux terminal multiplexer is running. Used internally by orchestrate skill to decide between comux multi-pane mode and degraded subagent mode.
---

# comux Detection

First, resolve the plugin root (not available as env var in main session):

```bash
PLUGIN_ROOT=$(find "$HOME/.claude/plugins/cache" -path "*comux-orchestrator*/.claude-plugin/plugin.json" 2>/dev/null | sort -V | tail -1 | sed 's|/.claude-plugin/plugin.json||')
```

Run the detection script to check if comux is available:

```bash
bash "$PLUGIN_ROOT/scripts/detect-comux.sh"
```

**If output is "available":**
- comux is running and the named pipe is accessible
- The orchestrator can use `comux split`, `comux agent spawn`, `comux markdown set` etc.
- Full multi-pane visual experience is available

**If output is "unavailable":**
- comux is not running or not installed
- Fall back to Claude Code's native `Agent` tool for parallel workers
- No visual dashboard — use text summaries in the terminal instead
- Log: "comux not detected. Running in degraded mode — agents will use Claude Code's native subagent system. Install comux for the full multi-pane experience: https://comux.org"

Store the detection result so other skills can check it without re-running:

```bash
export COMUX_AVAILABLE=$( bash "$PLUGIN_ROOT/scripts/detect-comux.sh" 2>/dev/null && echo "true" || echo "false" )
```

**ENFORCEMENT:**
- When `COMUX_AVAILABLE=true`: ALL agents MUST be spawned via `comux agent spawn`. Do NOT use Claude Code's `Agent` tool. The Agent tool creates invisible subagents — the user chose comux specifically to SEE agents in panes.
- When `COMUX_AVAILABLE=false`: Use Claude Code's `Agent` tool with `subagent_type: "comux-orchestrator:comux-worker"`.
- Never mix modes within an orchestration.

"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PipeServer = void 0;
const net_1 = __importDefault(require("net"));
const fs_1 = __importDefault(require("fs"));
const crypto_1 = __importDefault(require("crypto"));
const events_1 = require("events");
// Backstop against a newline-less client growing main-process memory without
// bound (the pipe is unauthenticated, so any local process can connect). Large
// enough for legitimate single-line V2 payloads (e.g. markdown.set_content).
const MAX_LINE_BYTES = 16 * 1024 * 1024;
class PipeServer extends events_1.EventEmitter {
    server = null;
    pipePath;
    // When set, every V2 request must carry a matching `token` (constant-time
    // compared). Empty ⇒ auth disabled (the GUI + default daemon — file-permission
    // guarded). The daemon opts in via COMUXD_REQUIRE_TOKEN.
    authToken;
    constructor(pipePath = '\\\\.\\pipe\\comux', opts = {}) {
        super();
        this.pipePath = pipePath;
        this.authToken = opts.token || '';
    }
    tokenOk(provided) {
        if (!this.authToken)
            return true;
        if (typeof provided !== 'string' || provided.length !== this.authToken.length)
            return false;
        try {
            return crypto_1.default.timingSafeEqual(Buffer.from(provided), Buffer.from(this.authToken));
        }
        catch {
            return false;
        }
    }
    start() {
        this.server = net_1.default.createServer((socket) => {
            let buffer = '';
            socket.on('data', (data) => {
                buffer += data.toString();
                // Drop a client that floods bytes without ever sending a newline.
                if (buffer.length > MAX_LINE_BYTES) {
                    socket.destroy();
                    return;
                }
                // Process complete lines
                let newlineIdx;
                while ((newlineIdx = buffer.indexOf('\n')) !== -1) {
                    const line = buffer.substring(0, newlineIdx).trim();
                    buffer = buffer.substring(newlineIdx + 1);
                    if (!line)
                        continue;
                    // Try JSON-RPC (V2) first
                    if (line.startsWith('{')) {
                        try {
                            const request = JSON.parse(line);
                            this.handleV2(request, socket);
                        }
                        catch {
                            socket.write(JSON.stringify({ error: { code: -32700, message: 'Parse error' } }) + '\n');
                        }
                    }
                    else {
                        // V1 text protocol
                        this.handleV1(line, socket);
                    }
                }
            });
            socket.on('error', () => {
                // Client disconnected, ignore
            });
        });
        this.server.listen(this.pipePath, () => {
            // The V2 control channel can read files, run JS in the webview and inject
            // keystrokes into terminals, so who may CONNECT is the whole access model.
            // Node creates the socket under the process umask (0755 on a stock box),
            // and getPipePath() falls back from $XDG_RUNTIME_DIR (0700 tmpfs) to
            // os.tmpdir() — which is world-writable — whenever there is no runtime dir,
            // i.e. on exactly the non-systemd and remote sessions the daemon targets.
            // Nothing chmodded it. This is the only thing between another local account
            // and the socket when the fallback is in play.
            if (process.platform !== 'win32') {
                try {
                    fs_1.default.chmodSync(this.pipePath, 0o600);
                }
                catch { /* best effort */ }
            }
            console.log(`comux pipe server listening on ${this.pipePath}`);
        });
        this.server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                // The endpoint is taken. Probe it: if a live server answers, another
                // comux instance owns it — back off and do nothing. If the connection is
                // refused, it's a stale endpoint we should reclaim. On Windows a named
                // pipe vanishes with its owner, so a retry suffices; on POSIX a
                // Unix-socket inode survives a crash/SIGKILL as a leftover file, so it
                // must be unlinked before listen() can rebind (otherwise: permanent
                // EADDRINUSE — the pipe never comes back).
                const probe = net_1.default.connect({ path: this.pipePath });
                probe.on('connect', () => probe.destroy()); // live owner — leave it alone
                probe.on('error', () => {
                    probe.destroy();
                    this.server?.close();
                    if (process.platform !== 'win32') {
                        try {
                            fs_1.default.unlinkSync(this.pipePath);
                        }
                        catch { /* already gone */ }
                    }
                    setTimeout(() => this.start(), 250);
                });
            }
        });
    }
    stop() {
        this.server?.close();
        this.server = null;
    }
    handleV1(line, socket) {
        // Parse command and surfaceId from fixed positions, then handle args
        // per-command to avoid breaking paths that contain spaces (e.g. OneDrive).
        const firstSpace = line.indexOf(' ');
        const command = firstSpace === -1 ? line : line.substring(0, firstSpace);
        const rest = firstSpace === -1 ? '' : line.substring(firstSpace + 1);
        const secondSpace = rest.indexOf(' ');
        const surfaceId = secondSpace === -1 ? rest : rest.substring(0, secondSpace);
        const argsRaw = secondSpace === -1 ? '' : rest.substring(secondSpace + 1).trim();
        let args;
        switch (command) {
            case 'report_pwd':
                // Single path argument — may contain spaces
                args = argsRaw ? [argsRaw] : [];
                break;
            case 'report_pr': {
                // format: <number> <state> <title...>  — title may contain spaces
                const prParts = argsRaw.split(/\s+/);
                args = prParts.length >= 3
                    ? [prParts[0], prParts[1], prParts.slice(2).join(' ')]
                    : prParts;
                break;
            }
            default:
                args = argsRaw ? argsRaw.split(/\s+/) : [];
                break;
        }
        const v1Command = { command, surfaceId, args };
        this.emit('v1', v1Command);
        // Respond with OK for simple commands
        if (command === 'ping') {
            socket.write('pong\n');
        }
        else {
            socket.write('ok\n');
        }
    }
    handleV2(request, socket) {
        const respond = (result) => {
            const response = { result, id: request.id };
            socket.write(JSON.stringify(response) + '\n');
        };
        const respondError = (code, message) => {
            const response = { error: { code, message }, id: request.id };
            socket.write(JSON.stringify(response) + '\n');
        };
        // Auth gate (no-op unless the server was constructed with a token).
        if (!this.tokenOk(request.token)) {
            respondError(-32001, 'unauthorized: missing or invalid token');
            return;
        }
        // Emit the V2 request and let handlers respond
        const handled = this.emit('v2', request, respond, respondError);
        if (!handled) {
            respondError(-32601, `Method not found: ${request.method}`);
        }
    }
}
exports.PipeServer = PipeServer;

/**
 * Starting an agent (claude/codex/gemini) for a REST endpoint, host-agnostic.
 *
 * The GUI grew this logic first, against BrowserWindow and ptyManager. The
 * headless daemon needs the identical behaviour — a REST endpoint that only works
 * when a desktop window is open is not much of a remote API — so the parts that
 * never needed electron live here and both hosts inject their own PTY access.
 *
 * Delivering the prompt is the fiddly half: agents echo a startup banner, commit
 * a large paste asynchronously, and swallow an Enter that races that commit. The
 * caller gets back the screen AS OF the moment the turn actually started, which
 * rest-server diffs against so a banner is never mistaken for the reply.
 */
import { RestEndpointAgent, RestEndpointMode } from './types';
/**
 * Prompts longer than this (UTF-8 bytes) are pasted into the agent's TUI rather
 * than passed as a launch-command argument, which truncates long values. Kept
 * well under the Windows cmd.exe ~8 KB command-line limit for safety margin.
 */
export declare const PROMPT_CLI_MAX_BYTES = 1500;
/**
 * How the shell that will RUN this command expects an argument to be quoted.
 * The command is typed into a live terminal, so it is parsed by whatever shell
 * that terminal is running — not by us.
 */
export type ShellQuoting = 'posix' | 'powershell' | 'cmd';
/** Pick a quoting dialect from a shell command/path. */
export declare function shellQuoting(shell: string | undefined): ShellQuoting;
/**
 * Quote `text` as a single argument for `style`.
 *
 * This used to be one hardcoded rule — wrap in single quotes, double any inner
 * single quote — which is PowerShell's convention. Under POSIX that rule is not
 * merely wrong, it is *silently* wrong: `'it''s'` is two adjacent quoted strings
 * that concatenate to `its`, so the apostrophe disappears from the prompt with no
 * error anywhere. Since the headless daemon's whole reason to exist is Linux/SSH,
 * that was the common case, not the exotic one. cmd.exe was worse still: single
 * quotes are not quoting characters there at all, so the agent received them as
 * literal text.
 */
export declare function quoteForShell(text: string, style: ShellQuoting): string;
/** Build the shell command that starts `agent` in `mode`, optionally pre-seeded. */
export declare function buildAgentCommand(agent: RestEndpointAgent, mode: RestEndpointMode, prompt: string, 
/** Quoting dialect of the terminal this will be typed into. Callers should pass
 *  the shell they actually spawned; the default only guesses from the platform. */
quoting?: ShellQuoting): string;
/** Whichever host owns the PTY — Electron's ptyManager or the daemon's map. */
export interface AgentSeedHost {
    hasPty: (surfaceId: string) => boolean;
    write: (surfaceId: string, data: string) => void;
    /** Newest rows of the terminal as plain text (ANSI stripped). */
    readScreen: (surfaceId: string) => Promise<string>;
}
/**
 * Deliver the prompt (pasting when it was too long for the command line), wait
 * until the agent is actually working, and return that screen as the baseline the
 * response wait diffs against. `promptToPaste` is null when the prompt already
 * went in on the launch command line.
 */
export declare function seedAgentBaseline(host: AgentSeedHost, surfaceId: string, promptToPaste: string | null): Promise<string>;
/**
 * Split a prompt into the part that can ride on the launch command line and the
 * part that must be pasted. Newlines are flattened for the command-line path — a
 * bare newline would submit early or break the single-quoted argument — while the
 * paste path keeps them, since bracketed paste inserts them literally.
 */
export declare function planPromptDelivery(prompt: string): {
    cliPrompt: string;
    pastePrompt: string | null;
};

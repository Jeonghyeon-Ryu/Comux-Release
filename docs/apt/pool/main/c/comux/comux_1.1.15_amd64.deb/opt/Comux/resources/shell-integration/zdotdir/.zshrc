# comux zsh shim — the one that matters.
#
# zsh has no `--init-file`, so comux points ZDOTDIR at this directory and ships a
# stand-in for each startup file. Each one sources the user's real file from
# COMUX_ZDOTDIR_ORIG, so their configuration runs exactly as it would have.
#
# ZDOTDIR stays pointed here until this file is done: zsh re-reads it before every
# startup file, so an early restore would send zsh looking for .zshrc beside the
# user's own files and our shim would never run. We put it back at the end, so
# anything the user runs afterwards sees the value they expect.

if [ -f "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zshrc" ]; then
    source "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zshrc"
fi

# comux's reporting goes on top of the user's config, so its precmd/preexec hooks
# wrap what they installed rather than being replaced by it.
if [ -n "${COMUX_SHELL_INTEGRATION:-}" ] && [ -f "$COMUX_SHELL_INTEGRATION" ]; then
    source "$COMUX_SHELL_INTEGRATION"
fi

# Hand ZDOTDIR back. Only if it is still ours — a user config that sets ZDOTDIR
# itself has made a deliberate choice we must not overwrite.
if [ "$ZDOTDIR" = "${0:A:h}" ]; then
    if [ -n "$COMUX_ZDOTDIR_ORIG" ]; then
        export ZDOTDIR="$COMUX_ZDOTDIR_ORIG"
    else
        unset ZDOTDIR
    fi
fi

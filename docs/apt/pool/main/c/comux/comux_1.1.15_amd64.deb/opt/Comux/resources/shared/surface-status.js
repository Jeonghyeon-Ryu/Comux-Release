"use strict";
/**
 * Surface Status — the single source of truth for per-surface agent state.
 *
 * Every producer (PTY observer patterns, Claude Code hooks, shell-integration
 * reports, external plugins) feeds edge-triggered signals into this machine;
 * every consumer (workspace tab dots, fleet dashboard, attention router, REST
 * API) reads the same per-surface record. This replaces the old "was there an
 * event in the last 5 seconds?" TTL heuristics, which starved during long tool
 * calls / thinking stretches and misreported working agents as idle.
 *
 * Claude-tier status ('working' | 'waiting' | 'done' | 'unknown') only changes
 * on explicit signals or the watchdog — it never decays client-side. Shell
 * state is tracked PER SURFACE (a sibling pane's prompt can no longer stomp
 * the Claude pane's state) and is used by consumers as the fallback tier when
 * no Claude state is live.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.setActivitySink = setActivitySink;
exports.onAttention = onAttention;
exports.signal = signal;
exports.touch = touch;
exports.noteResize = noteResize;
exports.clearSurface = clearSurface;
exports.getAllSnapshots = getAllSnapshots;
exports.getActivity = getActivity;
exports.applyExternalActivity = applyExternalActivity;
exports.onHookEvent = onHookEvent;
exports.runWatchdog = runWatchdog;
exports.startWatchdog = startWatchdog;
exports._resetForTests = _resetForTests;
let activitySink = null;
function setActivitySink(sink) { activitySink = sink; }
// 'working' demotes to 'unknown' after this long without working evidence.
// Claude Code repaints its spinner at least once per second while mid-turn, so
// a genuinely working agent never trips this; it exists so a killed/vanished
// agent can't stay 'working' forever.
const WORKING_TIMEOUT_MS = 30_000;
// Data-driven keepalive: while 'working', ANY PTY chunk refreshes the working
// signal — but only within this window of the last pattern match, so a surface
// that stopped printing recognizable Claude output (e.g. Claude died and the
// shell took over on a shell without integration) self-heals. Sized generously:
// a false 'working' costs seconds of wrong dot; a false 'idle' mid-turn is the
// exact bug this machine replaces.
const KEEPALIVE_WINDOW_MS = 120_000;
// ConPTY answers resizes with clear+repaint bursts that replay historical
// status lines; pattern-parsed done/waiting edges inside this window are
// discarded (working evidence and hook edges still pass).
const RESIZE_GUARD_MS = 1_500;
const WATCHDOG_INTERVAL_MS = 5_000;
const records = new Map();
const attentionListeners = [];
/** Register a listener for agent attention transitions. Returns an unsubscribe. */
function onAttention(cb) {
    attentionListeners.push(cb);
    return () => {
        const i = attentionListeners.indexOf(cb);
        if (i !== -1)
            attentionListeners.splice(i, 1);
    };
}
function emitAttention(ev) {
    for (const cb of attentionListeners) {
        try {
            cb(ev);
        }
        catch { /* a bad listener must not break the machine */ }
    }
}
function ensure(surfaceId, at) {
    let rec = records.get(surfaceId);
    if (!rec) {
        rec = {
            status: 'unknown',
            shellState: null,
            claude: false,
            agents: [],
            activeSkill: null,
            lastTool: null,
            lastUpdate: at,
            lastWorkingSignal: 0,
            lastPatternAt: 0,
            resizeGuardUntil: 0,
        };
        records.set(surfaceId, rec);
    }
    return rec;
}
function toSnapshot(rec) {
    return {
        status: rec.status,
        shellState: rec.shellState,
        claude: rec.claude,
        agents: rec.agents,
        activeSkill: rec.activeSkill,
        lastTool: rec.lastTool,
        lastUpdate: rec.lastUpdate,
    };
}
/** Emit a surface's snapshot (or null = record removed) to the injected sink. */
function broadcast(surfaceId, snap) {
    if (!activitySink)
        return;
    try {
        activitySink(surfaceId, snap);
    }
    catch { /* a bad sink must not break the machine */ }
}
/** Apply optional detail fields; returns true when anything changed.
 *  `tool: null` explicitly clears lastTool; `undefined` leaves it untouched. */
function applyDetails(rec, sig) {
    let changed = false;
    if (sig.tool !== undefined && sig.tool !== rec.lastTool) {
        rec.lastTool = sig.tool;
        changed = true;
    }
    if (sig.skill !== undefined && sig.skill !== rec.activeSkill) {
        rec.activeSkill = sig.skill;
        changed = true;
    }
    if (sig.agents !== undefined) {
        rec.agents = sig.agents;
        changed = true;
    }
    return changed;
}
/**
 * Feed one signal into the machine. Broadcasts (and emits attention) only on
 * genuine transitions or detail changes — steady-state working evidence just
 * refreshes the internal timestamps.
 */
function signal(surfaceId, sig, at = Date.now()) {
    const rec = ensure(surfaceId, at);
    let changed = false;
    let attention = null;
    switch (sig.type) {
        case 'working': {
            rec.claude = true;
            rec.lastWorkingSignal = at;
            rec.lastPatternAt = at;
            changed = applyDetails(rec, sig) || changed;
            if (rec.status !== 'working') {
                rec.status = 'working';
                changed = true;
            }
            break;
        }
        case 'waiting': {
            if (sig.via === 'pattern' && at < rec.resizeGuardUntil)
                return; // replayed history, not a real edge
            rec.claude = true;
            if (rec.status !== 'waiting') {
                rec.status = 'waiting';
                changed = true;
                attention = 'waiting';
            }
            break;
        }
        case 'done': {
            if (sig.via === 'pattern' && at < rec.resizeGuardUntil)
                return; // replayed history, not a real edge
            rec.claude = true;
            changed = applyDetails(rec, sig) || changed;
            if (rec.status !== 'done') {
                rec.status = 'done';
                rec.activeSkill = null;
                changed = true;
                attention = 'done';
            }
            break;
        }
        case 'detail': {
            rec.claude = true;
            changed = applyDetails(rec, sig);
            break;
        }
        case 'idle': {
            if (at < rec.resizeGuardUntil)
                return; // replayed banner/footer, not a real edge
            rec.claude = true;
            // 'done' persists — the fleet needs to see which agents FINISHED, and the
            // idle footer repaints immediately after every completed turn.
            if (rec.status !== 'idle' && rec.status !== 'done') {
                rec.status = 'idle';
                changed = true;
            }
            break;
        }
        case 'shell': {
            if (sig.state !== rec.shellState) {
                rec.shellState = sig.state;
                changed = true;
            }
            // A shell prompt/preexec report means the shell owns the terminal again —
            // whatever Claude session ran here is over. Demote so a frozen 'working'
            // or leftover 'done' can't outlive the session it described.
            if (rec.status !== 'unknown') {
                rec.status = 'unknown';
                changed = true;
            }
            break;
        }
    }
    if (changed) {
        rec.lastUpdate = at;
        broadcast(surfaceId, toSnapshot(rec));
    }
    if (attention) {
        emitAttention({ surfaceId, kind: attention, lastTool: rec.lastTool, at });
    }
}
/**
 * Data-driven keepalive: called for every PTY chunk. While a surface is
 * 'working', any output refreshes the working signal (ConPTY diff-repaints
 * don't always re-emit a matchable pattern), bounded by KEEPALIVE_WINDOW_MS
 * since the last real pattern match. Cheap and broadcast-free.
 */
function touch(surfaceId, at = Date.now()) {
    const rec = records.get(surfaceId);
    if (!rec || rec.status !== 'working')
        return;
    if (at - rec.lastPatternAt <= KEEPALIVE_WINDOW_MS)
        rec.lastWorkingSignal = at;
}
/** Note a PTY resize — pattern-parsed done/waiting edges are ignored briefly (replay guard). */
function noteResize(surfaceId, at = Date.now()) {
    const rec = records.get(surfaceId);
    if (rec)
        rec.resizeGuardUntil = at + RESIZE_GUARD_MS;
}
/** Drop a surface's record entirely (PTY exited) and tell the renderer. */
function clearSurface(surfaceId) {
    if (records.delete(surfaceId))
        broadcast(surfaceId, null);
}
/** Full snapshot for renderer reload seeding. */
function getAllSnapshots() {
    const out = {};
    for (const [id, rec] of records)
        out[id] = toSnapshot(rec);
    return out;
}
/**
 * Legacy accessor for the REST server. Defined only while Claude is actually
 * in evidence on the surface: plain shells stay undefined, and a surface whose
 * Claude session ended (shell demoted it to 'unknown' with the prompt back)
 * also reads undefined rather than a forever-"active but not done" ghost.
 */
function getActivity(surfaceId) {
    const rec = records.get(surfaceId);
    if (!rec || !rec.claude)
        return undefined;
    if (rec.status === 'unknown' && rec.shellState !== null)
        return undefined; // session over, shell owns the terminal
    // isDone semantics for API consumers: "not mid-turn" — true both after a
    // completed turn and for a session idling at its prompt.
    return { isDone: rec.status === 'done' || rec.status === 'idle', lastUpdate: rec.lastUpdate };
}
/**
 * Merge externally-sourced activity (e.g. the OpenCode plugin pushing over the
 * pipe) into the machine. Field semantics match the old observer API: only an
 * explicit isDone/waitingForInput value moves the status; detail-only pushes
 * (tool/skill/agents) never do.
 */
function applyExternalActivity(surfaceId, partial, at = Date.now()) {
    const details = {
        tool: partial.lastTool,
        skill: partial.activeSkill ?? undefined,
        agents: partial.agents,
    };
    if (partial.waitingForInput === true) {
        signal(surfaceId, { type: 'detail', ...details }, at);
        signal(surfaceId, { type: 'waiting' }, at);
        return;
    }
    if (partial.isDone === true) {
        signal(surfaceId, { type: 'done', ...details }, at);
        return;
    }
    if (partial.isDone === false || (partial.waitingForInput === false && records.get(surfaceId)?.status === 'waiting')) {
        // Explicitly active, or explicitly no-longer-waiting → the agent resumed.
        signal(surfaceId, { type: 'working', ...details }, at);
        return;
    }
    signal(surfaceId, { type: 'detail', ...details }, at);
}
/**
 * Route a Claude Code hook event (from the named pipe) into the machine.
 * Events without a surfaceId cannot be attributed and are ignored here —
 * misattributing them to whatever is focused is exactly the bug this replaces.
 */
function onHookEvent(params, at = Date.now()) {
    const surfaceId = params?.surfaceId;
    if (!surfaceId)
        return;
    const event = params.event || 'PostToolUse';
    switch (event) {
        case 'Stop':
            signal(surfaceId, { type: 'done' }, at);
            break;
        case 'Notification':
            signal(surfaceId, { type: 'waiting' }, at);
            break;
        case 'PreToolUse':
        case 'PostToolUse':
        case 'SubagentStop':
        case 'UserPromptSubmit':
        default:
            signal(surfaceId, { type: 'working', tool: params.tool || undefined }, at);
            break;
    }
}
/** Demote stale 'working' records; called on an interval (and from tests). */
function runWatchdog(at = Date.now()) {
    for (const [surfaceId, rec] of records) {
        if (rec.status === 'working' && at - rec.lastWorkingSignal > WORKING_TIMEOUT_MS) {
            rec.status = 'unknown';
            rec.lastUpdate = at;
            broadcast(surfaceId, toSnapshot(rec));
        }
    }
}
let watchdogTimer = null;
/** Start the periodic watchdog. Idempotent; call once from main startup. */
function startWatchdog() {
    if (watchdogTimer)
        return;
    watchdogTimer = setInterval(() => runWatchdog(), WATCHDOG_INTERVAL_MS);
}
/** Test-only: reset all machine state. */
function _resetForTests() {
    records.clear();
    attentionListeners.length = 0;
    activitySink = null;
    if (watchdogTimer) {
        clearInterval(watchdogTimer);
        watchdogTimer = null;
    }
}

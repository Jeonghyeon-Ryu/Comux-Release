import { EventEmitter } from 'events';
export interface V1Command {
    command: string;
    surfaceId: string;
    args: string[];
}
export interface V2Request {
    method: string;
    params: Record<string, any>;
    id?: string | number;
    /** Optional per-request auth token (checked only when the server was given one). */
    token?: string;
}
export interface V2Response {
    result?: any;
    error?: {
        code: number;
        message: string;
    };
    id?: string | number;
}
export declare class PipeServer extends EventEmitter {
    private server;
    private pipePath;
    private authToken;
    constructor(pipePath?: string, opts?: {
        token?: string;
    });
    private tokenOk;
    start(): void;
    stop(): void;
    private handleV1;
    private handleV2;
}

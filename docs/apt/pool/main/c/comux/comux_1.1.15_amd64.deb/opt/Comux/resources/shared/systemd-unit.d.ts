/**
 * A systemd unit for comuxd, so a server keeps its shells across logouts and
 * reboots instead of needing someone to start the daemon by hand.
 *
 * It is a USER unit, not a system one, and that is not a stylistic choice: the
 * daemon owns that user's shells, spawns them as that user, and puts its socket
 * in $XDG_RUNTIME_DIR. Running it as root under a system unit would give every
 * shell the wrong owner and put the control socket somewhere no one can reach.
 *
 * The catch worth knowing before installing it: a user manager is torn down when
 * the user's last session ends, which stops the service and kills every shell —
 * exactly the property people install this to avoid. `loginctl enable-linger`
 * is what keeps the manager alive, so the installer refuses to look finished
 * without saying so.
 */
export interface UnitPlan {
    /** Absolute path the unit will exec. */
    execStart: string;
    /** Where the unit file belongs. */
    unitPath: string;
    /** Unit name, including the instance suffix when one is set. */
    unitName: string;
    /** COMUXD_INSTANCE this unit is for, if any. */
    instance: string;
    /** Extra `Environment=` lines this launcher needs to work. */
    env: Record<string, string>;
    /**
     * Set when no unit can be written that would keep working — the AppImage case,
     * where the only paths available die with the mount. Explaining that beats
     * writing a unit that starts once and then fails after an upgrade.
     */
    unsupported?: string;
}
/** How to launch the daemon, plus whatever the environment has to say about it. */
export interface DaemonLaunch {
    execStart: string;
    env: Record<string, string>;
    unsupported?: string;
}
/** `comuxd` for the default instance, `comuxd-work` for COMUXD_INSTANCE=work. */
export declare function unitNameFor(instance: string): string;
/** ~/.config/systemd/user — honours XDG_CONFIG_HOME like everything else here. */
export declare function userUnitDir(env?: NodeJS.ProcessEnv): string;
/**
 * Find the launcher to exec.
 *
 * The portable bundle ships an executable `comuxd` at its root that resolves its
 * own Node, which is the right target when it exists: it survives the bundle
 * being moved and does not hardcode a node path. Otherwise fall back to running
 * the launcher script with the Node currently executing this code.
 */
export declare function resolveDaemonExec(opts?: {
    bundleRoot?: string;
    nodeBin?: string;
    scriptPath?: string;
}): string;
/**
 * Resolve the launcher, and any environment it cannot work without.
 *
 * There are three shipped layouts and they do NOT share a launcher:
 *
 * 1. **Portable TUI bundle** — ships an executable `comuxd` at its root that
 *    locates its own Node, so the bundle stays movable.
 * 2. **Source checkout** — `scripts/run-comuxd.cjs` under the current Node.
 * 3. **Packaged Electron (deb/AppImage)** — neither of the above exists. The
 *    launcher script is not inside the asar, and `process.execPath` is the
 *    ELECTRON binary, which opens the GUI unless `ELECTRON_RUN_AS_NODE` says
 *    otherwise. Pointing a unit at it without that variable starts a window on a
 *    headless server instead of a daemon. Electron's fs is asar-aware, so the
 *    entry may live inside the archive.
 *
 * The AppImage is the one case with no honest answer: everything addressable
 * lives under a mount point that is recreated per run, so any unit written from
 * inside it breaks the next time. Say so rather than write it.
 */
export declare function resolveDaemonLaunch(opts?: {
    bundleRoot?: string;
    nodeBin?: string;
    scriptPath?: string;
    appImage?: string;
    exists?: (p: string) => boolean;
}): DaemonLaunch;
/** systemd's ExecStart quoting: double quotes, backslash-escaped inside. */
export declare function quoteExec(p: string): string;
/**
 * Render the unit.
 *
 * `Restart=on-failure` and NOT on-success is deliberate: comuxd exits 0 when its
 * single-instance probe finds another daemon already answering on the socket, so
 * restarting on success would spin a losing race forever.
 */
export declare function renderUnit(plan: UnitPlan): string;
/** Everything the installer needs, resolved together. */
export declare function planUnit(env?: NodeJS.ProcessEnv, opts?: {
    bundleRoot?: string;
    nodeBin?: string;
    scriptPath?: string;
    exists?: (p: string) => boolean;
}): UnitPlan;

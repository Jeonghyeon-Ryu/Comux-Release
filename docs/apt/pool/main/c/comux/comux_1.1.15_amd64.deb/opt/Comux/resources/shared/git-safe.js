"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SAFE_GIT_DIFF_FLAGS = exports.SAFE_GIT_FLAGS = void 0;
/**
 * Flags forced onto every git invocation comux makes, ahead of the subcommand.
 *
 * Running git inside a repository executes that repository's `.git/config`.
 * `core.fsmonitor` is a COMMAND git runs, and plain `git status` runs it;
 * `diff.external` and a `.gitattributes` textconv driver are the same thing for
 * `git diff`. Cloning an untrusted repo and cd-ing into it is an entirely
 * ordinary thing for a developer to do, and comux polls whatever cwd a shell
 * reports (comuxd's V1 `report_pwd` → GitPoller) as well as whatever folder is
 * open in the sidebar (diff-provider). So the malicious clone gets code
 * execution as the user with no further interaction — inside a terminal
 * multiplexer whose entire job is running other people's code.
 *
 * `safe.directory` does not help here: it only trips when the repo is owned by a
 * DIFFERENT user, and you own what you cloned.
 *
 * This is a real execution, not a theory. Reproduced before the fix: a repo with
 * `core.fsmonitor=<path>/evil.sh` runs evil.sh on `git status --porcelain`, and
 * stops running it with these flags — with byte-identical branch and porcelain
 * output on a normal repo.
 *
 * `-c` on the command line outranks system, global, local AND worktree config,
 * so none of this can be turned back on from inside the repository.
 */
exports.SAFE_GIT_FLAGS = [
    '-c', 'core.fsmonitor=false', // executes a command during status
    '-c', 'core.hooksPath=', // could reintroduce it as a hook
    '-c', 'diff.external=', // executes a command instead of diffing
    '--no-optional-locks', // never write to a repo we are only inspecting
];
/**
 * Per-command additions for `git diff`, which `-c` cannot cover: a textconv
 * driver is selected by `.gitattributes` and runs a command per file. Both are
 * accepted by every git that ships `--no-optional-locks` (2.14+), and neither
 * changes the output of a repo that does not define such a driver.
 */
exports.SAFE_GIT_DIFF_FLAGS = ['--no-ext-diff', '--no-textconv'];

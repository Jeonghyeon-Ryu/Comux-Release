/**
 * Pure worktree naming, split from worktree.ts (which needs child_process and
 * fs) so the renderer's new-worktree dialog can preview the exact folder name
 * the host will use.
 */
/** A branch name as one folder name: `feature/login` → `feature-login`. */
export declare function branchSlug(branch: string): string;

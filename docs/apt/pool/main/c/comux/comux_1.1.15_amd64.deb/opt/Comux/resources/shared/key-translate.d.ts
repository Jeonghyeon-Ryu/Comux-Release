/**
 * Named key → the bytes a PTY expects, for the pipe's `surface.send_key`.
 *
 * Pure and electron-free so both hosts and the tests can use it: the GUI reaches
 * it from main and comuxd from the daemon, through the one `resolveKeyBytes`
 * below. It used to live inside src/main/index.ts, where importing it meant
 * importing the whole Electron entry point — which is why the daemon grew its own
 * scaffold copy instead.
 */
/**
 * Translate a key name to PTY bytes, or null when it is not a key we know.
 *
 * Two rules, in this order:
 *  - A single character is sent as itself, upper-cased when `shift` is set. This
 *    is what makes `send-key a --shift` produce "A" and, more importantly, what
 *    lets Ctrl+letter flows pass the letter through untouched.
 *  - Otherwise the name is matched case-insensitively against the table.
 *
 * Returning null rather than a guess matters: the caller reports an unknown key
 * instead of writing something arbitrary into the user's shell.
 */
export declare function translateKeyName(key: string, shift: boolean): string | null;
/** The names translateKeyName accepts (for help text and tests). */
export declare function knownKeyNames(): string[];
export type KeyResolution = {
    ok: true;
    bytes: string;
} | {
    ok: false;
    error: string;
};
/**
 * The whole of `surface.send_key`: a key name plus modifiers → the bytes to write.
 *
 * This is shared rather than duplicated because the two hosts had drifted badly.
 * The GUI did the full job; the daemon carried a separate scaffold that knew nine
 * key names, dropped `alt` on the floor, and — worst — returned the key NAME for
 * anything it did not recognise. Over SSH, `comux send-key pageup` therefore
 * typed the literal word "pageup" into the user's shell, and `ctrl-c` typed
 * "ctrl-c" instead of interrupting.
 *
 * Order matters and matches the GUI's (verified) behaviour: translate the name
 * first, then fold in ctrl, then prefix alt. Doing ctrl before translation would
 * turn `ctrl-c` (a table entry) into something else entirely.
 *
 * An unknown name is an ERROR, never a guess — writing an arbitrary string into
 * a live shell is the failure this replaces.
 */
export declare function resolveKeyBytes(key: string, modifiers?: string[]): KeyResolution;

# comux bash shim — passed to bash as --init-file.
#
# --init-file REPLACES ~/.bashrc rather than adding to it, so this file has to
# load the user's own configuration first. Getting that order wrong would mean
# comux silently dropped the user's prompt, aliases and PATH the moment they
# opened a terminal.
#
# /etc/bash.bashrc is unaffected — bash still reads it before this file.

if [ -f "$HOME/.bashrc" ]; then
    . "$HOME/.bashrc"
fi

# Then layer comux's reporting on top, so its PROMPT_COMMAND hook wraps whatever
# the user's rc installed instead of being overwritten by it.
if [ -n "${COMUX_SHELL_INTEGRATION:-}" ] && [ -f "$COMUX_SHELL_INTEGRATION" ]; then
    . "$COMUX_SHELL_INTEGRATION"
fi

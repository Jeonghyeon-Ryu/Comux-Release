---
name: orchestrate
description: Core orchestration skill. Analyzes codebase, decomposes tasks into a dependency graph of parallel agents (drawn as waves), starts each agent as soon as its dependencies finish, optionally isolates each in a git worktree, and triggers a reviewer.
---

# comux Orchestration Skill

You are the orchestrator. Your job is to decompose the user's task into parallel subtasks, plan their dependencies, and launch agents to execute it.

## Phase 0: Resolve Plugin Root

`CLAUDE_PLUGIN_ROOT` is set by Claude Code only inside hook execution, NOT in the main session's shell environment. You MUST resolve the plugin root path before running any scripts.

Run this to find and export the plugin root:

```bash
PLUGIN_ROOT=$(find "$HOME/.claude/plugins/cache" -path "*comux-orchestrator*/.claude-plugin/plugin.json" 2>/dev/null | sort -V | tail -1 | sed 's|/.claude-plugin/plugin.json||')
echo "PLUGIN_ROOT=$PLUGIN_ROOT"
ls "$PLUGIN_ROOT/scripts/" | head -5
```

If the `find` returns empty, the plugin is not installed. Tell the user:
> "comux-orchestrator plugin not found. Install it with: `claude plugins install comux-orchestrator@comux-orchestrator`"

**Store `PLUGIN_ROOT` and use it for ALL subsequent `bash` commands in this orchestration.** Every script reference below uses `$PLUGIN_ROOT` — you must prefix every bash command that references plugin scripts with the same export or pass the resolved path directly.

## Phase 1: Detect comux

Run the detection script:

```bash
bash "$PLUGIN_ROOT/scripts/detect-comux.sh"
```

Store the result as `COMUX_MODE`:
- If output is `"available"` → `COMUX_MODE=comux` — agents spawn in visible terminal panes via `comux agent spawn`
- If output is `"unavailable"` → `COMUX_MODE=degraded` — agents spawn as invisible Claude Code subagents via the Agent tool

**This decision is binding for the entire orchestration.** Do not switch modes mid-orchestration.

If degraded, log to the user:
> "comux not detected. Running in degraded mode — agents will use Claude Code's native subagent system. Install comux for the full multi-pane experience: https://comux.org"

If comux mode, log to the user:
> "comux detected. Agents will spawn in visible terminal panes."

## Phase 2: Analyze the Codebase

Before decomposing, understand what the task involves:

1. **Map relevant files**: Use Glob and Grep to find all files related to the task
2. **Trace dependencies**: For each relevant file, check its imports and exports to understand coupling
3. **Identify conflict zones**: Files that would need to be touched by multiple subtasks — these MUST be assigned to a single agent or sequenced across waves
4. **Check git context**: Read recent commits for relevant context

Be thorough but efficient. You need enough understanding to make good decomposition decisions, not a complete codebase map.

## Phase 3: Decompose into Subtasks

Based on your analysis, break the task into subtasks. Each subtask must have:
- A clear, bounded scope described in 2-3 sentences
- An explicit list of files it may modify (allowed files)
- An explicit list of files it must NOT modify (other agents' zones)
- No circular dependencies with other subtasks

**Rules for decomposition:**
- Files that are tightly coupled (heavy imports between them) belong in the same subtask
- Shared types/interfaces should be in the earliest wave (other agents depend on them)
- Tests should generally be in the last wave (they depend on implementation)
- Prefer fewer, larger subtasks over many tiny ones — agent startup has overhead
- A single-line fix does NOT need an orchestration. If the task is trivial, just do it directly.

Reference the decomposition guide for patterns:
```bash
cat "$PLUGIN_ROOT/skills/orchestrate/references/decomposition-guide.md"
```

## Phase 4: Build the Plan (a dependency graph, drawn as waves)

Group subtasks into waves for the picture, but give every agent an explicit `dependsOn` list — the agent ids whose output it actually needs:

- **Wave 1**: Foundation work — types, models, shared interfaces. `dependsOn: []`.
- **Wave 2+**: Work that needs earlier output. `dependsOn` names ONLY the agents it reads from.
- **Final wave**: Tests, documentation, or anything that depends on all previous work.

In comux mode the scheduler (`scripts/orch.js`) starts each agent **the moment its own dependencies are done** — not when its whole wave is. An API agent that only needs the types agent starts while the UI agent is still working. Leave `dependsOn` out and the agent waits for every agent in earlier waves (the old barrier behaviour).

Per agent you may also set **`category`** — `quick` (small mechanical edits), `deep` (design-heavy work), `visual` (UI/CSS), `review` — or an explicit **`cli`** (`claude`, `codex`, `gemini`, `opencode`). The user's `~/.comux/orchestrator.json` (or the project's `.comux/orchestrator.json`) maps categories to ordered CLI lists, e.g. `{"categories": {"quick": ["codex", "claude"], "visual": ["gemini", "claude"]}}`; a CLI that is not installed is skipped, and everything falls back to `claude`. Set a category only when the user has such a config or asks for it.

Sizing:
- Number of truly independent subtasks
- `maxParallel` (default 5) caps how many run at once; more causes diminishing returns from context overhead
- If only 1 subtask exists, skip orchestration and do it directly

## Phase 4.5: Detect Coupling & Generate Contracts

Before presenting the plan, audit each wave for **coupling**: cases where multiple parallel agents must agree on names, types, shapes, or IDs for the final output to work. Coupling that isn't explicitly coordinated causes drift — agents independently invent different names for the same concept and the integration breaks. (This actually happened on a past run: two parallel agents building HTML and CSS invented different class names like `.hero__grid` vs `.hero__inner` for the same element, and 510 lines of alias CSS were needed to reconcile after the fact.)

### Coupling triggers

A wave has coupled agents when any of these apply:
- Two or more agents touch files of the same domain that reference each other by name:
  - HTML + CSS of the same component (class names must match)
  - HTML + JS of the same component (mount-point IDs and selectors must match)
  - Frontend client + backend server for the same feature (endpoint paths, request/response shapes must match)
  - Schema producer + schema consumer (exported type signatures must match)
  - Multiple agents adding methods/fields to the same exported module
- Two or more agents fill slots in a shared top-level structure (e.g., one writes the HTML skeleton, others write the component markup that plugs into it)
- Two or more agents read from or write to a common config/constants file

### Resolution paths

For each coupled group, choose ONE resolution:

1. **Merge into a single agent.** Use when the coupled work is small enough for one agent (roughly < 800 lines of final output) AND the work is naturally cohesive. Prefer this when possible — fewest moving parts.

2. **Sequence across waves.** Move one agent to an earlier wave; the later wave's prompt includes the earlier wave's result file so the dependent agent reads real names from real files. Use when the coupling is directional (types → consumers, schema → migrations, API → clients) and large enough that merging would make one agent unwieldy.

3. **Generate a shared contract file.** Write a single source-of-truth document that BOTH agents read before writing any code. Use when the work MUST run in parallel AND the coupling is naming-only, not logic-level.

### Generating the contract file (path 3)

When you choose path 3, write `{orch-dir}/wave-{N}-contract.md` BEFORE spawning the wave. Every shared name must appear in it. If an agent needs a name not in the contract, that's a bug — the agent must stop and flag disagreement (see injection below), not silently invent.

Template (omit sections that don't apply — don't include placeholder text, only real names):

````markdown
# Wave {N} Contract — [short description]

> This is the single source of truth for names shared by parallel agents in wave {N}.
> All agents listed below MUST read this file before writing any code and use these
> names verbatim. Do not invent alternatives.

## Agents bound by this contract
- agent-a ([role])
- agent-b ([role])

## Shared HTML class names
_(fill this section when at least one agent writes HTML and another writes CSS)_
- Site header: `.site-header`, `.site-header__brand`, `.site-header__nav`, `.site-header__link`
- Hero: `.hero`, `.hero__grid`, `.hero__title`, `.hero__title__line`, `.hero__cta`

## Shared DOM IDs and mount points
_(fill when one agent writes HTML scaffolding that another agent fills via JS)_
- `#wave-sim-root` — empty div in hero; agent-c mounts the simulator into it
- `aside.activity-rail` — empty aside in hero; agent-e appends log lines to it

## Shared CSS custom properties
_(fill when CSS declares variables that JS reads/writes)_
- `--scroll` — 0..1 fractional page scroll, written by motion agent, read by CSS
- `--mouse-x`, `--mouse-y` — **pixel** values (not normalized), written by ambient agent, read by CSS `top`/`left`

## Shared TypeScript/JavaScript exports
_(fill when one agent declares types/functions used by another in the same wave)_
- `export type User = { id: string; email: string; role: 'admin' | 'user' }` in `src/shared/types.ts`
- `export function formatDate(d: Date): string` in `src/shared/format.ts`

## Shared API endpoints
_(fill when frontend and backend are coupled)_
- `POST /api/auth/login` — request `{ email, password }`, response `{ token, user: User }`
- `GET /api/users/:id` — response `User`

## Shared file structure
_(fill when multiple agents place files in a coordinated layout)_
- `src/components/Hero/Hero.tsx` — structure (agent-a)
- `src/components/Hero/hero.module.css` — styles (agent-b)
````

### Injecting the contract into agent prompts

For EVERY coupled agent in the wave, add this block to their prompt file (in Phase 6c), placed right after the `## Orchestration Context` section and before `## Your Zone of Work`:

````markdown
## Shared Contract — READ BEFORE WRITING ANY CODE

You share this wave with other agents who depend on the same names. To prevent naming drift, a shared contract has been written at:

`{orch-dir}/wave-{N}-contract.md`

**Before writing any code, use the Read tool to read that file in full.** It defines every class name, mount point, type, and API shape that you and the other agents must use identically. Use these names verbatim — do not invent alternatives, do not translate them, do not simplify them.

If a name in the contract seems wrong or missing:
1. Stop implementation.
2. Write to your result file with status `contract_disagreement`.
3. Describe the specific name at issue and your proposed alternative.
4. Do NOT silently invent a different name and proceed.

The reviewer will pick up any `contract_disagreement` result and reconcile before the next wave.
````

Agents NOT in a coupled group skip this block — their work is independent and doesn't need the extra read.

## Phase 5: Present the Plan

Show the user a structured plan. Format it clearly:

```
Orchestration Plan: [task description]
Agents: [total] in [N] waves
Estimated complexity: [low/medium/high]

Wave 1 — [description]
  Agent A: "[subtask label]"
    Allowed files: [list]
    Excluded files: [list]

Wave 2 — [description]
  Agent B: "[subtask label]"   after: A
    Allowed files: [list]
    Excluded files: [list]
  Agent C: "[subtask label]"   after: A   [category quick → codex]
    Allowed files: [list]
    Excluded files: [list]

Wave 3 — [description]
  Agent D: "[subtask label]"   after: B, C
    Allowed files: [list]
    Excluded files: [list]

Options:
  --worktree: Give each agent its own git worktree + branch; each is merged into this checkout when it finishes (default: no)
  --review-cli codex|gemini|claude: Run the final review as a separate agent in that CLI — an independent second opinion (default: review in this session)
  --no-review: Skip the automated reviewer (default: review enabled)
```

Recommend `--worktree` when agents' file zones are close to each other or when the user wants to keep their checkout untouched until the end; without it every agent edits this checkout directly.

Ask the user: **"Validate this plan? (yes / adjust / cancel)"**

Wait for user approval. If they want adjustments, modify the plan and re-present. Do NOT proceed without explicit approval.

## Phase 6: Initialize Orchestration

Once the user validates:

### 6a. Generate orchestration ID

```bash
ORCH_ID="orch-$(date +%s | tail -c 7)"
echo $ORCH_ID
```

### 6b. Create orchestration directory and state file

Create the directory:
```bash
mkdir -p "${TMPDIR:-/tmp}/comux-orch-$ORCH_ID"
```

Write `state.json` using the Write tool. Schema:
```json
{
  "id": "orch-XXXXXX",
  "task": "the user's task description",
  "status": "running",
  "startedAt": "ISO-8601 UTC timestamp",
  "cwd": "project working directory",
  "workspaceId": null,
  "dashboardSurfaceId": null,
  "useWorktrees": false,
  "maxParallel": 5,
  "waves": [
    {
      "index": 0,
      "status": "pending",
      "agents": [
        {
          "id": "agent-a",
          "label": "Subtask label",
          "subtask": "Full subtask description",
          "files": ["allowed/file/paths"],
          "excludeFiles": ["excluded/patterns/*"],
          "dependsOn": [],
          "category": null,
          "status": "pending",
          "toolUses": 0,
          "resultFile": "<orch-dir>/agent-a-result.md"
        }
      ]
    }
  ],
  "reviewer": {
    "status": "pending",
    "mode": "session",
    "cli": null,
    "reportFile": "<orch-dir>/review-report.md"
  }
}
```

Use short agent IDs like "agent-a", "agent-b", etc. Leave every status "pending" — `orch.js start` sets them. `cwd` must be the Windows-style path on Windows (`C:\...` or `C:/...`); a Git Bash `/c/...` path is converted. With `--worktree`, set `"useWorktrees": true`. With `--review-cli X`, set the reviewer's `"mode": "agent"` and `"cli": "X"`. With `--no-review`, leave out `reviewer`.

### 6c. Generate agent prompt files

For EACH agent, create a prompt file at `{orch-dir}/agent-{id}-prompt.md` with:

```markdown
# Mission: [subtask label]

## Orchestration Context
You are [Agent ID] in orchestration [ORCH_ID].
[N] other agents are working on the same project in parallel.
You are in Wave [N] of [total waves].

[If this agent is in a coupled group per Phase 4.5, inject the Shared Contract block here — see Phase 4.5 template. Skip for non-coupled agents.]

[If the agent has dependencies:]
## Results You Build On
These agents finish before you start. Read their result files FIRST — they say what they changed and which names/types they exported:
- [orch-dir]/agent-[dep-id]-result.md (for each id in dependsOn)

## Your Zone of Work
Allowed files (you MAY modify these):
- [list each file]

Excluded files (you MUST NOT modify these):
- [list patterns]

## Your Mission
[Detailed subtask description with specific steps]

## When You Finish
Create your result file at: [orch-dir]/agent-[id]-result.md

Use this format:
### Summary
[2-3 sentences]
### Files Modified
- `path` — [description]
### Interfaces/Types Changed
[Any exported types that changed signature]
### Tests
[Test results or "Out of scope"]
### Risks
[Points of attention for other agents or reviewer]
```

Write prompt files for ALL agents now, not wave by wave: an agent may start the moment its dependencies finish, while you are not looking.

### 6d/6e. Start the run (comux mode)

**IMPORTANT: Work in the CURRENT workspace. Do NOT create or close workspaces — that hides agent panes from the user.**

**CRITICAL RULE: When comux is available, agents run in visible terminal panes started by the scheduler. Do NOT use Claude Code's `Agent` tool when comux is available — it creates invisible subagents the user cannot see. The `Agent` tool is ONLY for degraded mode (no comux).**

```bash
node "$PLUGIN_ROOT/scripts/orch.js" start "[orch-dir]"
```

This validates the plan (unknown ids and dependency cycles are rejected — fix `state.json` and run it again), lays out one pane grid for the run, and starts every agent whose dependencies are already met. For each agent it:
1. creates its git worktree (`orch/<orch-id>/<agent-id>`) when `useWorktrees` is on;
2. picks its CLI (`cli`, else `category` through the user's config, else claude);
3. runs `launch-agent.js` in a pane — the agent starts **interactively with its full TUI**, so the user can watch it and type into it.

From then on the scheduler moves by itself: when an agent finishes, everything that was waiting on it starts.

**If comux is NOT available (degraded mode only):**

Spawn each agent using Claude Code's native Agent tool:
- For each agent in Wave 1, use the Agent tool with `subagent_type: "comux-orchestrator:comux-worker"`
- Pass the prompt file content as the prompt
- Use `description: "[agent label]"` for tracking
- Wait for all agents to complete before proceeding to next wave

## Phase 7: Monitor and Transition (Orchestrator Loop)

**You are the orchestrator.** Your job is to monitor agent progress and coordinate wave transitions. This is where the real orchestration happens.

### Live dashboard visibility

Before entering the loop, note how the user sees progress:

- **In comux mode**: comux's sidebar automatically watches `{TMPDIR}/comux-orch-*/state.json` and renders a live cockpit (task, elapsed time, per-wave progress bars, per-agent state dots, tool counts). You don't need to do anything to keep it updated — the hooks already update state.json on tool-use and wave transitions, and the sidebar polls every second. Do NOT call the dashboard manually in comux mode; it would be redundant and noisy.

- **In degraded mode (no comux)**: you must print the text dashboard into Claude Code's conversation at each wave transition so the user can see progress. Run:
  ```bash
  node "$PLUGIN_ROOT/scripts/dashboard-text.js" "[orch-dir]"
  ```
  Call it ONCE after spawning each wave, and ONCE after each wave completes. Do not call it inside the monitoring loop (that would spam the session). If the user asks "how's it going", you can also call it then.

### With comux (event-driven — do not poll):

Agents run interactively and never exit by themselves, so their process status says nothing. Completion is an EVENT: a Claude worker's Stop hook reports it the moment the worker finishes (and sends it back to work if its result file is missing — the evidence gate); a codex/gemini worker is noticed when its result file appears. Wait for the next event with ONE call:

```bash
node "$PLUGIN_ROOT/scripts/orch.js" wait "[orch-dir]"
```

It blocks (up to ~9 minutes, no tokens spent) and prints what happened plus a status table. Then:

- **`done <agent>`** — read `[orch-dir]/agent-<id>-result.md` and tell the user in one or two lines what it produced. Its dependents have already been started (`started` events).
- **`merge-conflict <agent>`** (worktree mode) — its branch did not merge into this checkout cleanly; everything after it waits. Resolve it here: `git merge orch/<orch-id>/<agent-id>`, fix the conflicts, commit, then `node "$PLUGIN_ROOT/scripts/orch.js" resolved "[orch-dir]" <agent-id>`.
- **`failed <agent>`** — read the reason (and the result file if any). Either fix the cause and mark it done yourself with `orch.js complete "[orch-dir]" <agent-id>`, or tell the user what blocks it.
- **`needs-attention <agent>`** — the worker stopped without a result, usually to ask the user something. Point the user at its pane.
- **`stuck`** — nothing can move: failed/blocked agents are listed. Decide with the user.
- **`all-done`** — go to Phase 8.
- **No change** — just call `wait` again.

Report progress to the user between waits, briefly. Never start agents yourself and never write prompt files for "the next wave" — the scheduler starts each agent when it is ready. `node "$PLUGIN_ROOT/scripts/orch.js" status "[orch-dir]"` prints the table at any time.

### Without comux (degraded mode — Agent tool returns):
1. Wait for all Wave N agents to complete (their Agent tool calls return)
2. Read their result files
3. Generate Wave N+1 agent prompts (inject previous wave results)
4. Spawn Wave N+1 agents using Agent tool
5. Repeat until all waves complete

## Phase 8: Review

When all agents are done:

- **Reviewer in another CLI** (`reviewer.mode: "agent"`): the scheduler has already started it (`started reviewer` in the last `wait`). It reviews the whole run independently and writes `review-report.md` ending in `VERDICT: PASS` or `VERDICT: FAIL — …`. Keep calling `wait` until `review-done`, then read the report.
- **Reviewer in this session** (default): aggregate the results and invoke the reviewer skill:
  ```bash
  bash "$PLUGIN_ROOT/scripts/collect-results.sh" "[orch-dir]"
  ```

Treat every agent's report as a claim to verify, not a fact.

## Phase 9: Finalize

```bash
node "$PLUGIN_ROOT/scripts/orch.js" finish "[orch-dir]"
```

Present a summary:
- Total time elapsed, agents used (and which CLI each ran on)
- Files modified (from `git diff --stat`)
- Test results and the reviewer's findings / verdict
- Offer actions: **commit** / **view full diff** / **abort all changes**

When the user is done with the agents' panes, clean up (stops the agents; with worktrees, removes each merged worktree and its branch — an unmerged one is kept):
```bash
node "$PLUGIN_ROOT/scripts/orch.js" cleanup "[orch-dir]"
```

"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.shellKind = shellKind;
exports.activateShellIntegration = activateShellIntegration;
/**
 * Getting bash/zsh to LOAD the comux shell integration.
 *
 * The reporting script itself has existed for a long time, but nothing ever
 * sourced it for these shells: pty-manager wired up PowerShell and cmd only, and
 * the daemon spawned a bare `$SHELL`. So on Linux — where bash IS the shell and
 * there is no PowerShell integration to fall back on — cwd, git branch and shell
 * state never reached comux at all.
 *
 * Neither shell has a "source this as well" flag, so both need a shim, and the
 * shim must run the user's own startup files first or comux would silently
 * replace their prompt, aliases and PATH:
 *
 *   bash — `--init-file <shim>` REPLACES ~/.bashrc, so the shim sources ~/.bashrc
 *          itself and then layers the integration on top. (--init-file is ignored
 *          for login shells; comux does not spawn one.)
 *   zsh  — there is no --init-file equivalent, so ZDOTDIR is pointed at a
 *          directory of shims. zsh re-reads ZDOTDIR before EACH startup file, so
 *          the shim must keep pointing at itself until .zshrc has run; the real
 *          directory travels in COMUX_ZDOTDIR_ORIG and is restored at the end.
 *
 * Same approach VS Code uses for its shell integration, for the same reasons.
 */
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
/** Classify a shell command/path. Matches on the basename so a directory that
 *  happens to contain "cmd" or "zsh" cannot misclassify the shell. */
function shellKind(shell) {
    const lower = (shell || '').toLowerCase();
    if (lower.includes('pwsh') || lower.includes('powershell'))
        return 'powershell';
    const base = lower.split(/[\\/]/).pop() || lower;
    const name = base.replace(/\.exe$/, '');
    if (name === 'cmd')
        return 'cmd';
    if (name === 'wsl')
        return 'wsl';
    if (name === 'bash' || name === 'sh')
        return 'bash'; // dash/sh: --init-file is bash-only, see below
    if (name === 'zsh')
        return 'zsh';
    if (lower.includes('cmd'))
        return 'cmd';
    if (lower.includes('wsl'))
        return 'wsl';
    return 'unknown';
}
const NONE = { args: [], env: {} };
/**
 * Argv + env that make `shell` load the integration from `integrationDir`.
 * Returns nothing to add when the shell is not bash/zsh, or when the files are
 * missing (a dev tree without a build, a bundle that did not stage them) — a
 * missing integration must degrade to a plain shell, never to a broken one.
 */
function activateShellIntegration(shell, integrationDir) {
    const kind = shellKind(shell);
    if (kind !== 'bash' && kind !== 'zsh')
        return NONE;
    const script = path.join(integrationDir, 'comux-bash-integration.sh');
    if (!exists(script))
        return NONE;
    if (kind === 'bash') {
        // `sh` is often dash, which has no --init-file and would treat it as an
        // operand — starting the shell with a bogus argument. Only real bash gets it.
        if (!/bash(\.exe)?$/i.test(shell))
            return NONE;
        const init = path.join(integrationDir, 'comux-bash-init.sh');
        if (!exists(init))
            return NONE;
        return { args: ['--init-file', init], env: { COMUX_SHELL_INTEGRATION: script } };
    }
    const zdotdir = path.join(integrationDir, 'zdotdir');
    if (!exists(path.join(zdotdir, '.zshrc')))
        return NONE;
    return {
        args: [],
        env: {
            ZDOTDIR: zdotdir,
            // Where the user's real startup files live, for the shim to source and to
            // restore. ZDOTDIR is frequently unset, in which case zsh means $HOME.
            COMUX_ZDOTDIR_ORIG: process.env.ZDOTDIR || process.env.HOME || '',
            COMUX_SHELL_INTEGRATION: script,
        },
    };
}
function exists(p) {
    try {
        return fs.existsSync(p);
    }
    catch {
        return false;
    }
}

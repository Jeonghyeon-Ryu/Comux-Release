"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.unitNameFor = unitNameFor;
exports.userUnitDir = userUnitDir;
exports.resolveDaemonExec = resolveDaemonExec;
exports.resolveDaemonLaunch = resolveDaemonLaunch;
exports.quoteExec = quoteExec;
exports.renderUnit = renderUnit;
exports.planUnit = planUnit;
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
/** `comuxd` for the default instance, `comuxd-work` for COMUXD_INSTANCE=work. */
function unitNameFor(instance) {
    const suffix = instance.trim() ? `-${instance.trim()}` : '';
    return `comuxd${suffix}.service`;
}
/** ~/.config/systemd/user — honours XDG_CONFIG_HOME like everything else here. */
function userUnitDir(env = process.env) {
    const base = env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
    return path.join(base, 'systemd', 'user');
}
/**
 * Find the launcher to exec.
 *
 * The portable bundle ships an executable `comuxd` at its root that resolves its
 * own Node, which is the right target when it exists: it survives the bundle
 * being moved and does not hardcode a node path. Otherwise fall back to running
 * the launcher script with the Node currently executing this code.
 */
function resolveDaemonExec(opts = {}) {
    return resolveDaemonLaunch(opts).execStart;
}
/**
 * Resolve the launcher, and any environment it cannot work without.
 *
 * There are three shipped layouts and they do NOT share a launcher:
 *
 * 1. **Portable TUI bundle** — ships an executable `comuxd` at its root that
 *    locates its own Node, so the bundle stays movable.
 * 2. **Source checkout** — `scripts/run-comuxd.cjs` under the current Node.
 * 3. **Packaged Electron (deb/AppImage)** — neither of the above exists. The
 *    launcher script is not inside the asar, and `process.execPath` is the
 *    ELECTRON binary, which opens the GUI unless `ELECTRON_RUN_AS_NODE` says
 *    otherwise. Pointing a unit at it without that variable starts a window on a
 *    headless server instead of a daemon. Electron's fs is asar-aware, so the
 *    entry may live inside the archive.
 *
 * The AppImage is the one case with no honest answer: everything addressable
 * lives under a mount point that is recreated per run, so any unit written from
 * inside it breaks the next time. Say so rather than write it.
 */
function resolveDaemonLaunch(opts = {}) {
    const bundleRoot = opts.bundleRoot ?? path.resolve(__dirname, '..', '..');
    const node = opts.nodeBin ?? process.execPath;
    const appImage = opts.appImage ?? process.env.APPIMAGE;
    const exists = opts.exists ?? ((p) => {
        try {
            return fs.existsSync(p);
        }
        catch {
            return false;
        }
    });
    // 1. The bundle's own wrapper, when it is there.
    const wrapper = path.join(bundleRoot, 'comuxd');
    if (exists(wrapper))
        return { execStart: quoteExec(wrapper), env: {} };
    // 2. The plain-Node launcher script.
    const script = opts.scriptPath ?? path.join(bundleRoot, 'scripts', 'run-comuxd.cjs');
    if (exists(script)) {
        // Quote both halves: systemd splits ExecStart on whitespace, and an install
        // path with a space would otherwise become two arguments.
        return { execStart: `${quoteExec(node)} ${quoteExec(script)}`, env: {} };
    }
    // 3. Packaged Electron. The daemon entry ships inside the asar, and where this
    //    module is loaded from decides how to reach it:
    //      - inside the asar   → dist/daemon sits right there
    //      - resources/shared/ → the deb's CLI runs from OUTSIDE the archive
    //        (electron-builder copies cli/ and shared/ out), so bundleRoot is the
    //        app root and the entry is one level down inside app.asar.
    //    Getting this wrong is silent: the unit installs, and only fails at start
    //    with MODULE_NOT_FOUND.
    const inPlace = path.join(bundleRoot, 'dist', 'daemon', 'comuxd.js');
    const asar = path.join(bundleRoot, 'resources', 'app.asar');
    const entry = exists(inPlace)
        ? inPlace
        : exists(asar)
            ? path.join(asar, 'dist', 'daemon', 'comuxd.js')
            : inPlace;
    const launch = {
        execStart: `${quoteExec(node)} ${quoteExec(entry)}`,
        env: { ELECTRON_RUN_AS_NODE: '1' },
    };
    if (appImage) {
        launch.unsupported =
            'This is an AppImage: every path inside it lives under a mount that is '
                + 'recreated on each run, so a unit written from here stops working after '
                + 'the next start. Install the .deb (or the headless bundle) to run comuxd '
                + 'as a service.';
    }
    return launch;
}
/** systemd's ExecStart quoting: double quotes, backslash-escaped inside. */
function quoteExec(p) {
    if (!/[\s"\\]/.test(p))
        return p;
    return `"${p.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}
/**
 * Render the unit.
 *
 * `Restart=on-failure` and NOT on-success is deliberate: comuxd exits 0 when its
 * single-instance probe finds another daemon already answering on the socket, so
 * restarting on success would spin a losing race forever.
 */
function renderUnit(plan) {
    const vars = { ...(plan.env ?? {}) };
    if (plan.instance.trim())
        vars.COMUXD_INSTANCE = plan.instance.trim();
    const envLines = Object.entries(vars)
        .map(([k, v]) => `Environment=${k}=${v}\n`)
        .join('');
    return `[Unit]
Description=comux daemon (terminal multiplexer for AI agents)
Documentation=https://jeonghyeon-ryu.github.io/Comux-Release/
After=default.target

[Service]
Type=simple
ExecStart=${plan.execStart}
${envLines}# comuxd exits 0 when another instance already holds the socket, so restarting
# on success would spin forever against a daemon that is already running.
Restart=on-failure
RestartSec=2
# The daemon flushes its session and kills its PTYs on SIGTERM, so the default
# stop signal is already a clean shutdown.
KillSignal=SIGTERM
TimeoutStopSec=10

[Install]
WantedBy=default.target
`;
}
/** Everything the installer needs, resolved together. */
function planUnit(env = process.env, opts = {}) {
    const instance = env.COMUXD_INSTANCE || '';
    const unitName = unitNameFor(instance);
    const launch = resolveDaemonLaunch({ ...opts, appImage: env.APPIMAGE });
    return {
        execStart: launch.execStart,
        unitPath: path.join(userUnitDir(env), unitName),
        unitName,
        instance,
        env: launch.env,
        unsupported: launch.unsupported,
    };
}

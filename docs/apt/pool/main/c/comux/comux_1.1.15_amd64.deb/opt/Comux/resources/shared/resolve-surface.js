"use strict";
/**
 * Deciding which terminal a write should go to.
 *
 * Every external write path funnels through this: the pipe's `surface.send_text`
 * and `send_key`, and the REST `/terminals/:id/input`. The caller may name a
 * surface or leave it out, and "leave it out" has to mean the surface the user
 * is actually looking at.
 *
 * The decision is separated from HOW the host answers the two questions it asks
 * — the GUI reads the active surface out of the renderer over IPC and checks its
 * PtyManager; the daemon walks its SessionModel. Same injection style as
 * RestServerDeps and AgentSeedHost, and it makes the branch table testable
 * without an Electron window.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveSurfaceForWrite = resolveSurfaceForWrite;
/**
 * Resolve `id` (or the active surface when absent) to a writable terminal.
 *
 * Every failure is a distinct message rather than a bare false: these strings
 * surface to a CLI user or an HTTP client as the entire explanation, and
 * "no surface" vs "that surface is a markdown pane" lead to different fixes.
 */
async function resolveSurfaceForWrite(id, host) {
    let surfaceId = id;
    if (!surfaceId) {
        try {
            surfaceId = (await host.getActiveSurfaceId()) ?? undefined;
        }
        catch (err) {
            // The renderer may be mid-reload or gone; say so instead of reporting the
            // much more confusing "no active surface".
            return { ok: false, error: `Could not resolve active surface: ${err?.message ?? err}` };
        }
        if (!surfaceId)
            return { ok: false, error: 'No active surface' };
    }
    const branded = surfaceId;
    if (!host.hasPty(branded)) {
        return {
            ok: false,
            error: `surface ${surfaceId} has no PTY (pane is markdown/browser, or surface was closed). Pass an explicit surfaceId pointing at a terminal surface.`,
        };
    }
    return { ok: true, id: branded };
}

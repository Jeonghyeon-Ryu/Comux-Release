"use strict";
/**
 * Named key → the bytes a PTY expects, for the pipe's `surface.send_key`.
 *
 * Pure and electron-free so both hosts and the tests can use it: the GUI reaches
 * it from main and comuxd from the daemon, through the one `resolveKeyBytes`
 * below. It used to live inside src/main/index.ts, where importing it meant
 * importing the whole Electron entry point — which is why the daemon grew its own
 * scaffold copy instead.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.translateKeyName = translateKeyName;
exports.knownKeyNames = knownKeyNames;
exports.resolveKeyBytes = resolveKeyBytes;
const PTY_KEY_MAP = {
    enter: '\r',
    return: '\r',
    tab: '\t',
    esc: '\x1b',
    escape: '\x1b',
    backspace: '\x7f',
    delete: '\x1b[3~',
    space: ' ',
    'ctrl-c': '\x03',
    'ctrl-d': '\x04',
    'ctrl-u': '\x15',
    'ctrl-l': '\x0c',
    'ctrl-a': '\x01',
    'ctrl-e': '\x05',
    'ctrl-k': '\x0b',
    'ctrl-w': '\x17',
    'ctrl-r': '\x12',
    'ctrl-z': '\x1a',
    up: '\x1b[A',
    down: '\x1b[B',
    right: '\x1b[C',
    left: '\x1b[D',
    home: '\x1b[H',
    end: '\x1b[F',
    pageup: '\x1b[5~',
    pagedown: '\x1b[6~',
    f1: '\x1bOP', f2: '\x1bOQ', f3: '\x1bOR', f4: '\x1bOS',
    f5: '\x1b[15~', f6: '\x1b[17~', f7: '\x1b[18~', f8: '\x1b[19~',
    f9: '\x1b[20~', f10: '\x1b[21~', f11: '\x1b[23~', f12: '\x1b[24~',
};
/**
 * Translate a key name to PTY bytes, or null when it is not a key we know.
 *
 * Two rules, in this order:
 *  - A single character is sent as itself, upper-cased when `shift` is set. This
 *    is what makes `send-key a --shift` produce "A" and, more importantly, what
 *    lets Ctrl+letter flows pass the letter through untouched.
 *  - Otherwise the name is matched case-insensitively against the table.
 *
 * Returning null rather than a guess matters: the caller reports an unknown key
 * instead of writing something arbitrary into the user's shell.
 */
function translateKeyName(key, shift) {
    if (key.length === 1)
        return shift ? key.toUpperCase() : key;
    const normalized = key.toLowerCase();
    if (normalized in PTY_KEY_MAP)
        return PTY_KEY_MAP[normalized];
    return null;
}
/** The names translateKeyName accepts (for help text and tests). */
function knownKeyNames() {
    return Object.keys(PTY_KEY_MAP);
}
/**
 * The whole of `surface.send_key`: a key name plus modifiers → the bytes to write.
 *
 * This is shared rather than duplicated because the two hosts had drifted badly.
 * The GUI did the full job; the daemon carried a separate scaffold that knew nine
 * key names, dropped `alt` on the floor, and — worst — returned the key NAME for
 * anything it did not recognise. Over SSH, `comux send-key pageup` therefore
 * typed the literal word "pageup" into the user's shell, and `ctrl-c` typed
 * "ctrl-c" instead of interrupting.
 *
 * Order matters and matches the GUI's (verified) behaviour: translate the name
 * first, then fold in ctrl, then prefix alt. Doing ctrl before translation would
 * turn `ctrl-c` (a table entry) into something else entirely.
 *
 * An unknown name is an ERROR, never a guess — writing an arbitrary string into
 * a live shell is the failure this replaces.
 */
function resolveKeyBytes(key, modifiers = []) {
    const has = (m) => modifiers.includes(m);
    const translated = translateKeyName(key, has('shift'));
    if (translated === null) {
        return {
            ok: false,
            error: `unknown key name: "${key}" (use one of: ${knownKeyNames().join(', ')}, or a single character)`,
        };
    }
    let bytes = translated;
    // Ctrl+letter → the C0 control byte. Only meaningful for a single character;
    // `ctrl` alongside `pageup` has no encoding, so it is ignored rather than
    // mangling the escape sequence.
    if (has('ctrl') && bytes.length === 1) {
        const code = bytes.toUpperCase().charCodeAt(0) - 64;
        if (code > 0 && code < 27)
            bytes = String.fromCharCode(code);
    }
    // Alt/Meta is the ESC prefix, and it composes with everything above.
    if (has('alt'))
        bytes = `\x1b${bytes}`;
    return { ok: true, bytes };
}

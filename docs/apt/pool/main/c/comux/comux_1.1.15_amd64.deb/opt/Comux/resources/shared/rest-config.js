"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VALID_AGENTS = exports.VALID_MODES = void 0;
exports.normalizeEndpointName = normalizeEndpointName;
exports.isValidPort = isValidPort;
exports.getRestConfig = getRestConfig;
exports.saveRestConfig = saveRestConfig;
exports.updateRestConfig = updateRestConfig;
exports.regenerateRestToken = regenerateRestToken;
exports.restConfigPath = restConfigPath;
exports.reloadRestConfig = reloadRestConfig;
exports.upsertEndpoint = upsertEndpoint;
exports.removeEndpoint = removeEndpoint;
/**
 * Persistence for the external REST API config (enabled / host / port / token).
 *
 * Lives in a small JSON file under the per-instance appData dir (same scheme as
 * sessions, via getAppDataDir). The main process reads this to decide whether to
 * start the HTTP server and which token to require. The token is generated once
 * on first read and kept stable across restarts so external automation can hold
 * a long-lived credential.
 */
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const crypto_1 = __importDefault(require("crypto"));
const instance_1 = require("./instance");
const fs_atomic_1 = require("./fs-atomic");
const CONFIG_FILE = path_1.default.join((0, instance_1.getAppDataDir)(), 'rest-api.json');
const DEFAULTS = {
    enabled: false,
    host: '127.0.0.1',
    port: 7878,
    endpoints: [],
};
exports.VALID_MODES = ['plan', 'accept', 'auto'];
exports.VALID_AGENTS = ['claude', 'codex', 'gemini'];
/**
 * Collapse an endpoint name to its persisted form: it becomes the URL path
 * segment of `POST /api/<name>`, so spaces and slashes can't survive.
 *
 * Exported because every caller that looks an endpoint up BY NAME has to match
 * what was written. `upsertEndpoint('my ep')` comparing raw would append a second
 * `my-ep`, which sanitizeEndpoints then silently drops as a duplicate — the edit
 * would just vanish.
 */
function normalizeEndpointName(raw) {
    return raw.trim().replace(/[\s/\\]+/g, '-');
}
/** Normalize a persisted endpoint list, dropping malformed/duplicate entries. */
function sanitizeEndpoints(raw) {
    if (!Array.isArray(raw))
        return [];
    const seen = new Set();
    const out = [];
    for (const e of raw) {
        if (!e || typeof e !== 'object')
            continue;
        const ep = e;
        // The name forms the URL path segment (POST /api/<name>) — collapse spaces
        // and slashes so a typed name can't break routing.
        const name = typeof ep.name === 'string' ? normalizeEndpointName(ep.name) : '';
        if (!name)
            continue;
        const key = name.toLowerCase();
        if (seen.has(key))
            continue; // names must be unique (they form the URL path)
        seen.add(key);
        out.push({
            id: typeof ep.id === 'string' && ep.id ? ep.id : `ep-${crypto_1.default.randomUUID()}`,
            name,
            agent: exports.VALID_AGENTS.includes(ep.agent) ? ep.agent : 'claude',
            prompt: typeof ep.prompt === 'string' ? ep.prompt : '',
            cwd: typeof ep.cwd === 'string' ? ep.cwd : '',
            // Default to the safest mode. 'auto' maps to bypassPermissions/yolo
            // (token = host RCE), so a missing/invalid mode must NOT silently become it.
            mode: exports.VALID_MODES.includes(ep.mode) ? ep.mode : 'plan',
        });
    }
    return out;
}
function generateToken() {
    return crypto_1.default.randomBytes(24).toString('hex');
}
/** A port http.Server will actually accept. */
function isValidPort(v) {
    return typeof v === 'number' && Number.isInteger(v) && v > 0 && v < 65536;
}
let cached = null;
/** Read the config (cached). Generates+persists a token on first run. */
function getRestConfig() {
    if (cached)
        return cached;
    let parsed = {};
    try {
        parsed = JSON.parse(fs_1.default.readFileSync(CONFIG_FILE, 'utf-8'));
    }
    catch {
        /* missing or corrupt → fall back to defaults */
    }
    const hadToken = typeof parsed.token === 'string' && parsed.token.length > 0;
    const config = {
        enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : DEFAULTS.enabled,
        host: typeof parsed.host === 'string' && parsed.host ? parsed.host : DEFAULTS.host,
        // Same range the write path clamps to (updateRestConfig). Validating only on
        // write let a hand-edited `"port": 99999` reach srv.listen() and throw
        // ERR_SOCKET_BAD_PORT, which the server only console.error's — the API just
        // never came up, with nothing in the UI to say why.
        port: isValidPort(parsed.port) ? parsed.port : DEFAULTS.port,
        token: hadToken ? parsed.token : generateToken(),
        endpoints: sanitizeEndpoints(parsed.endpoints),
    };
    cached = config;
    // Persist if the file was missing/tokenless, so the token is stable next launch.
    if (!hadToken)
        saveRestConfig(config);
    return config;
}
/** Overwrite the whole config and persist it. */
function saveRestConfig(config) {
    cached = config;
    try {
        fs_1.default.mkdirSync(path_1.default.dirname(CONFIG_FILE), { recursive: true, mode: 0o700 });
        // 0600 + atomic: this file holds the bearer token that drives terminals, so
        // it is RCE-equivalent (see the non-loopback warning in `comux rest enable`)
        // — and it was being written with the process umask, i.e. world-readable on
        // a stock Linux box. The rename also re-tightens a file created earlier.
        (0, fs_atomic_1.atomicWritePrivateFileSync)(CONFIG_FILE, JSON.stringify(config, null, 2));
    }
    catch (err) {
        console.error('[comux] Failed to write rest-api.json:', err.message);
    }
    return config;
}
/**
 * Merge a partial update (host/port/enabled/endpoints) into the saved config.
 *
 * Re-reads from disk FIRST. `getRestConfig()` memoizes for the life of the
 * process and nothing watches the file, so merging over the cache meant a
 * long-lived host — the GUI, or comuxd — wrote back whatever it happened to read
 * at startup. Toggling one checkbox in Settings then silently reverted every
 * change made since: a rotated token, a `comux rest add-endpoint`, a hand-edited
 * host. On a file that holds the credential driving terminals, that is data loss.
 *
 * This narrows the window to the read-modify-write itself rather than closing it
 * — two processes saving at the same instant are still last-writer-wins — but
 * that window is microseconds instead of a whole session.
 */
function updateRestConfig(partial) {
    const next = { ...reloadRestConfig(), ...partial };
    // Never allow an empty token — a tokenless server would be unauthenticated.
    if (!next.token)
        next.token = generateToken();
    // Clamp the port to a sane range.
    if (!isValidPort(next.port))
        next.port = DEFAULTS.port;
    // Re-validate endpoints whenever they're touched (or seed an empty array).
    next.endpoints = sanitizeEndpoints(next.endpoints);
    return saveRestConfig(next);
}
/** Roll a fresh token (invalidates all existing external credentials). */
function regenerateRestToken() {
    return updateRestConfig({ token: generateToken() });
}
/**
 * Absolute path of rest-api.json. Printed by `comux rest status` because the path
 * carries the instance suffix (COMUX_INSTANCE, or `-dev` for an unpackaged run) —
 * without showing it, editing the prod config while a dev instance reads
 * `comux-dev` looks like the setting simply had no effect.
 */
function restConfigPath() {
    return CONFIG_FILE;
}
/**
 * Forget the cached config and re-read it from disk.
 *
 * `comux rest enable` rewrites the file from its OWN short-lived process, so a
 * long-lived host (the GUI, or comuxd) still holds whatever it cached at startup.
 * The `rest.reload` pipe method calls this and then re-runs startRestServer, which
 * is what lets the change land without restarting the daemon and dropping every
 * shell it owns.
 */
function reloadRestConfig() {
    cached = null;
    return getRestConfig();
}
/**
 * Add an endpoint, or merge `spec`'s provided fields into the existing one with
 * that name. Pure — the caller persists through updateRestConfig, which
 * re-validates the result (so a bad agent/mode can't slip in this way either).
 */
function upsertEndpoint(endpoints, spec) {
    const name = normalizeEndpointName(spec.name);
    const key = name.toLowerCase();
    const idx = endpoints.findIndex((e) => e.name.toLowerCase() === key);
    if (idx < 0) {
        return [
            ...endpoints,
            {
                id: `ep-${crypto_1.default.randomUUID()}`,
                name,
                agent: spec.agent ?? 'claude',
                prompt: spec.prompt ?? '',
                cwd: spec.cwd ?? '',
                // Matches sanitizeEndpoints' default: 'auto' means bypassPermissions/yolo,
                // which must never be reached by omission.
                mode: spec.mode ?? 'plan',
            },
        ];
    }
    const next = endpoints.slice();
    next[idx] = {
        ...next[idx],
        name, // keep the id — a re-add is an edit, not a new endpoint
        ...(spec.agent !== undefined && { agent: spec.agent }),
        ...(spec.mode !== undefined && { mode: spec.mode }),
        ...(spec.cwd !== undefined && { cwd: spec.cwd }),
        ...(spec.prompt !== undefined && { prompt: spec.prompt }),
    };
    return next;
}
/** Drop the endpoint with this name. `removed` is null when nothing matched, so
 *  the caller can report "no such endpoint" instead of a silent no-op. */
function removeEndpoint(endpoints, name) {
    const key = normalizeEndpointName(name).toLowerCase();
    const removed = endpoints.find((e) => e.name.toLowerCase() === key) ?? null;
    return { endpoints: removed ? endpoints.filter((e) => e !== removed) : endpoints, removed };
}

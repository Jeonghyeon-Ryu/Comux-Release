"use strict";
/**
 * Type a command into a freshly spawned shell once it is at a prompt.
 *
 * Writing straight after spawn loses the text: PowerShell with comux's
 * integration takes 1–3s to reach its first prompt and discards input typed
 * while its profile loads. agent-manager learned this first (a blind 800ms
 * timeout dropped agent commands); this is the same rule, shared so a
 * worktree's setup commands and an agent's launch line behave alike on both
 * hosts.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SHELL_PROMPT_RE = void 0;
exports.typeWhenShellReady = typeWhenShellReady;
/** A shell prompt at the end of a chunk: `PS C:\x>`, `$ `, `# `, `% `, `> `. */
exports.SHELL_PROMPT_RE = /(?:PS\s.*>|[$#%>])\s*$/m;
/** Returns a cancel function. The text is written at most once. */
function typeWhenShellReady(o) {
    const settleMs = o.settleMs ?? 1500;
    const timeoutMs = o.timeoutMs ?? 5000;
    let done = false;
    let settle = null;
    let unsubscribe = null;
    const cleanup = () => {
        done = true;
        if (settle)
            clearTimeout(settle);
        clearTimeout(fallback);
        if (unsubscribe) {
            try {
                unsubscribe();
            }
            catch { /* already gone */ }
        }
    };
    const send = () => {
        if (done)
            return;
        cleanup();
        // A beat after the prompt so the line editor has finished drawing it.
        setTimeout(() => o.write(o.text), 150);
    };
    const fallback = setTimeout(send, timeoutMs);
    unsubscribe = o.subscribe((data) => {
        if (done)
            return;
        if (exports.SHELL_PROMPT_RE.test(data))
            send();
        else if (!settle)
            settle = setTimeout(send, settleMs);
    });
    return cleanup;
}

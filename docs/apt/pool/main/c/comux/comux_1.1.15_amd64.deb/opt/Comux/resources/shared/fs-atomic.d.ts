/**
 * Write a file atomically: write a temp sibling, then rename over the target
 * (atomic replace on the same filesystem). A crash / power-loss / disk-full
 * mid-write then leaves the ORIGINAL intact instead of a truncated or empty
 * file — important for the user's hand-authored ~/.claude and ~/.config files
 * that comux mutates but does not own, where a partial write would also make a
 * later JSON.parse fail forever.
 *
 * The trailing encoding arg is accepted (and ignored — always UTF-8) so existing
 * `writeFileSync(path, data, 'utf-8')` call sites need no change.
 */
export declare function atomicWriteFileSync(filePath: string, content: string, _encoding?: BufferEncoding): void;
/**
 * Same, but the file is only readable by its owner (0600).
 *
 * For files that ARE a credential: `rest-api.json` holds the REST bearer token,
 * which drives terminals and is therefore RCE-equivalent (the CLI says so when
 * you enable a non-loopback bind), and `rest-api-logs.json` records the prompt
 * text of every API call. Both were written with the process umask — 0644 on a
 * typical Linux box, so every local account could read them.
 *
 * The mode goes on the TEMP file and rename carries it across, which also fixes
 * up an already-created world-readable file and leaves no window where the new
 * content exists at the old permissions. Windows ignores the mode (ACLs are
 * inherited from the directory) — this is a POSIX fix, and on Windows the
 * appData dir is already per-user.
 */
export declare function atomicWritePrivateFileSync(filePath: string, content: string): void;

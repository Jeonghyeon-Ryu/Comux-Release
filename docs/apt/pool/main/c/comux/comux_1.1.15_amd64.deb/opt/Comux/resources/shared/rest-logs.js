"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.estimateTokens = estimateTokens;
exports.appendRestLog = appendRestLog;
exports.getRestLogs = getRestLogs;
exports.clearRestLogs = clearRestLogs;
/**
 * Usage-log persistence for the external REST API.
 *
 * Every input-injecting request (and unauthorized attempt) is appended here so
 * the titlebar "API logs" dialog can show who used which API, from where, when,
 * with what input, and an estimated token count. Stored as a rolling JSON array
 * under the per-instance appData dir (same scheme as rest-api.json), capped so
 * the file can't grow unbounded.
 */
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const crypto_1 = __importDefault(require("crypto"));
const instance_1 = require("./instance");
const LOG_FILE = path_1.default.join((0, instance_1.getAppDataDir)(), 'rest-api-logs.json');
/** Keep the most recent N entries. Old ones are evicted FIFO. */
const MAX_ENTRIES = 1000;
/** Never store an input larger than this (chars of text) — bounds file size. */
const MAX_INPUT_CHARS = 4000;
let cache = null;
function load() {
    if (cache)
        return cache;
    try {
        const parsed = JSON.parse(fs_1.default.readFileSync(LOG_FILE, 'utf-8'));
        cache = Array.isArray(parsed) ? parsed : [];
    }
    catch {
        cache = [];
    }
    return cache;
}
let persistTimer = null;
/**
 * Debounced async persist. Previously every request did a SYNCHRONOUS full-file
 * rewrite on the main thread, so an unauthenticated flood could freeze the UI.
 * Now a burst coalesces into a single off-thread write (the in-memory `cache` is
 * the source of truth for reads, so the UI is unaffected by the write delay).
 */
function persist(_entries) {
    if (persistTimer)
        return;
    persistTimer = setTimeout(() => {
        persistTimer = null;
        const snapshot = JSON.stringify(cache ?? []);
        fs_1.default.mkdir(path_1.default.dirname(LOG_FILE), { recursive: true, mode: 0o700 }, () => {
            // 0600: these entries carry the PROMPT TEXT of every API call, and the
            // file was written with the process umask. Kept async (a burst must not
            // block the main thread) so the mode rides on the open, with a chmod
            // fix-up for a file an older build already created world-readable.
            fs_1.default.writeFile(LOG_FILE, snapshot, { encoding: 'utf-8', mode: 0o600 }, (err) => {
                if (err) {
                    console.error('[comux] Failed to write rest-api-logs.json:', err.message);
                    return;
                }
                if (process.platform !== 'win32')
                    fs_1.default.chmod(LOG_FILE, 0o600, () => { });
            });
        });
    }, 1000);
}
/** True for a code point in the wide CJK/Hangul/fullwidth ranges. */
function isCjk(c) {
    return ((c >= 0x3000 && c <= 0x9fff) || // CJK symbols, kana, ideographs
        (c >= 0xac00 && c <= 0xd7af) || // Hangul syllables
        (c >= 0xf900 && c <= 0xfaff) || // CJK compatibility ideographs
        (c >= 0xff00 && c <= 0xffef) // fullwidth / halfwidth forms
    );
}
/**
 * Rough token estimate (no tokenizer is bundled). Latin-ish text averages ~4
 * chars/token; CJK/Hangul averages closer to ~1 token/char. Good enough for a
 * usage gauge, intentionally labeled "estimated" in the UI.
 */
function estimateTokens(text) {
    if (!text)
        return 0;
    let cjk = 0;
    for (const ch of text) {
        const c = ch.codePointAt(0);
        if (c !== undefined && isCjk(c))
            cjk++;
    }
    const rest = text.length - cjk;
    return Math.max(1, Math.round(rest / 4 + cjk));
}
/** Append one usage event. id + timestamp are filled in here. */
function appendRestLog(entry) {
    const entries = load();
    const input = entry.input.length > MAX_INPUT_CHARS
        ? entry.input.slice(0, MAX_INPUT_CHARS) + '...'
        : entry.input;
    entries.push({
        ...entry,
        input,
        id: `log-${crypto_1.default.randomUUID()}`,
        timestamp: Date.now(),
    });
    if (entries.length > MAX_ENTRIES)
        entries.splice(0, entries.length - MAX_ENTRIES);
    cache = entries;
    persist(entries);
}
/** Return all logs, newest first. */
function getRestLogs() {
    return [...load()].reverse();
}
/** Wipe the log. */
function clearRestLogs() {
    cache = [];
    persist([]);
}

"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.atomicWriteFileSync = atomicWriteFileSync;
exports.atomicWritePrivateFileSync = atomicWritePrivateFileSync;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
/**
 * Write a file atomically: write a temp sibling, then rename over the target
 * (atomic replace on the same filesystem). A crash / power-loss / disk-full
 * mid-write then leaves the ORIGINAL intact instead of a truncated or empty
 * file — important for the user's hand-authored ~/.claude and ~/.config files
 * that comux mutates but does not own, where a partial write would also make a
 * later JSON.parse fail forever.
 *
 * The trailing encoding arg is accepted (and ignored — always UTF-8) so existing
 * `writeFileSync(path, data, 'utf-8')` call sites need no change.
 */
function atomicWriteFileSync(filePath, content, _encoding) {
    write(filePath, content);
}
/**
 * Same, but the file is only readable by its owner (0600).
 *
 * For files that ARE a credential: `rest-api.json` holds the REST bearer token,
 * which drives terminals and is therefore RCE-equivalent (the CLI says so when
 * you enable a non-loopback bind), and `rest-api-logs.json` records the prompt
 * text of every API call. Both were written with the process umask — 0644 on a
 * typical Linux box, so every local account could read them.
 *
 * The mode goes on the TEMP file and rename carries it across, which also fixes
 * up an already-created world-readable file and leaves no window where the new
 * content exists at the old permissions. Windows ignores the mode (ACLs are
 * inherited from the directory) — this is a POSIX fix, and on Windows the
 * appData dir is already per-user.
 */
function atomicWritePrivateFileSync(filePath, content) {
    write(filePath, content, 0o600);
}
function write(filePath, content, mode) {
    const tmp = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${process.pid}.tmp`);
    try {
        fs.writeFileSync(tmp, content, mode === undefined ? 'utf-8' : { encoding: 'utf-8', mode });
        // `mode` in writeFileSync only applies when the file is CREATED, so a stale
        // temp left by a crashed run with the same pid would keep its old bits.
        if (mode !== undefined && process.platform !== 'win32') {
            try {
                fs.chmodSync(tmp, mode);
            }
            catch { /* best effort — rename still runs */ }
        }
        fs.renameSync(tmp, filePath);
    }
    catch (err) {
        try {
            fs.unlinkSync(tmp);
        }
        catch { /* best-effort cleanup */ }
        throw err;
    }
}

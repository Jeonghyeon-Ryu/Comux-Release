"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IPC_CHANNELS = void 0;
// IPC channel names
exports.IPC_CHANNELS = {
    // PTY
    PTY_CREATE: 'pty:create',
    PTY_WRITE: 'pty:write',
    PTY_RESIZE: 'pty:resize',
    PTY_KILL: 'pty:kill',
    PTY_HAS: 'pty:has',
    PTY_DATA: 'pty:data',
    PTY_EXIT: 'pty:exit',
    // Workspace
    WORKSPACE_CREATE: 'workspace:create',
    WORKSPACE_CLOSE: 'workspace:close',
    WORKSPACE_SELECT: 'workspace:select',
    WORKSPACE_RENAME: 'workspace:rename',
    WORKSPACE_LIST: 'workspace:list',
    WORKSPACE_REORDER: 'workspace:reorder',
    WORKSPACE_MOVE_TO_WINDOW: 'workspace:moveToWindow',
    // Surface
    SURFACE_CREATE: 'surface:create',
    SURFACE_CLOSE: 'surface:close',
    SURFACE_FOCUS: 'surface:focus',
    SURFACE_LIST: 'surface:list',
    SURFACE_READ_TEXT: 'surface:readText',
    SURFACE_SEND_TEXT: 'surface:sendText',
    SURFACE_SEND_KEY: 'surface:sendKey',
    SURFACE_TRIGGER_FLASH: 'surface:triggerFlash',
    // Pane
    PANE_SPLIT: 'pane:split',
    PANE_CLOSE: 'pane:close',
    PANE_FOCUS: 'pane:focus',
    PANE_ZOOM: 'pane:zoom',
    PANE_LIST: 'pane:list',
    // Notification
    NOTIFICATION_FIRE: 'notification:fire',
    NOTIFICATION_LIST: 'notification:list',
    NOTIFICATION_CLEAR: 'notification:clear',
    NOTIFICATION_JUMP: 'notification:jump',
    // Settings
    SETTINGS_GET: 'settings:get',
    SETTINGS_SET: 'settings:set',
    SETTINGS_CHANGED: 'settings:changed',
    // Window
    WINDOW_CREATE: 'window:create',
    WINDOW_CLOSE: 'window:close',
    WINDOW_FOCUS: 'window:focus',
    WINDOW_LIST: 'window:list',
    WINDOW_MINIMIZE: 'window:minimize',
    WINDOW_MAXIMIZE: 'window:maximize',
    WINDOW_IS_MAXIMIZED: 'window:isMaximized',
    // Config
    CONFIG_GET_THEME: 'config:getTheme',
    CONFIG_GET_THEME_LIST: 'config:getThemeList',
    CONFIG_IMPORT_WT: 'config:importWindowsTerminal',
    CONFIG_IMPORT_GHOSTTY: 'config:importGhostty',
    CONFIG_GET_USER_CONFIG: 'config:getUserConfig',
    CONFIG_RELOAD_USER_CONFIG: 'config:reloadUserConfig',
    CONFIG_USER_CONFIG_UPDATED: 'config:userConfigUpdated',
    // System
    SYSTEM_GET_SHELLS: 'system:getShells',
    SYSTEM_OPEN_EXTERNAL: 'system:openExternal',
    SYSTEM_SELECT_DIRECTORY: 'system:selectDirectory',
    SYSTEM_REPORT_ERROR: 'system:reportError', // renderer → main: ErrorBoundary crash
    // Metadata events (main → renderer)
    METADATA_UPDATE: 'metadata:update',
    // Agent
    AGENT_SPAWN: 'agent:spawn',
    AGENT_SPAWN_BATCH: 'agent:spawn-batch',
    AGENT_STATUS: 'agent:status',
    AGENT_LIST: 'agent:list',
    AGENT_KILL: 'agent:kill',
    AGENT_UPDATE: 'agent:update',
    // CDP (browser.* pipe methods map to these internal IPC channels)
    CDP_ATTACH: 'cdp:attach',
    // Design Mode: pick an element in a browser webview (main/browser-pick.ts)
    BROWSER_PICK: 'browser:pick',
    CDP_DETACH: 'cdp:detach',
    CDP_NAVIGATE: 'cdp:navigate',
    CDP_SNAPSHOT: 'cdp:snapshot',
    CDP_CLICK: 'cdp:click',
    CDP_TYPE: 'cdp:type',
    CDP_FILL: 'cdp:fill',
    CDP_SCREENSHOT: 'cdp:screenshot',
    CDP_GET_TEXT: 'cdp:get-text',
    CDP_EVAL: 'cdp:eval',
    CDP_WAIT: 'cdp:wait',
    // Browser panel actions (renderer → main; act on the webview's own session)
    BROWSER_CLEAR_CACHE: 'browser:clear-cache',
    // Active workspace query (renderer → main)
    GET_ACTIVE_WORKSPACE: 'get-active-workspace',
    // Hook events (Claude Code hooks → main → renderer)
    HOOK_EVENT: 'hook:event',
    // Claude Code activity (parsed from PTY output → renderer)
    CLAUDE_ACTIVITY: 'claude:activity',
    // One-shot snapshot of all per-surface activity (renderer reload seeding)
    CLAUDE_ACTIVITY_SNAPSHOT: 'claude:activity-snapshot',
    // Auto-saved session (the rolling 30s snapshot the main process writes)
    SESSION_LOAD_AUTO: 'session:load-auto',
    // Write that same snapshot NOW, on demand, and report whether it landed.
    // Distinct from the fire-and-forget `session:save` the 30s timer answers:
    // this one is a user action, so it needs an ack to confirm honestly.
    SESSION_SAVE_NOW: 'session:save-now',
    // Diff viewer
    DIFF_GET_FILES: 'diff:get-files',
    DIFF_GET_DIFF: 'diff:get-diff',
    DIFF_UPDATE: 'diff:update',
    // File system (code panel / file tree)
    FILE_LIST_DIR: 'file:list-dir',
    FILE_READ: 'file:read',
    FILE_WRITE: 'file:write',
    FILE_SEARCH: 'file:search',
    // File system — mutations (file tree management)
    FILE_CREATE: 'file:create',
    FILE_MKDIR: 'file:mkdir',
    FILE_RENAME: 'file:rename',
    FILE_MOVE: 'file:move',
    FILE_COPY: 'file:copy',
    FILE_TRASH: 'file:trash',
    FILE_REVEAL: 'file:reveal',
    // File system — recursive watch (auto-refresh the tree)
    FILE_WATCH_START: 'file:watch-start',
    FILE_WATCH_STOP: 'file:watch-stop',
    FILE_CHANGED: 'file:changed', // main → renderer push
    // Git per-file status (file tree decorations)
    GIT_FILE_STATUS: 'git:file-status',
    // Git worktrees (new-worktree dialog, worktree removal on workspace close)
    WORKTREE_RPC: 'worktree:rpc',
    // AI commit message / PR draft / "Fix with AI" (main/git-ai.ts)
    GIT_AI_RPC: 'git-ai:rpc',
    // Orchestration (comux-orchestrator plugin state broadcast)
    ORCHESTRATION_UPDATE: 'orchestration:update',
    ORCHESTRATION_CLEAR: 'orchestration:clear',
    // App update notification (GitHub releases polling — opens OS browser on click)
    UPDATE_AVAILABLE: 'update:available',
    UPDATE_GET_LATEST: 'update:get-latest',
    UPDATE_OPEN_RELEASE: 'update:open-release',
    UPDATE_INSTALL: 'update:install',
    UPDATE_PROGRESS: 'update:progress',
    UPDATE_PROMPT: 'update:prompt',
    // External REST API (HTTP server in main — send chat/commands into a terminal)
    REST_GET_CONFIG: 'rest:get-config',
    REST_SET_CONFIG: 'rest:set-config',
    REST_GET_STATUS: 'rest:get-status',
    REST_REGEN_TOKEN: 'rest:regenerate-token',
    REST_GET_LOGS: 'rest:get-logs',
    REST_CLEAR_LOGS: 'rest:clear-logs',
    // Attention Router (agent waiting/done → toast + webhook)
    ATTENTION_GET_CONFIG: 'attention:get-config',
    ATTENTION_SET_CONFIG: 'attention:set-config',
    // Real Claude Code token usage (parsed from ~/.claude logs)
    USAGE_GET: 'usage:get',
    USAGE_UPDATE: 'usage:update',
    // Subscription usage limits (Anthropic OAuth usage endpoint — /usage data)
    USAGE_LIMITS_GET: 'usage:limits-get',
    USAGE_LIMITS_UPDATE: 'usage:limits-update',
    // System resource metrics (main → renderer, polled CPU/RAM usage)
    SYSTEM_METRICS: 'system:metrics',
    // Provider-agnostic live LLM token meter (transparent local proxy tap —
    // works for Claude/Codex/Gemini/local sLLM, any tool with a base-URL override)
    LLM_TOKENS_UPDATE: 'llm:tokens:update', // main → renderer snapshot push
    LLM_METER_GET: 'llm:meter:get', // renderer → main: { config, snapshot }
    LLM_METER_SET_ENABLED: 'llm:meter:set-enabled',
    // Log-parser backstop: per-tool cumulative token totals read from each CLI's
    // own session logs (~/.codex, ~/.gemini) — catches what the proxy tap can't.
    TOOL_USAGE_GET: 'tool-usage:get',
    TOOL_USAGE_UPDATE: 'tool-usage:update',
    // Code intelligence (hover types + go-to-definition for the code panel)
    CODE_HOVER: 'code:hover',
    CODE_DEFINITION: 'code:definition',
    CODE_DID_OPEN: 'code:did-open',
    CODE_DID_CHANGE: 'code:did-change',
    CODE_DID_CLOSE: 'code:did-close',
    CODE_STATUS: 'code:status', // main → renderer push
    // Core session write-path inversion: renderer sends a command (a SessionModel
    // mutation) to main, main applies it to the authoritative SessionModel and
    // broadcasts the resulting {workspaces, activeWorkspaceId} to every window.
    CORE_COMMAND: 'core:command', // renderer → main: { method, args, id? }
    CORE_STATE_UPDATE: 'core:state-update', // main → renderer: authoritative snapshot
    CORE_REQUEST_STATE: 'core:request-state', // renderer → main (invoke): current snapshot
};

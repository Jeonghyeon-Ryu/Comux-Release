import { RestEndpointMode, RestEndpointAgent } from './types';
import { WORKING_RE, detectWaitingForInput } from './agent-detect';
export interface RestServerDeps {
    /** Write raw bytes to a terminal PTY (surfaceId == PTY id). */
    write: (surfaceId: string, data: string) => void;
    /** Resolve/validate a surfaceId (undefined → active surface); errors if not a live terminal. */
    resolvePtySurface: (id: string | undefined) => Promise<{
        ok: true;
        id: `surf-${string}`;
    } | {
        ok: false;
        error: string;
    }>;
    /** Reverse lookup: is an agent (e.g. spawned Claude) bound to this surface? */
    getAgentBySurface: (surfaceId: string) => {
        agentId: string;
        label: string;
        status: string;
    } | undefined;
    /** Claude busy/idle activity for a surface (from the PTY observer), if any. */
    getActivity: (surfaceId: string) => {
        isDone: boolean;
        lastUpdate: number;
    } | undefined;
    /** Read a terminal's on-screen plain text (newest `maxLines` rows, ANSI stripped). */
    readScreen: (surfaceId: string, maxLines?: number) => Promise<string>;
    /** True if a live PTY exists for this surface (used to decide whether to relaunch). */
    ptyHas: (surfaceId: string) => boolean;
    /**
     * Launch a fresh agent session (claude/codex/gemini) in a visible terminal,
     * seeded with `prompt` as its first message. Resolves once the prompt has been
     * delivered and the agent has begun working, returning the surfaceId and a
     * `baseline` snapshot of the screen at that point — the response wait diffs
     * against this so the agent's startup banner isn't mistaken for its reply.
     */
    launchAgent: (opts: {
        agent: RestEndpointAgent;
        cwd: string;
        mode: RestEndpointMode;
        prompt: string;
        label: string;
    }) => Promise<{
        ok: true;
        surfaceId: string;
        baseline: string;
    } | {
        ok: false;
        error: string;
    }>;
    /** The raw terminal/surface list (each carrying a `surfaceId`); merged here with agent + activity info. The GUI reads it from the renderer; the daemon builds it from its SessionModel. */
    listSurfaces: () => Promise<any[]> | any[];
    /** App version, surfaced on /health. */
    version: string;
}
export declare class RestBusyError extends Error {
    /** 409 = the holder outlasted our patience; 429 = the queue was already full. */
    readonly status: 409 | 429;
    constructor(message: string, 
    /** 409 = the holder outlasted our patience; 429 = the queue was already full. */
    status: 409 | 429);
}
/**
 * Run `fn` with exclusive access to `key`. Throws RestBusyError rather than
 * queueing without bound or waiting forever — a stuck agent must not silently
 * accumulate blocked HTTP connections.
 */
export declare function withLock<T>(key: string, fn: () => Promise<T>, timeoutMs?: number): Promise<T>;
/** Test seam: drop all lock state between cases. */
export declare function __resetRestLocks(): void;
/**
 * Compose the message sent to Claude from an endpoint's prompt template and the
 * request's input. `{input}` is substituted; absent it, the input is appended.
 *
 * Newlines are PRESERVED here. Long prompts are delivered by bracketed paste
 * (see writeAgentMessage / seedAgentBaseline), where embedded newlines are safe
 * — collapsing them would flatten a structured markdown prompt into one line and
 * lose its tables/lists/code fences (and the giant single line truncates in the
 * TUI). The collapse-to-one-line guard is applied only on the paths that type
 * the text raw (Enter would submit early): the typed branch of writeAgentMessage
 * and the CLI-argument launch path.
 */
export declare function composeMessage(prompt: string, input: string): string;
/** Collapse newlines to spaces — for paths that TYPE text raw (where a bare
 *  newline would submit early). Paste paths must NOT use this (newlines safe). */
export declare function flattenForTyping(text: string): string;
export { WORKING_RE, detectWaitingForInput };
/**
 * Answer a Claude select/permission menu by option number, the way its footer
 * advertises ("Tab/Arrow keys to navigate · Enter to select"): step down from
 * the first (highlighted) option N-1 times, then Enter. This is version-proof —
 * unlike typing the digit, which not every menu accepts as a shortcut.
 */
export declare function selectMenuOption(write: (id: string, data: string) => void, surfaceId: string, n: number): void;
/**
 * Hold until the agent on `surfaceId` finishes the turn it just started, then
 * return its freshly-printed text (the delta vs `before`).
 *
 * Resolution is one of three states, whichever is reached first:
 *   - done    — the turn completed (observer busy→idle, or screen settled and no
 *               pending prompt). The caller has the full reply.
 *   - waiting — Claude paused for a permission/confirmation prompt; the caller
 *               should POST a follow-up answer to the SAME endpoint/surface.
 *   - neither — timed out; partial text is returned with done=false.
 *
 * The observer's busy→idle transition is preferred (reliable for Claude); a
 * quiet-screen fallback covers shells / agents the observer can't parse, after a
 * START_GRACE_MS warm-up so we don't return before the reply has begun.
 */
export declare function waitForResponse(deps: RestServerDeps, surfaceId: string, before: string, timeoutMs: number): Promise<{
    done: boolean;
    waiting: boolean;
    response: string;
}>;
export declare function extractResponse(before: string, after: string): string;
/**
 * Whether the HTTP listener is actually up — which is NOT the same as
 * `config.enabled`. A port clash (another comux, or anything else on 7878) fails
 * asynchronously in `listen`, so the config keeps claiming the API is on while
 * nothing is bound. That used to be a lone console.error nobody reads; now it is
 * recorded here and reported by `comux rest status/enable`, the `rest.status`
 * pipe method, and the Settings panel.
 */
export interface RestServerStatus {
    /** Config says run (independent of whether the bind succeeded). */
    enabled: boolean;
    /** The listener is bound and accepting requests right now. */
    listening: boolean;
    host: string;
    port: number;
    /** Human-readable reason the listener is down, or null. */
    error: string | null;
    /** Errno-style code when the failure came from the OS (EADDRINUSE, EACCES…). */
    code: string | null;
}
export declare function getRestServerStatus(): RestServerStatus;
/** Turn a listen error into something a user can act on. (Exported for tests —
 *  this string is the whole user-facing product of a failed bind.) */
export declare function describeListenError(err: NodeJS.ErrnoException, host: string, port: number): string;
/**
 * Decode a request body to text. Prefer strict UTF-8; if the bytes aren't valid
 * UTF-8, fall back to legacy Windows code pages (CP949/EUC-KR for Korean, then
 * Windows-1252). Clients such as Git Bash's curl on a Korean Windows box encode
 * the body in the system ANSI code page, not UTF-8 — without this, that Korean
 * arrives garbled long before any PTY write. ASCII is valid UTF-8, so it always
 * takes the fast path and is never touched.
 */
export declare function decodeBody(buf: Buffer): {
    text: string;
    encoding: string;
};
/**
 * Merge the renderer's terminal list with agent + Claude-activity info from main.
 * Exported for tests: the /terminals filter is the whole point of this function
 * and starting a real server to check it would touch the user's rest-api.json.
 */
export declare function listTerminals(deps: RestServerDeps): Promise<any[]>;
/**
 * Start (or restart) the REST server using the current persisted config.
 *
 * Resolves once the outcome is known — bound, or failed to bind — so callers
 * (`rest.reload` over the pipe, the Settings IPC) can report the real result
 * instead of optimistically echoing the config back.
 */
export declare function startRestServer(deps: RestServerDeps): Promise<RestServerStatus>;
/** Stop the server if running. */
export declare function stopRestServer(): void;
/** Restart using the deps captured at the last start (after a config change). */
export declare function reloadRestServer(): Promise<RestServerStatus>;

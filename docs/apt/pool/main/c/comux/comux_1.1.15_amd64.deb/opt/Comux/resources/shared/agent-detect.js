"use strict";
// Shared agent-TUI state detection. Both the REST server (which waits on an
// agent turn) and the PTY observer (which drives the sidebar + Attention Router)
// need to recognise "still working" vs "paused waiting for the user", so the
// patterns live here in one place rather than being duplicated/drifting.
//
// The two directions are NOT symmetric, and the patterns below are deliberately
// tuned around that:
//
//   Missing "working"  → the caller decides the turn ended early and returns a
//                        half-written reply. Bad, and silent.
//   Extra   "working"  → the caller waits a bit longer, then falls back to the
//                        screen-settled heuristic. Harmless.
//   Extra   "waiting"  → the caller returns `waiting:true` mid-reply and the
//                        user is asked to answer a prompt that isn't there. Bad.
//
// So the working set is generous and the waiting set is strict.
Object.defineProperty(exports, "__esModule", { value: true });
exports.WORKING_RE = void 0;
exports.detectWaitingForInput = detectWaitingForInput;
/**
 * The agent is mid-turn.
 *
 * Claude Code prints "esc to interrupt" on its live status line. "interrupt" is
 * load-bearing here and the wording may NOT be relaxed to cover more CLIs: a
 * menu footer reads "Enter to select · esc to cancel", so accepting "esc to
 * cancel" as a working signal inverts every waiting screen into a working one.
 * (Tried it; two tests caught it immediately, and rest-server already classifies
 * that exact string as menu chrome.) Only affordances that are specific to an
 * interruptible, in-flight turn belong here.
 */
exports.WORKING_RE = /esc to interrupt|ctrl\+c to interrupt/i;
/**
 * Prompt shapes that mean "the agent stopped and needs an answer".
 *
 * Kept to constructs that do not occur in ordinary prose or code output, since a
 * false positive truncates a reply. Anything agent-specific enough to be a guess
 * is left out — the callers already have a screen-settled fallback that works for
 * any TUI, so a missing pattern degrades to "slightly slower", not "wrong".
 */
const WAITING_PATTERNS = [
    // Claude: "Do you want to proceed?" and friends.
    /Do you want to (?:proceed|create|make|run|apply|continue)/i,
    // A numbered menu with the arrow cursor on an option (claude, codex, gemini all
    // render some variant of this).
    /❯\s*\d+\.\s/,
    // "1. Yes" / "2. No" confirm menu.
    /\b1\.\s*Yes\b/i,
    // (y/n) / (y/N) inline prompt — the most portable confirmation there is.
    /\(\s*y\s*\/\s*n\s*\)/i,
    // Selection-list footers.
    /Enter to select/i,
    // Generic approval questions used by the sandboxed CLIs when a command or an
    // edit needs sign-off. Question-mark anchored so prose cannot trigger them.
    /\b(?:Allow|Approve|Apply)\b[^\n?]{0,60}\?/i,
];
/**
 * Detect that the agent has paused mid-turn waiting for the user — a permission
 * prompt ("Do you want to proceed?" with a numbered ❯ menu), a y/n confirmation,
 * or any selection list. In `accept`/`plan` mode Claude still stops here for
 * non-edit actions, so callers need to know the turn isn't finished — it's blocked.
 *
 * Only the tail is inspected (the live prompt is at the bottom of the screen),
 * and the working spinner is excluded — a prompt is only "waiting" once the
 * agent has stopped processing.
 */
function detectWaitingForInput(text) {
    const tail = text.split('\n').slice(-14).join('\n');
    if (exports.WORKING_RE.test(tail))
        return false; // still working, not waiting
    return WAITING_PATTERNS.some((re) => re.test(tail));
}

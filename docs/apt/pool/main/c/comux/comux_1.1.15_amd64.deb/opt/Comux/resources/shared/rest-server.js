"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.detectWaitingForInput = exports.WORKING_RE = exports.RestBusyError = void 0;
exports.withLock = withLock;
exports.__resetRestLocks = __resetRestLocks;
exports.composeMessage = composeMessage;
exports.flattenForTyping = flattenForTyping;
exports.selectMenuOption = selectMenuOption;
exports.waitForResponse = waitForResponse;
exports.extractResponse = extractResponse;
exports.getRestServerStatus = getRestServerStatus;
exports.describeListenError = describeListenError;
exports.decodeBody = decodeBody;
exports.listTerminals = listTerminals;
exports.startRestServer = startRestServer;
exports.stopRestServer = stopRestServer;
exports.reloadRestServer = reloadRestServer;
/**
 * External REST API server (HTTP, main process).
 *
 * A thin front door over the existing PTY mechanism: outside clients authenticate
 * with a Bearer token, discover terminals (GET /terminals), and inject chat/
 * commands into a specific terminal (POST /terminals/:surfaceId/input). Input is
 * fire-and-forget by default — it writes the text (plus Enter) to the PTY and
 * returns immediately. Pass `{ "wait": true }` to instead hold the request open
 * until the agent finishes its turn and read its on-screen reply back in the
 * `response` field (the `/api/:name` endpoints wait by default). The reply is
 * scraped from the visible terminal, so the user still watches it live.
 *
 * Reuses the same `ptyManager.write` + `resolvePtySurface` path as the named-pipe
 * `surface.send_text` handler, so external writes reach real user terminals.
 *
 * Security: token required on every request (constant-time compare); the server
 * never starts without a token or when disabled. Defaults to binding 127.0.0.1 —
 * to reach it remotely, front it with a tunnel (cloudflared/ngrok) rather than
 * exposing the port directly.
 */
const http_1 = __importDefault(require("http"));
const crypto_1 = __importDefault(require("crypto"));
const rest_config_1 = require("./rest-config");
const rest_logs_1 = require("./rest-logs");
const agent_detect_1 = require("./agent-detect");
Object.defineProperty(exports, "WORKING_RE", { enumerable: true, get: function () { return agent_detect_1.WORKING_RE; } });
Object.defineProperty(exports, "detectWaitingForInput", { enumerable: true, get: function () { return agent_detect_1.detectWaitingForInput; } });
const MAX_BODY = 64 * 1024;
/**
 * Per-endpoint Claude session binding: endpoint id → the surfaceId of the
 * terminal we last launched Claude into. Lets a follow-up request reuse the
 * running session instead of spawning a new one. Lives in memory — on restart
 * the first request to each endpoint re-launches, which is the safe default.
 */
const endpointBindings = new Map();
// ── Per-key serialization ────────────────────────────────────────────────────
/**
 * A terminal is a single-writer device: two requests writing to one surface
 * interleave their keystrokes inside the agent's input box, and the resulting
 * mush is submitted as one prompt. Two concurrent FIRST requests to the same
 * endpoint are worse — both find no binding and each launches its own agent,
 * leaving an orphan burning tokens in a pane nobody answers.
 *
 * So writes are serialized per key: `surface:<id>` for a terminal, and
 * `endpoint:<id>` around the whole /api/:name request (taken first, so the
 * launch decision and the binding write are inside one critical section).
 * Lock order is always endpoint → surface, never the reverse, so the nesting in
 * /api/:name cannot deadlock against /terminals holding a surface lock.
 *
 * A holder keeps the lock for its entire turn — including a `wait` that can run
 * minutes — which is the point: the second prompt must not land mid-turn. The
 * multi-step permission flow is unaffected, because a request that hits a prompt
 * returns `waiting:true` and releases before the caller sends the answer.
 */
const locks = new Map();
/** How long a request waits for a busy key before giving up with 409. */
const LOCK_ACQUIRE_TIMEOUT_MS = 60_000;
/** Waiters per key; beyond this the API sheds load (429) instead of queueing. */
const LOCK_MAX_QUEUE = 16;
class RestBusyError extends Error {
    status;
    constructor(message, 
    /** 409 = the holder outlasted our patience; 429 = the queue was already full. */
    status) {
        super(message);
        this.status = status;
        this.name = 'RestBusyError';
    }
}
exports.RestBusyError = RestBusyError;
/**
 * Run `fn` with exclusive access to `key`. Throws RestBusyError rather than
 * queueing without bound or waiting forever — a stuck agent must not silently
 * accumulate blocked HTTP connections.
 */
async function withLock(key, fn, timeoutMs = LOCK_ACQUIRE_TIMEOUT_MS) {
    let lock = locks.get(key);
    if (!lock) {
        lock = { held: false, queue: [] };
        locks.set(key, lock);
    }
    if (lock.held) {
        if (lock.queue.length >= LOCK_MAX_QUEUE) {
            throw new RestBusyError(`too many requests queued for ${key} — try again later`, 429);
        }
        await new Promise((resolve, reject) => {
            let settled = false;
            const timer = setTimeout(() => {
                if (settled)
                    return;
                settled = true;
                const i = lock.queue.indexOf(wake);
                if (i >= 0)
                    lock.queue.splice(i, 1);
                reject(new RestBusyError(`${key} is busy with another request (waited ${Math.round(timeoutMs / 1000)}s)`, 409));
            }, timeoutMs);
            const wake = () => {
                if (settled)
                    return;
                settled = true;
                clearTimeout(timer);
                resolve();
            };
            lock.queue.push(wake);
        });
    }
    lock.held = true;
    try {
        return await fn();
    }
    finally {
        const next = lock.queue.shift();
        if (next) {
            next(); // hand the lock straight over; `held` stays true for the waiter
        }
        else {
            lock.held = false;
            locks.delete(key); // idle key — don't leak a map entry per surface seen
        }
    }
}
/** Test seam: drop all lock state between cases. */
function __resetRestLocks() {
    locks.clear();
}
/**
 * Compose the message sent to Claude from an endpoint's prompt template and the
 * request's input. `{input}` is substituted; absent it, the input is appended.
 *
 * Newlines are PRESERVED here. Long prompts are delivered by bracketed paste
 * (see writeAgentMessage / seedAgentBaseline), where embedded newlines are safe
 * — collapsing them would flatten a structured markdown prompt into one line and
 * lose its tables/lists/code fences (and the giant single line truncates in the
 * TUI). The collapse-to-one-line guard is applied only on the paths that type
 * the text raw (Enter would submit early): the typed branch of writeAgentMessage
 * and the CLI-argument launch path.
 */
function composeMessage(prompt, input) {
    let text;
    if (prompt && prompt.includes('{input}')) {
        text = prompt.split('{input}').join(input);
    }
    else if (prompt) {
        text = input ? `${prompt}\n\n${input}` : prompt;
    }
    else {
        text = input;
    }
    return text.trim();
}
/** Collapse newlines to spaces — for paths that TYPE text raw (where a bare
 *  newline would submit early). Paste paths must NOT use this (newlines safe). */
function flattenForTyping(text) {
    return text.replace(/\r?\n/g, ' ').trim();
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** Clamp a caller-supplied timeout to a sane window; fall back to the default. */
function clampTimeout(v) {
    const n = typeof v === 'number' && isFinite(v) ? v : DEFAULT_WAIT_MS;
    return Math.max(5_000, Math.min(600_000, n));
}
/** Default cap on how long a `wait` request holds the HTTP connection open. */
const DEFAULT_WAIT_MS = 180_000;
/** Polling cadence while waiting for the agent to finish a turn. */
const POLL_MS = 350;
/**
 * If we never observe the agent go busy then idle (e.g. a plain shell, or a
 * non-Claude CLI the observer doesn't parse), fall back to "the screen stopped
 * changing for this long" as the done signal — but only after a startup grace so
 * we don't return before the agent has even begun replying.
 */
const QUIET_SETTLE_MS = 1_500;
const START_GRACE_MS = 9_000;
const KEY_DOWN = '\x1b[B';
const KEY_ENTER = '\r';
/** A long message passed straight as keystrokes can be truncated; above this many
 *  UTF-8 bytes we wrap it in a bracketed paste so the agent inserts it as one
 *  atomic block. (Only safe for agent TUIs — used for the bound Claude session.) */
const PASTE_MIN_BYTES = 1500;
/**
 * Send `text` to an agent terminal, wrapping long content in a bracketed paste
 * (ESC[200~ … ESC[201~) so it lands atomically instead of being processed — and
 * possibly dropped — keystroke by keystroke. Returns whether the paste path was
 * used (the caller must then delay/retry the submit — see submitAgentInput).
 */
function writeAgentMessage(write, surfaceId, text) {
    if (Buffer.byteLength(text, 'utf8') > PASTE_MIN_BYTES) {
        // Paste path: newlines are inserted literally (not submitted), so keep the
        // prompt's structure intact.
        write(surfaceId, '\x1b[200~' + text + '\x1b[201~');
        return true;
    }
    // Typed raw: a bare newline would submit early, so flatten to one line.
    write(surfaceId, flattenForTyping(text));
    return false;
}
/** Grace before the first Enter after a bracketed paste — Claude commits a large
 *  paste asynchronously, and an Enter racing that commit is silently dropped (the
 *  "[Pasted text … +N lines]" block just sits unsubmitted in the input box). */
const PASTE_SUBMIT_DELAY_MS = 450;
/**
 * Deliver `text` to an agent and (optionally) submit it, robustly.
 *
 * A short message is typed and Enter is immediate. A long message goes via
 * bracketed paste, after which the Enter is **delayed and then retried**: Claude
 * ingests a big multi-line paste asynchronously, so a single prompt Enter can land
 * before the paste is committed and be dropped, leaving the block stranded in the
 * input. We re-send Enter until the agent visibly reacts — it starts a turn
 * ("esc to interrupt") or pauses on a prompt — or we run out of attempts.
 */
async function submitAgentInput(deps, surfaceId, text, submit) {
    const pasted = text ? writeAgentMessage(deps.write, surfaceId, text) : false;
    if (!submit)
        return;
    if (!pasted) {
        deps.write(surfaceId, '\r');
        return;
    }
    await sleep(PASTE_SUBMIT_DELAY_MS);
    deps.write(surfaceId, '\r');
    // Confirm the Enter took; if the paste is still sitting in the input, nudge it.
    for (let i = 0; i < 3; i++) {
        await sleep(500);
        const screen = await deps.readScreen(surfaceId);
        if (/esc to interrupt/i.test(screen))
            return; // turn started → submitted
        if ((0, agent_detect_1.detectWaitingForInput)(screen))
            return; // hit a prompt → submitted
        deps.write(surfaceId, '\r'); // nothing happened → retry Enter
    }
}
/**
 * Answer a Claude select/permission menu by option number, the way its footer
 * advertises ("Tab/Arrow keys to navigate · Enter to select"): step down from
 * the first (highlighted) option N-1 times, then Enter. This is version-proof —
 * unlike typing the digit, which not every menu accepts as a shortcut.
 */
function selectMenuOption(write, surfaceId, n) {
    for (let i = 1; i < n; i++)
        write(surfaceId, KEY_DOWN);
    write(surfaceId, KEY_ENTER);
}
/**
 * Hold until the agent on `surfaceId` finishes the turn it just started, then
 * return its freshly-printed text (the delta vs `before`).
 *
 * Resolution is one of three states, whichever is reached first:
 *   - done    — the turn completed (observer busy→idle, or screen settled and no
 *               pending prompt). The caller has the full reply.
 *   - waiting — Claude paused for a permission/confirmation prompt; the caller
 *               should POST a follow-up answer to the SAME endpoint/surface.
 *   - neither — timed out; partial text is returned with done=false.
 *
 * The observer's busy→idle transition is preferred (reliable for Claude); a
 * quiet-screen fallback covers shells / agents the observer can't parse, after a
 * START_GRACE_MS warm-up so we don't return before the reply has begun.
 */
async function waitForResponse(deps, surfaceId, before, timeoutMs) {
    const start = Date.now();
    let lastText = before;
    let lastChange = start;
    // The agent's live "… esc to interrupt" line is the ground-truth "working"
    // signal — far more reliable than the observer's defaulted isDone. Seed it
    // from the baseline (a fresh launch hands us a screen already mid-turn).
    let sawWorking = agent_detect_1.WORKING_RE.test(before);
    for (;;) {
        await sleep(POLL_MS);
        const now = Date.now();
        const elapsed = now - start;
        const text = await deps.readScreen(surfaceId);
        if (text && text !== lastText) {
            lastText = text;
            lastChange = now;
        }
        const settledFor = now - lastChange;
        const working = agent_detect_1.WORKING_RE.test(text);
        if (working)
            sawWorking = true;
        const observerDone = deps.getActivity(surfaceId)?.isDone === true;
        const result = (done, waiting) => ({
            done,
            waiting,
            response: extractResponse(before, lastText),
        });
        // A permission/confirmation prompt has rendered and stopped moving → the
        // caller must answer. Checked first: this is NOT a finished turn, and only
        // counts when the agent isn't actively working.
        if (!working && settledFor >= 500 && (0, agent_detect_1.detectWaitingForInput)(text)) {
            return result(false, true);
        }
        // Primary: the agent was working, has now stopped, and the screen settled —
        // the reply is fully painted. (Corroborated faster by the observer's done.)
        if (sawWorking && !working) {
            if (observerDone && settledFor >= 300)
                return result(true, false);
            if (settledFor >= 800)
                return result(true, false);
        }
        // Fallback for surfaces with no working indicator (a plain shell command via
        // /terminals): treat a long-quiet screen as done, past the warm-up window.
        if (!sawWorking && settledFor >= QUIET_SETTLE_MS && elapsed >= START_GRACE_MS) {
            return result(true, false);
        }
        if (elapsed >= timeoutMs) {
            return result(false, false);
        }
    }
}
/**
 * Pull just the agent's reply out of the full screen scrape: the lines added
 * since `before`, with Claude's input-box chrome and status spinner stripped.
 */
// Lines that are agent UI chrome, not reply content: box borders, the input row,
// hints, the working spinner, and the "✻ Baked for 3m 10s" turn-summary (glyph +
// verb + a real time unit, so "● Searched for 5 files" is NOT stripped).
function isChromeLine(line) {
    const t = line.trim();
    if (!t)
        return false; // keep blanks for paragraph spacing (trimmed at the end)
    if (/^[╭╮╰╯│─━┃┌┐└┘]+$/.test(t))
        return true;
    if (/^[│┃]\s*>/.test(t))
        return true;
    if (agent_detect_1.WORKING_RE.test(t))
        return true;
    if (/^[✻✺✽✼✾✿❀✶✵✷✴✳✲✱∗✢◉◍◌◦]\s+\w+ for\s+\d+(?:ms|s|m|h)\b/i.test(t))
        return true;
    if (/^\?\s+for shortcuts/i.test(t))
        return true;
    if (/(accept edits|plan mode|bypass permissions)\s+on/i.test(t))
        return true;
    if (/Tab\/Arrow keys to navigate|Enter to select|esc to cancel/i.test(t))
        return true;
    return false;
}
function extractResponse(before, after) {
    const beforeLines = before.split('\n').map((l) => l.replace(/\s+$/, ''));
    const afterLines = after.split('\n').map((l) => l.replace(/\s+$/, ''));
    // Anchor: the deepest substantive `before` line that still exists in `after`,
    // and take everything past it. Scanning from the end (and skipping blank/chrome
    // lines, which churn and would mis-anchor) makes this robust to the volatile
    // status line at the bottom and to scrollback shifting old lines off the top.
    let cut = -1;
    for (let i = beforeLines.length - 1; i >= 0 && cut < 0; i--) {
        const l = beforeLines[i];
        if (!l.trim() || isChromeLine(l))
            continue;
        const j = afterLines.lastIndexOf(l);
        if (j >= 0)
            cut = j;
    }
    const delta = cut >= 0 ? afterLines.slice(cut + 1) : afterLines;
    return delta
        .filter((l) => !isChromeLine(l))
        .join('\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}
let server = null;
// Remembered so a config change (via Settings IPC) can restart with the same deps.
let lastDeps = null;
let status = {
    enabled: false, listening: false, host: '127.0.0.1', port: 7878, error: null, code: null,
};
function getRestServerStatus() {
    return { ...status };
}
/** Turn a listen error into something a user can act on. (Exported for tests —
 *  this string is the whole user-facing product of a failed bind.) */
function describeListenError(err, host, port) {
    switch (err.code) {
        case 'EADDRINUSE':
            return `port ${port} on ${host} is already in use — another comux (GUI and daemon share one rest-api.json) or a different program holds it. Pick another with: comux rest enable --port <n>`;
        case 'EACCES':
            return `not allowed to bind ${host}:${port} — ports below 1024 need privileges. Pick a higher one with: comux rest enable --port <n>`;
        case 'EADDRNOTAVAIL':
            return `${host} is not an address on this machine — bind 127.0.0.1 (or 0.0.0.0) instead.`;
        default:
            return `${err.code ? err.code + ': ' : ''}${err.message}`;
    }
}
function timingSafeEqualStr(a, b) {
    const ab = Buffer.from(a, 'utf-8');
    const bb = Buffer.from(b, 'utf-8');
    if (ab.length !== bb.length)
        return false;
    return crypto_1.default.timingSafeEqual(ab, bb);
}
function sendJson(res, status, body) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(body));
}
/**
 * Client IP from the real socket peer. We deliberately do NOT honor
 * X-Forwarded-For: it's attacker-controlled and was both poisoning the audit
 * log and letting a flood evade per-IP rate limiting by spoofing the header.
 */
function clientIp(req) {
    const ip = req.socket.remoteAddress || 'unknown';
    return ip.trim().replace(/^::ffff:/, ''); // unwrap IPv4-mapped IPv6
}
// ── Per-IP sliding-window rate limit (applied before auth + logging) ──
// Bounds an unauthenticated flood so it can't drive repeated log writes / work.
const RATE_WINDOW_MS = 10_000;
const RATE_MAX = 100; // requests per window per IP
const rateBuckets = new Map();
function rateLimited(ip) {
    const now = Date.now();
    let b = rateBuckets.get(ip);
    if (!b || now >= b.resetAt) {
        b = { count: 0, resetAt: now + RATE_WINDOW_MS };
        rateBuckets.set(ip, b);
    }
    // Opportunistically drop expired buckets so the map can't grow unbounded.
    if (rateBuckets.size > 256) {
        for (const [k, v] of rateBuckets)
            if (now >= v.resetAt)
                rateBuckets.delete(k);
    }
    b.count++;
    return b.count > RATE_MAX;
}
function bearerToken(req) {
    const auth = req.headers['authorization'];
    if (!auth || Array.isArray(auth))
        return null;
    const m = /^Bearer\s+(.+)$/i.exec(auth.trim());
    return m ? m[1] : null;
}
/**
 * Decode a request body to text. Prefer strict UTF-8; if the bytes aren't valid
 * UTF-8, fall back to legacy Windows code pages (CP949/EUC-KR for Korean, then
 * Windows-1252). Clients such as Git Bash's curl on a Korean Windows box encode
 * the body in the system ANSI code page, not UTF-8 — without this, that Korean
 * arrives garbled long before any PTY write. ASCII is valid UTF-8, so it always
 * takes the fast path and is never touched.
 */
function decodeBody(buf) {
    try {
        return { text: new TextDecoder('utf-8', { fatal: true }).decode(buf), encoding: 'utf-8' };
    }
    catch {
        for (const enc of ['euc-kr', 'windows-1252']) {
            try {
                return { text: new TextDecoder(enc, { fatal: true }).decode(buf), encoding: enc };
            }
            catch {
                /* try the next fallback */
            }
        }
        return { text: buf.toString('utf-8'), encoding: 'utf-8-lossy' };
    }
}
function readJsonBody(req) {
    return new Promise((resolve) => {
        let size = 0;
        let done = false;
        const chunks = [];
        const finish = (r) => {
            if (done)
                return;
            done = true;
            resolve(r);
        };
        req.on('data', (c) => {
            size += c.length;
            if (size > MAX_BODY) {
                finish({ ok: false, error: 'request body too large' });
                req.destroy();
                return;
            }
            chunks.push(c);
        });
        req.on('end', () => {
            const raw = decodeBody(Buffer.concat(chunks)).text.trim();
            if (!raw)
                return finish({ ok: true, data: {} });
            try {
                finish({ ok: true, data: JSON.parse(raw) });
            }
            catch {
                finish({ ok: false, error: 'invalid JSON body' });
            }
        });
        req.on('error', () => finish({ ok: false, error: 'request error' }));
    });
}
/**
 * Merge the renderer's terminal list with agent + Claude-activity info from main.
 * Exported for tests: the /terminals filter is the whole point of this function
 * and starting a real server to check it would touch the user's rest-api.json.
 */
async function listTerminals(deps) {
    let surfaces = [];
    try {
        surfaces = await deps.listSurfaces();
    }
    catch {
        return [];
    }
    if (!Array.isArray(surfaces))
        return [];
    return surfaces
        // The route is /terminals, so only terminals belong here. Filtering centrally
        // (rather than trusting each host's list) is what keeps the GUI and the daemon
        // from drifting: the daemon used to return markdown/browser surfaces too, and
        // every one of them 404'd the moment a caller POSTed to its /input.
        .filter((s) => !s || !s.type || s.type === 'terminal')
        .map((s) => {
        const agent = deps.getAgentBySurface(s.surfaceId);
        const activity = deps.getActivity(s.surfaceId);
        return {
            ...s,
            hasAgent: !!agent,
            agentLabel: agent?.label,
            // `active` = the observer has seen Claude output on this surface; `isDone`
            // distinguishes waiting-for-input (true) from mid-turn (false).
            claude: activity ? { active: true, isDone: activity.isDone } : { active: false, isDone: null },
        };
    });
}
async function handle(req, res, deps) {
    const config = (0, rest_config_1.getRestConfig)();
    const ip = clientIp(req);
    const reqPath = (req.url || '/').split('?')[0];
    const reqMethod = req.method || 'GET';
    // ── Rate limit FIRST, before auth or logging, so a flood (even unauthorized)
    //    can't drive repeated work/log writes on the main thread. ──
    if (rateLimited(ip)) {
        sendJson(res, 429, { ok: false, error: 'too many requests' });
        return;
    }
    // ── Auth: required on every request (constant-time compare) ──
    const token = bearerToken(req);
    if (!token || !config.token || !timingSafeEqualStr(token, config.token)) {
        // Record the rejected access so the logs dialog surfaces probe/attack IPs.
        (0, rest_logs_1.appendRestLog)({ ip, api: '—', method: reqMethod, path: reqPath, input: '', tokens: 0, status: 401 });
        sendJson(res, 401, { ok: false, error: 'unauthorized' });
        return;
    }
    const url = new URL(req.url || '/', 'http://localhost');
    const pathName = url.pathname.replace(/\/+$/, '') || '/';
    const method = req.method || 'GET';
    // GET /health  (and /)
    if (method === 'GET' && (pathName === '/health' || pathName === '/')) {
        sendJson(res, 200, { ok: true, name: 'comux', version: deps.version });
        return;
    }
    // POST /echo  — encoding diagnostic. Returns the raw request-body bytes (hex)
    // exactly as received, plus how they decode as UTF-8 and the parsed text. Lets
    // a client confirm whether it is actually sending UTF-8 (correct Korean/CJK) or
    // some other charset (which would arrive already-garbled, before any PTY write).
    if (method === 'POST' && pathName === '/echo') {
        const rawChunks = [];
        let rsize = 0;
        let aborted = false;
        req.on('data', (c) => {
            rsize += c.length;
            if (rsize > MAX_BODY) {
                aborted = true;
                req.destroy();
                return;
            }
            rawChunks.push(c);
        });
        req.on('end', () => {
            if (aborted) {
                sendJson(res, 413, { ok: false, error: 'request body too large' });
                return;
            }
            const raw = Buffer.concat(rawChunks);
            const decoded = decodeBody(raw);
            let parsedText;
            try {
                parsedText = JSON.parse(decoded.text)?.text;
            }
            catch {
                parsedText = undefined;
            }
            const text = typeof parsedText === 'string' ? parsedText : '';
            sendJson(res, 200, {
                ok: true,
                byteLength: raw.length,
                detectedEncoding: decoded.encoding, // 'utf-8' if the client sent UTF-8; 'euc-kr' if recovered
                bodyHex: raw.toString('hex'),
                bodyDecoded: decoded.text,
                text,
                textHex: Buffer.from(text, 'utf-8').toString('hex'),
                sampleKoreanHex: Buffer.from('한글테스트', 'utf-8').toString('hex'),
            });
        });
        return;
    }
    // GET /terminals
    if (method === 'GET' && pathName === '/terminals') {
        sendJson(res, 200, { ok: true, terminals: await listTerminals(deps) });
        return;
    }
    // POST /terminals/:surfaceId/input   (surfaceId "active" or empty → active terminal)
    const inputMatch = /^\/terminals\/([^/]+)\/input$/.exec(pathName);
    if (inputMatch) {
        if (method !== 'POST') {
            sendJson(res, 405, { ok: false, error: 'method not allowed (use POST)' });
            return;
        }
        const body = await readJsonBody(req);
        if (!body.ok) {
            sendJson(res, 400, { ok: false, error: body.error });
            return;
        }
        const text = typeof body.data.text === 'string' ? body.data.text : null;
        if (text === null) {
            sendJson(res, 400, { ok: false, error: 'body.text (string) is required' });
            return;
        }
        const submit = body.data.submit !== false; // default: press Enter to submit
        // Opt-in: hold the request open and return the agent's reply (only meaningful
        // when we also submit — without Enter nothing runs).
        const wait = body.data.wait === true && submit;
        const timeoutMs = clampTimeout(body.data.timeoutMs);
        const raw = decodeURIComponent(inputMatch[1]);
        const target = raw === 'active' || raw === '' ? undefined : raw;
        const resolved = await deps.resolvePtySurface(target);
        if (!resolved.ok) {
            (0, rest_logs_1.appendRestLog)({ ip, api: 'terminals', method, path: pathName, input: text, tokens: (0, rest_logs_1.estimateTokens)(text), status: 404 });
            sendJson(res, 404, { ok: false, error: resolved.error });
            return;
        }
        // One writer per terminal: without this, two concurrent posts interleave
        // their keystrokes inside the agent's input box.
        await withLock(`surface:${resolved.id}`, async () => {
            const before = wait ? await deps.readScreen(resolved.id) : '';
            deps.write(resolved.id, text);
            if (submit)
                deps.write(resolved.id, '\r');
            (0, rest_logs_1.appendRestLog)({ ip, api: 'terminals', method, path: pathName, input: text, tokens: (0, rest_logs_1.estimateTokens)(text), status: 200, surfaceId: resolved.id });
            if (wait) {
                const { done, waiting, response } = await waitForResponse(deps, resolved.id, before, timeoutMs);
                sendJson(res, 200, { ok: true, surfaceId: resolved.id, submitted: submit, done, waiting, response });
            }
            else {
                sendJson(res, 200, { ok: true, surfaceId: resolved.id, submitted: submit });
            }
        });
        return;
    }
    // GET /api  — list configured dynamic endpoints (names + mode, no prompt body)
    if (method === 'GET' && pathName === '/api') {
        sendJson(res, 200, {
            ok: true,
            endpoints: config.endpoints.map((e) => ({ name: e.name, agent: e.agent, mode: e.mode, cwd: e.cwd })),
        });
        return;
    }
    // POST /api/:name  — dynamic endpoint: compose prompt + input, send to Claude,
    // auto-launching a Claude session (in the endpoint's cwd/mode) if none runs.
    const apiMatch = /^\/api\/([^/]+)$/.exec(pathName);
    if (apiMatch) {
        if (method !== 'POST') {
            sendJson(res, 405, { ok: false, error: 'method not allowed (use POST)' });
            return;
        }
        const name = decodeURIComponent(apiMatch[1]).toLowerCase();
        const endpoint = config.endpoints.find((e) => e.name.toLowerCase() === name);
        if (!endpoint) {
            sendJson(res, 404, { ok: false, error: `no endpoint named "${apiMatch[1]}"` });
            return;
        }
        const body = await readJsonBody(req);
        if (!body.ok) {
            sendJson(res, 400, { ok: false, error: body.error });
            return;
        }
        const input = typeof body.data.text === 'string' ? body.data.text : '';
        const rawInput = input.replace(/\r?\n/g, ' ').trim();
        const templatedMessage = composeMessage(endpoint.prompt, input);
        // `raw`: send `input` verbatim, skipping the endpoint's prompt template.
        // Normally this is inferred — when the bound session is mid-turn waiting for
        // an answer (a permission/selection prompt), the input IS the answer and must
        // NOT be re-wrapped — but a caller can also force it explicitly.
        const forceRaw = body.data.raw === true;
        // Whether to press Enter after the text. Default true; pass {"submit":false}
        // to send a bare keystroke (some menus select on the digit alone).
        const submit = body.data.submit !== false;
        // Capture the agent's reply and return it by default; `{ "wait": false }`
        // restores the old fire-and-forget behaviour.
        const wait = body.data.wait !== false;
        const timeoutMs = clampTimeout(body.data.timeoutMs);
        const logApi = (status, message, surfaceId) => (0, rest_logs_1.appendRestLog)({ ip, api: endpoint.name, method, path: pathName, input, tokens: (0, rest_logs_1.estimateTokens)(message), status, surfaceId });
        // Everything from "is there a session?" to "remember the one I launched" is
        // one critical section per endpoint. Without it two concurrent first requests
        // both read an empty binding and each launch their own agent — the loser is an
        // orphan nobody ever answers.
        await withLock(`endpoint:${endpoint.id}`, async () => {
            // Reuse the endpoint's existing Claude terminal if it's still alive.
            const bound = endpointBindings.get(endpoint.id);
            if (bound && deps.ptyHas(bound)) {
                // Also hold the surface lock, so a concurrent /terminals write to this same
                // terminal queues behind the turn instead of landing inside its prompt.
                await withLock(`surface:${bound}`, async () => {
                    // Peek at the session: if it's paused on a prompt, this input is the answer
                    // (don't re-wrap it in the template); otherwise it's a new request. This is
                    // what lets a remote caller drive a multi-step prompt → answer flow.
                    const before = await deps.readScreen(bound);
                    const menuWaiting = (0, agent_detect_1.detectWaitingForInput)(before);
                    const answering = forceRaw || menuWaiting;
                    // A bare number while a menu is up = pick that option via arrow-navigation
                    // (the menu's advertised selection method). Free text is typed as-is.
                    const menuPick = menuWaiting && !forceRaw && /^\d+$/.test(rawInput) ? parseInt(rawInput, 10) : 0;
                    const message = answering ? rawInput : templatedMessage;
                    if (menuPick > 0) {
                        selectMenuOption(deps.write, bound, menuPick);
                        logApi(200, `«option ${menuPick}»`, bound);
                    }
                    else {
                        if (!message && !submit) {
                            logApi(400, '');
                            sendJson(res, 400, { ok: false, error: 'empty message (no prompt and no body.text)' });
                            return;
                        }
                        await submitAgentInput(deps, bound, message, submit);
                        logApi(200, message, bound);
                    }
                    if (wait) {
                        const { done, waiting, response } = await waitForResponse(deps, bound, before, timeoutMs);
                        sendJson(res, 200, { ok: true, endpoint: endpoint.name, surfaceId: bound, launched: false, answered: answering, done, waiting, response });
                    }
                    else {
                        sendJson(res, 200, { ok: true, endpoint: endpoint.name, surfaceId: bound, launched: false, answered: answering });
                    }
                });
                return;
            }
            // No live session → launch a fresh one seeded with the composed message.
            const message = forceRaw ? rawInput : templatedMessage;
            if (!message) {
                logApi(400, '');
                sendJson(res, 400, { ok: false, error: 'empty message (no prompt and no body.text)' });
                return;
            }
            const launched = await deps.launchAgent({
                agent: endpoint.agent,
                cwd: endpoint.cwd,
                mode: endpoint.mode,
                prompt: message,
                label: `api:${endpoint.name}`,
            });
            if (!launched.ok) {
                logApi(500, message);
                sendJson(res, 500, { ok: false, error: launched.error });
                return;
            }
            endpointBindings.set(endpoint.id, launched.surfaceId);
            logApi(200, message, launched.surfaceId);
            if (wait) {
                // launchAgent resolves once the prompt is in and the agent is working, and
                // hands back a baseline snapshot — diffing against it keeps the startup
                // banner out of the reply.
                const { done, waiting, response } = await withLock(`surface:${launched.surfaceId}`, () => waitForResponse(deps, launched.surfaceId, launched.baseline, timeoutMs));
                sendJson(res, 200, {
                    ok: true,
                    endpoint: endpoint.name,
                    surfaceId: launched.surfaceId,
                    launched: true,
                    agent: endpoint.agent,
                    mode: endpoint.mode,
                    done,
                    waiting,
                    response,
                });
            }
            else {
                sendJson(res, 200, {
                    ok: true,
                    endpoint: endpoint.name,
                    surfaceId: launched.surfaceId,
                    launched: true,
                    agent: endpoint.agent,
                    mode: endpoint.mode,
                });
            }
        });
        return;
    }
    sendJson(res, 404, { ok: false, error: 'not found' });
}
/**
 * Start (or restart) the REST server using the current persisted config.
 *
 * Resolves once the outcome is known — bound, or failed to bind — so callers
 * (`rest.reload` over the pipe, the Settings IPC) can report the real result
 * instead of optimistically echoing the config back.
 */
function startRestServer(deps) {
    lastDeps = deps;
    stopRestServer();
    const config = (0, rest_config_1.getRestConfig)();
    status = {
        enabled: config.enabled,
        listening: false,
        host: config.host,
        port: config.port,
        error: null,
        code: null,
    };
    if (!config.enabled)
        return Promise.resolve(getRestServerStatus());
    if (!config.token) {
        status.error = 'no auth token in rest-api.json — the server refuses to run without one. Mint one with: comux rest token --rotate';
        return Promise.resolve(getRestServerStatus());
    }
    const srv = http_1.default.createServer((req, res) => {
        handle(req, res, deps).catch((err) => {
            try {
                // A busy terminal is a client-visible condition (409/429), not a crash.
                if (err instanceof RestBusyError)
                    sendJson(res, err.status, { ok: false, error: err.message });
                else
                    sendJson(res, 500, { ok: false, error: err?.message || 'internal error' });
            }
            catch {
                /* response already sent */
            }
        });
    });
    return new Promise((resolve) => {
        let settled = false;
        const done = () => { if (!settled) {
            settled = true;
            resolve(getRestServerStatus());
        } };
        srv.on('error', (err) => {
            if (server === srv)
                server = null;
            status.listening = false;
            status.code = err.code || null;
            status.error = describeListenError(err, config.host, config.port);
            console.error(`[comux] REST API cannot listen on ${config.host}:${config.port} — ${status.error}`);
            done();
        });
        srv.listen(config.port, config.host, () => {
            status.listening = true;
            status.error = null;
            status.code = null;
            console.log(`[comux] REST API listening on http://${config.host}:${config.port}`);
            done();
        });
        server = srv;
    });
}
/** Stop the server if running. */
function stopRestServer() {
    if (server) {
        server.close();
        server = null;
    }
    status = { ...status, listening: false };
}
/** Restart using the deps captured at the last start (after a config change). */
function reloadRestServer() {
    if (lastDeps)
        return startRestServer(lastDeps);
    return Promise.resolve(getRestServerStatus());
}

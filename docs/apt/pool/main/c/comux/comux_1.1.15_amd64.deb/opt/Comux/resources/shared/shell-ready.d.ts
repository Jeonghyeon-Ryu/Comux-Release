/**
 * Type a command into a freshly spawned shell once it is at a prompt.
 *
 * Writing straight after spawn loses the text: PowerShell with comux's
 * integration takes 1–3s to reach its first prompt and discards input typed
 * while its profile loads. agent-manager learned this first (a blind 800ms
 * timeout dropped agent commands); this is the same rule, shared so a
 * worktree's setup commands and an agent's launch line behave alike on both
 * hosts.
 */
/** A shell prompt at the end of a chunk: `PS C:\x>`, `$ `, `# `, `% `, `> `. */
export declare const SHELL_PROMPT_RE: RegExp;
export interface TypeWhenReadyOptions {
    /** Subscribe to the shell's output; returns an unsubscribe. */
    subscribe: (cb: (data: string) => void) => () => void;
    write: (text: string) => void;
    text: string;
    /** Output that never matches a prompt: send after this much of it. */
    settleMs?: number;
    /** Absolute fallback when the shell prints nothing recognisable. */
    timeoutMs?: number;
}
/** Returns a cancel function. The text is written at most once. */
export declare function typeWhenShellReady(o: TypeWhenReadyOptions): () => void;

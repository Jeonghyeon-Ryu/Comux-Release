/**
 * The four buckets a token can land in, and the arithmetic over them.
 *
 * A single scalar cannot represent LLM token usage honestly, for two reasons
 * measured on this project's own logs:
 *
 * 1. **Scale.** Cache reads outweigh fresh input by ~45x in real agentic
 *    sessions (2.4B vs 2.4M on a month of transcripts). Folding them together
 *    hides everything; dropping them — which is what comux did — under-reports
 *    total volume by ~55x.
 * 2. **Definition drift between tools.** Anthropic's `input_tokens` EXCLUDES
 *    cached input, so its total is the sum of all four fields. Codex's
 *    `input_tokens` INCLUDES `cached_input_tokens`, so adding the cache figure
 *    on top double-counts it. Normalizing to these buckets at the reader is
 *    what makes per-tool numbers comparable — and summable — at all.
 *
 * Every reader converts into this shape before anything aggregates.
 */
export interface TokenBuckets {
    /** Input processed from scratch — not served from the prompt cache. */
    fresh: number;
    /** Input served from the prompt cache. Re-read context: still processed. */
    cachedRead: number;
    /** Input written INTO the prompt cache. */
    cacheWrite: number;
    /** Generated output. */
    output: number;
}
export declare const EMPTY_BUCKETS: TokenBuckets;
export declare function emptyBuckets(): TokenBuckets;
/** Add `src` into `dst` in place. */
export declare function addBuckets(dst: TokenBuckets, src: TokenBuckets): void;
/**
 * Every token the model actually processed for this work.
 *
 * Includes `cachedRead`: a cache hit is cheaper, not absent — the tokens are
 * still part of the prompt the model read. This is the number to show when the
 * question is "how much did I use", as distinct from a cost estimate, where the
 * four buckets carry different per-token rates and must stay separate.
 */
export declare function bucketsTotal(b: TokenBuckets): number;
/** Input-side only (everything that was in the prompt, cached or not). */
export declare function bucketsInput(b: TokenBuckets): number;

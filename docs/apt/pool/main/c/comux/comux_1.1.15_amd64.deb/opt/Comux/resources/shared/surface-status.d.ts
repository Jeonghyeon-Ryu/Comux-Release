/**
 * Surface Status — the single source of truth for per-surface agent state.
 *
 * Every producer (PTY observer patterns, Claude Code hooks, shell-integration
 * reports, external plugins) feeds edge-triggered signals into this machine;
 * every consumer (workspace tab dots, fleet dashboard, attention router, REST
 * API) reads the same per-surface record. This replaces the old "was there an
 * event in the last 5 seconds?" TTL heuristics, which starved during long tool
 * calls / thinking stretches and misreported working agents as idle.
 *
 * Claude-tier status ('working' | 'waiting' | 'done' | 'unknown') only changes
 * on explicit signals or the watchdog — it never decays client-side. Shell
 * state is tracked PER SURFACE (a sibling pane's prompt can no longer stomp
 * the Claude pane's state) and is used by consumers as the fallback tier when
 * no Claude state is live.
 */
import { SurfaceId, AgentActivity, ShellReportState, SurfaceActivitySnapshot } from './types';
export type { AgentActivity } from './types';
export type ActivitySink = (surfaceId: SurfaceId, activity: SurfaceActivitySnapshot | null) => void;
export declare function setActivitySink(sink: ActivitySink | null): void;
export type SurfaceSignal = {
    type: 'working';
    tool?: string | null;
    skill?: string;
    agents?: AgentActivity[];
} | {
    type: 'waiting';
    via?: 'pattern';
} | {
    type: 'done';
    via?: 'pattern';
    tool?: string | null;
    skill?: string;
    agents?: AgentActivity[];
} | {
    type: 'detail';
    tool?: string | null;
    skill?: string;
    agents?: AgentActivity[];
} | {
    type: 'idle';
} | {
    type: 'shell';
    state: ShellReportState;
};
export type AttentionKind = 'waiting' | 'done';
export interface AttentionEvent {
    surfaceId: SurfaceId;
    kind: AttentionKind;
    lastTool: string | null;
    at: number;
}
type AttentionListener = (ev: AttentionEvent) => void;
/** Register a listener for agent attention transitions. Returns an unsubscribe. */
export declare function onAttention(cb: AttentionListener): () => void;
/**
 * Feed one signal into the machine. Broadcasts (and emits attention) only on
 * genuine transitions or detail changes — steady-state working evidence just
 * refreshes the internal timestamps.
 */
export declare function signal(surfaceId: SurfaceId, sig: SurfaceSignal, at?: number): void;
/**
 * Data-driven keepalive: called for every PTY chunk. While a surface is
 * 'working', any output refreshes the working signal (ConPTY diff-repaints
 * don't always re-emit a matchable pattern), bounded by KEEPALIVE_WINDOW_MS
 * since the last real pattern match. Cheap and broadcast-free.
 */
export declare function touch(surfaceId: SurfaceId, at?: number): void;
/** Note a PTY resize — pattern-parsed done/waiting edges are ignored briefly (replay guard). */
export declare function noteResize(surfaceId: SurfaceId, at?: number): void;
/** Drop a surface's record entirely (PTY exited) and tell the renderer. */
export declare function clearSurface(surfaceId: SurfaceId): void;
/** Full snapshot for renderer reload seeding. */
export declare function getAllSnapshots(): Record<string, SurfaceActivitySnapshot>;
/**
 * Legacy accessor for the REST server. Defined only while Claude is actually
 * in evidence on the surface: plain shells stay undefined, and a surface whose
 * Claude session ended (shell demoted it to 'unknown' with the prompt back)
 * also reads undefined rather than a forever-"active but not done" ghost.
 */
export declare function getActivity(surfaceId: SurfaceId): {
    isDone: boolean;
    lastUpdate: number;
} | undefined;
/**
 * Merge externally-sourced activity (e.g. the OpenCode plugin pushing over the
 * pipe) into the machine. Field semantics match the old observer API: only an
 * explicit isDone/waitingForInput value moves the status; detail-only pushes
 * (tool/skill/agents) never do.
 */
export declare function applyExternalActivity(surfaceId: SurfaceId, partial: {
    lastTool?: string | null;
    activeSkill?: string | null;
    isDone?: boolean;
    waitingForInput?: boolean;
    agents?: AgentActivity[];
}, at?: number): void;
/**
 * Route a Claude Code hook event (from the named pipe) into the machine.
 * Events without a surfaceId cannot be attributed and are ignored here —
 * misattributing them to whatever is focused is exactly the bug this replaces.
 */
export declare function onHookEvent(params: {
    surfaceId?: string;
    event?: string;
    tool?: string;
}, at?: number): void;
/** Demote stale 'working' records; called on an interval (and from tests). */
export declare function runWatchdog(at?: number): void;
/** Start the periodic watchdog. Idempotent; call once from main startup. */
export declare function startWatchdog(): void;
/** Test-only: reset all machine state. */
export declare function _resetForTests(): void;

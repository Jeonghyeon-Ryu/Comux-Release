// orch-core.js — the pure scheduling rules behind orch.js (no I/O, unit-tested).
//
// The plan is still written as WAVES (that is how the orchestrator reasons and
// how the comux sidebar draws it), but waves are now only a picture: each agent
// starts the moment the agents it depends on are done, not when its whole wave
// is. An agent with no `dependsOn` depends on every agent in earlier waves, so
// a plan written for the old barrier scheduler runs exactly as before.
'use strict';

const DONE = new Set(['exited', 'completed', 'complete']);

function allAgents(state) {
  const out = [];
  for (const wave of state.waves || []) for (const a of wave.agents || []) out.push(a);
  return out;
}

function findAgent(state, id) {
  for (let w = 0; w < (state.waves || []).length; w++) {
    const agents = state.waves[w].agents || [];
    for (let i = 0; i < agents.length; i++) if (agents[i].id === id) return { agent: agents[i], waveIndex: w, index: i };
  }
  return null;
}

/** Finished successfully (the sidebar's vocabulary is `exited`; older scripts wrote `completed`). */
function isDone(a) {
  return DONE.has(a.status) && (a.exitCode == null || a.exitCode === 0);
}
function isFailed(a) {
  return a.status === 'failed' || (DONE.has(a.status) && a.exitCode != null && a.exitCode !== 0);
}

/**
 * Fill in `dependsOn` from the waves and check the graph: unknown ids and
 * cycles are plan bugs, and a cycle would otherwise just hang the run.
 */
function normalizePlan(state) {
  const seen = new Set();
  const earlier = [];
  for (const wave of state.waves || []) {
    const ids = [];
    for (const a of wave.agents || []) {
      if (!a.id) throw new Error('every agent needs an id');
      if (seen.has(a.id)) throw new Error(`duplicate agent id "${a.id}"`);
      seen.add(a.id);
      if (!Array.isArray(a.dependsOn)) a.dependsOn = earlier.slice();
      ids.push(a.id);
    }
    earlier.push(...ids);
  }
  for (const a of allAgents(state)) {
    for (const d of a.dependsOn) {
      if (!seen.has(d)) throw new Error(`agent "${a.id}" depends on unknown agent "${d}"`);
      if (d === a.id) throw new Error(`agent "${a.id}" depends on itself`);
    }
  }
  const cycle = findCycle(state);
  if (cycle) throw new Error(`dependency cycle: ${cycle.join(' → ')}`);
  return state;
}

function findCycle(state) {
  const deps = new Map(allAgents(state).map((a) => [a.id, a.dependsOn || []]));
  const mark = new Map(); // 1 = on stack, 2 = done
  const stack = [];
  const visit = (id) => {
    if (mark.get(id) === 2) return null;
    if (mark.get(id) === 1) return stack.slice(stack.indexOf(id)).concat(id);
    mark.set(id, 1);
    stack.push(id);
    for (const d of deps.get(id) || []) {
      const c = visit(d);
      if (c) return c;
    }
    stack.pop();
    mark.set(id, 2);
    return null;
  };
  for (const id of deps.keys()) {
    const c = visit(id);
    if (c) return c;
  }
  return null;
}

/** A dependency that is finished AND (with worktrees) merged into the main checkout. */
function depSatisfied(state, dep) {
  if (!isDone(dep)) return false;
  if (state.useWorktrees) return dep.mergeStatus === 'merged' || dep.mergeStatus === 'empty';
  return true;
}

/** Why a pending agent cannot ever start: a dependency failed or its merge conflicted. */
function blockedReason(state, agent) {
  for (const id of agent.dependsOn || []) {
    const f = findAgent(state, id);
    if (!f) continue;
    if (isFailed(f.agent)) return `${id} failed`;
    if (state.useWorktrees && isDone(f.agent) && f.agent.mergeStatus === 'conflict') return `${id}'s merge has conflicts`;
  }
  return null;
}

/** Pending agents that may start now, oldest wave first, within maxParallel. */
function readyAgents(state) {
  const all = allAgents(state);
  const running = all.filter((a) => a.status === 'running').length;
  const room = Math.max(0, (state.maxParallel || 5) - running);
  const ready = [];
  for (const a of all) {
    if (a.status !== 'pending' || ready.length >= room) continue;
    const deps = (a.dependsOn || []).map((id) => findAgent(state, id)).filter(Boolean).map((f) => f.agent);
    if (deps.every((d) => depSatisfied(state, d))) ready.push(a);
  }
  return ready;
}

/** Recompute each wave's status from its agents (display only). */
function refreshWaves(state) {
  for (const wave of state.waves || []) {
    const agents = wave.agents || [];
    if (agents.length && agents.every((a) => isDone(a) || isFailed(a))) wave.status = agents.some(isFailed) ? 'failed' : 'complete';
    else if (agents.some((a) => a.status !== 'pending')) wave.status = 'running';
    else wave.status = 'pending';
  }
}

/**
 * Nothing left that can move: everything finished, or what remains is
 * pending behind a failure/conflict with nothing running.
 */
function settled(state) {
  const all = allAgents(state);
  if (all.some((a) => a.status === 'running')) return false;
  return all.every((a) => a.status !== 'pending' || blockedReason(state, a));
}

/** Longest chain of dependencies, for the dashboard: the run cannot be shorter. */
function criticalPath(state) {
  const memo = new Map();
  const len = (id) => {
    if (memo.has(id)) return memo.get(id);
    const f = findAgent(state, id);
    const deps = f ? f.agent.dependsOn || [] : [];
    let best = [];
    for (const d of deps) { const p = len(d); if (p.length > best.length) best = p; }
    const path = best.concat(id);
    memo.set(id, path);
    return path;
  };
  let best = [];
  for (const a of allAgents(state)) { const p = len(a.id); if (p.length > best.length) best = p; }
  return best;
}

/** Most agents at one dependency depth — how many panes the run can use at once. */
function maxWidth(state) {
  const depth = new Map();
  const d = (id) => {
    if (depth.has(id)) return depth.get(id);
    const f = findAgent(state, id);
    const v = f && f.agent.dependsOn && f.agent.dependsOn.length ? 1 + Math.max(...f.agent.dependsOn.map(d)) : 0;
    depth.set(id, v);
    return v;
  };
  const counts = new Map();
  for (const a of allAgents(state)) { const k = d(a.id); counts.set(k, (counts.get(k) || 0) + 1); }
  return Math.max(0, ...counts.values());
}

/**
 * Which CLI runs an agent. An explicit `cli` wins; else its `category`
 * ('quick' | 'deep' | 'visual' | 'review' | …) through the config's ordered
 * list, skipping CLIs that are not installed; else claude.
 */
function chooseCli(agent, config, isInstalled) {
  const ok = (c) => typeof c === 'string' && c && isInstalled(c);
  if (agent.cli) {
    if (ok(agent.cli)) return { cli: agent.cli, why: 'set in plan' };
    return { cli: 'claude', why: `${agent.cli} is not installed — fell back to claude` };
  }
  const list = agent.category && config && config.categories && config.categories[agent.category];
  if (Array.isArray(list)) {
    for (const c of list) if (ok(c)) return { cli: c, why: `category ${agent.category}` };
    return { cli: 'claude', why: `no CLI for category ${agent.category} is installed — fell back to claude` };
  }
  return { cli: 'claude', why: 'default' };
}

/**
 * The evidence gate: a worker may only finish once its result file exists,
 * was written during its run, and is the report the mission asked for — not
 * an empty file or a one-line "done".
 */
function checkResult(text, mtimeMs, startedAtMs) {
  if (text == null) return { ok: false, reason: 'the result file does not exist' };
  if (startedAtMs && mtimeMs && mtimeMs + 2000 < startedAtMs) return { ok: false, reason: 'the result file is older than this run' };
  const body = String(text).trim();
  if (body.length < 120) return { ok: false, reason: 'the result file is too short to be the report' };
  if (!/^#{1,4}\s*summary\b/im.test(body)) return { ok: false, reason: 'the result file has no "### Summary" section' };
  return { ok: true };
}

module.exports = {
  allAgents, findAgent, isDone, isFailed, normalizePlan, findCycle, readyAgents, blockedReason,
  refreshWaves, settled, criticalPath, maxWidth, chooseCli, checkResult, depSatisfied,
};

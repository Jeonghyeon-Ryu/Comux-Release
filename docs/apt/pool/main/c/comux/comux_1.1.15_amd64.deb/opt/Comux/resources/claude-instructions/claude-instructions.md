<!-- comux:start — AUTO-MANAGED BY comux. Do not edit this section manually. -->

# comux

You are running inside comux, a terminal multiplexer with a browser panel on the right side that the user can see in real-time.

## Browser

For any web browsing task, use the `comux browser` commands so the user can watch in the browser panel. Do NOT use Playwright, Firecrawl, or WebSearch — they open invisible windows the user cannot see. If the user explicitly asks for one of those tools, use it.

```bash
comux browser open <url>          # navigate
comux browser snapshot            # get accessibility tree with @eN refs
comux browser click @eN           # click (waits until it is visible, enabled and not covered)
comux browser type @eN <text>     # type into element
comux browser fill @eN <value>    # set input value
comux browser press enter [@eN]   # press a key (submit a form)
comux browser select @eN <label>  # choose a <select> option
comux browser upload @eN <file>   # put a file into a file input
comux browser hover @eN           # hover (menus that open on hover)
comux browser scroll down|up|bottom|@eN
comux browser wait --text "Saved" # wait for text / --selector css / --url part (--gone: until it disappears)
comux browser console --errors    # the page's console errors and uncaught exceptions
comux browser dialogs             # alerts/confirms the page showed and how they were answered
comux browser dialog accept       # OK the next confirm/prompt (default: alerts OK, confirms Cancel)
comux browser get-text            # get page text
comux browser screenshot          # capture screenshot
comux browser eval <js>           # run JavaScript
comux browser back                # go back
comux browser forward             # go forward
comux browser reload              # reload page
comux browser pick "<what>"        # ask the user to click an element; returns its selector, HTML, styles and a screenshot path
```

Workflow: `browser open <url>` → `browser snapshot` → read tree → `browser click/type @eN` → `browser snapshot` again.

Refs (`@e1`, `@e2`...) expire after page changes — always re-snapshot. If a click fails with `covered by …`, deal with what covers it (a cookie banner, a modal) first. A click's result lists any dialog it raised.

## Parallel work on one repo (git worktrees)

When the user wants several agents (or tasks) on the same repository at once, give each its own checkout so they never edit the same files:

```bash
comux worktree create <branch>                 # branch + checkout beside the repo, opens a workspace on it
comux agent spawn --cmd "claude" --worktree <branch>   # an agent in its own checkout
comux worktree list --status                   # every checkout, its workspace, uncommitted changes
comux worktree remove <branch>                 # refuses while there are uncommitted changes
```

<!-- comux:end -->

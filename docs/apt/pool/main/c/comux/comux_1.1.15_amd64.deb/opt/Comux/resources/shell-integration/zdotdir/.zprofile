# comux zsh shim — login shells only. Pass the user's file through untouched.
if [ -f "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zprofile" ]; then
    source "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zprofile"
fi

"use strict";
/**
 * What a <webview> is allowed to ask for.
 *
 * `webviewTag` is on, so any script running in the host renderer — the whole
 * point of the markdown pane's sanitizer, and of a CSP if one is ever added —
 * can append a `<webview>` and choose its privileges through attributes. Those
 * attributes are attacker-controlled input; this is where they get overruled.
 *
 * Lifted out of the `will-attach-webview` handler in src/main/index.ts so it can
 * be tested without starting Electron, the same reason translateKeyName and
 * resolveSurfaceForWrite were lifted. The handler is one line of glue now.
 *
 * Nothing here can change how the REAL browser panel behaves: BrowserPane sets
 * only `src`, `partition` and style, so every preference forced below is one it
 * never asked for.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.hardenWebviewAttach = hardenWebviewAttach;
/** Schemes a guest may be BORN with. Anything else starts at about:blank. */
const SAFE_SRC = /^(https?:|about:)/i;
function hardenWebviewAttach(webPreferences, params) {
    // ── Node in the guest's main world ──
    delete webPreferences.preload;
    webPreferences.nodeIntegration = false;
    webPreferences.contextIsolation = true;
    delete params.allowpopups;
    // ── The ways around that ──
    // A nested <webview> restarts the attack inside a frame this handler has
    // already run for; subframe Node reaches the same APIs one level down;
    // webSecurity=no drops the same-origin policy that makes the panel a boundary
    // at all; Blink feature flags are an arbitrary switch surface.
    webPreferences.webviewTag = false;
    webPreferences.nodeIntegrationInSubFrames = false;
    webPreferences.webSecurity = true;
    webPreferences.experimentalFeatures = false;
    delete webPreferences.enableBlinkFeatures;
    // With the preload deleted there is nothing left in the guest that needs Node,
    // so sandboxing it is free here — unlike the host window, whose preload does
    // require() and would break.
    webPreferences.sandbox = true;
    // `will-navigate` only fires for NAVIGATIONS, so it never sees the src a tag
    // is born with: <webview src="file:///…"> would load a local file and a
    // javascript: URL would run in the host's own origin, both before any
    // navigation event exists to block.
    const src = typeof params.src === 'string' ? params.src : '';
    if (src && !SAFE_SRC.test(src))
        params.src = 'about:blank';
}

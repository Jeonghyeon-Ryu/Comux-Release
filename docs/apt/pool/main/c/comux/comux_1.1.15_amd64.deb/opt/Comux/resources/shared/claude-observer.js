"use strict";
/**
 * Claude Code terminal output observer.
 * Parses PTY data streams for Claude Code patterns (agents, skills, tools,
 * spinner/turn-summary lines) and feeds edge-triggered signals into the
 * surface-status state machine — the single source of truth every consumer
 * (tab dots, fleet dashboard, attention router, REST API) reads.
 *
 * This module is a pure parser: it owns no status state of its own (only the
 * per-surface tail buffer for waiting detection and the parsed agents list).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.observePtyData = observePtyData;
exports.clearActivity = clearActivity;
const agent_detect_1 = require("./agent-detect");
const surface_status_1 = require("./surface-status");
// Strip ANSI escape codes from terminal output. The ESC (\x1b) and BEL (\x07)
// control chars are required to match terminal escape sequences.
function stripAnsi(str) {
    // eslint-disable-next-line no-control-regex
    return str.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '').replace(/\x1b\][^\x07]*\x07/g, '');
}
// Parsed agent lines per surface — presentation detail owned by the parser;
// the machine stores whatever array it is last handed.
const agentLists = new Map();
// A short rolling window of recent (ANSI-stripped) output per surface. The
// waiting-for-input prompt lives at the bottom of the screen; keeping the last
// few KB of stream lets detectWaitingForInput inspect that tail without needing
// the rendered screen (which the observer, being push-based, doesn't have).
const tails = new Map();
const TAIL_MAX = 4000;
/**
 * The trailing, not-yet-terminated fragment of each surface's stream.
 *
 * PTY data arrives in arbitrary chunks, so a status line is regularly split
 * across two of them ("✳ Photosynthesizing… (2m " / "16s)"). Parsing each chunk
 * in isolation dropped every line that landed on a boundary — and since all of
 * these patterns are `^`-anchored, the second half could not match on its own
 * either. The fragment is carried into the next chunk instead.
 */
const partials = new Map();
const PARTIAL_MAX = 2000;
/**
 * Split a stream chunk into lines, treating a bare CR as a line break.
 *
 * Agent TUIs repaint their live status line with `\r` and no newline, so
 * splitting on '\n' alone glued the repaint onto whatever preceded it — and the
 * `^`-anchored spinner/working patterns then failed to match the line they were
 * written for.
 */
function splitLines(text) {
    return text.split(/\r\n|\r|\n/);
}
// Glyphs accepted at the start of Claude Code's live-spinner / turn-summary
// lines. Deliberately EXCLUDES the ordinary characters from the full spinner
// family ('*', '·', '∗') so plain output like "* installed deps (3s)" or a
// markdown bullet "* waited for 30s" can't register as Claude activity.
const GLYPH = '[✻✺✽✼✾✿❀✶✵✷✴✳✲✱✢●○◉◍◌◦]';
// Patterns to match in Claude Code terminal output
const PATTERNS = {
    // "Running 3 agents…" or "● 3 Explore agents finished"
    agentBatchStart: /Running (\d+) agents/,
    agentBatchDone: /(\d+)\s+\w+\s+agents?\s+finished/,
    // "├─ Research · 2 tool uses · 13.4k tokens" or "└─ Name · N tool uses · Xk tokens"
    agentDetail: /[├└]─\s*(.+?)\s*·\s*(\d+)\s*tool\s*uses?\s*·\s*([\d.]+k?)\s*tokens/,
    // "⎿  Done" after an agent entry
    agentDone: /⎿\s+Done/,
    // "Skill(name)" or "Skill(ns:name)"
    skillLoad: /Skill\(([^)]+)\)/,
    // "● Bash(...)", "● Task(...)", "● TodoWrite(...)" — any capitalized tool
    // header. The fixed tool list kept falling behind Claude Code releases.
    toolUse: /●\s*([A-Z][A-Za-z_]*)\s*\(/,
    // Current Bash progress header: "● Running 1 shell command…"
    shellHeader: /●\s*Running \d+ shell commands?/,
    mcpTool: /●\s*plugin:([^:]+):([^\s]+)/,
    // Claude is mid-turn. Two forms:
    // (a) the interrupt hints — "esc to interrupt" historically lived on the
    //     spinner line and now sits in the persistent footer while a turn runs;
    //     "ctrl+b to run in background" accompanies a running shell command.
    working: /esc to interrupt|ctrl\+b to run in background/i,
    // (b) the live spinner line itself, glyph-anchored with an elapsed-time
    //     counter: "✳ Photosynthesizing… (2m 16s · ↓ 6.4k tokens)". Newer Claude
    //     Code versions no longer put "esc to interrupt" on this line, and the
    //     footer may not be part of a diff repaint chunk — so the spinner is an
    //     independent working signal.
    workingSpinner: new RegExp(`^\\s*${GLYPH}\\s*\\S+.*\\(\\s*(?:\\d+h\\s*)?(?:\\d+m\\s*)?\\d+s\\b`),
    // Claude finished the turn. The status line settles into "✻ Baked for 3m 10s"
    // (glyph-anchored, and the duration must carry a time unit so prose like
    // "for 3 platforms" can't trigger it), or a /cost-style summary line —
    // anchored to line start; the old anywhere-on-the-line match fired on
    // ordinary output that merely mentioned "Total duration" or "tokens used".
    responseDone: new RegExp(`^\\s*${GLYPH}\\s*\\S+ for\\s+\\d+[smh]\\b|^\\s*(?:Cost:|Total cost|Total duration|tokens used)`, 'i'),
    // Claude is sitting at its input prompt with NO turn in flight: the startup
    // banner ("Claude Code v2.1.207") or the idle footer ("? for shortcuts" —
    // which the footer only shows when no turn is running; mid-turn it swaps to
    // "esc to interrupt"). Without this, a freshly launched claude shows the
    // shell tier's 'running' (the preexec report from launching it) even though
    // the agent is doing nothing.
    idlePrompt: /\?\s+for shortcuts|Claude Code v\d+\.\d+/,
};
/**
 * Process a chunk of PTY data for Claude Code patterns.
 * Called from the main process whenever PTY data flows through.
 */
function observePtyData(surfaceId, data) {
    const clean = stripAnsi(data);
    // Re-attach whatever the previous chunk left unterminated, then hold back this
    // chunk's own trailing fragment. It is NOT parsed here: the next write
    // terminates it (agents repaint continuously), and parsing it twice would let
    // a line like "Running 3 agents…" reset the agent list on both passes.
    const buffered = (partials.get(surfaceId) ?? '') + clean;
    const lines = splitLines(buffered);
    const partial = lines.pop() ?? '';
    partials.set(surfaceId, partial.length > PARTIAL_MAX ? partial.slice(-PARTIAL_MAX) : partial);
    // Chunk-local parse results. Status evidence is resolved in line order —
    // the LAST status-bearing line in the chunk wins, mirroring what the screen
    // actually shows after the chunk rendered.
    let finalStatus = null;
    let tool;
    let skill;
    let agentsChanged = false;
    let agents = agentLists.get(surfaceId);
    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed)
            continue;
        // Live working indicators — checked before responseDone so the active
        // status line can never be mistaken for completion.
        if (PATTERNS.working.test(trimmed) || PATTERNS.workingSpinner.test(trimmed)) {
            finalStatus = 'working';
            continue;
        }
        // Response done ("✻ Baked for 3m 10s" / line-start "Cost:" / "Total cost …")
        if (PATTERNS.responseDone.test(trimmed)) {
            finalStatus = 'done';
            continue;
        }
        // Idle at the input prompt (startup banner / "? for shortcuts" footer).
        // The footer renders below everything, so it wins over stale working
        // evidence above it (esc-interrupted turns settle to idle this way) —
        // EXCEPT over a done line: a turn-end repaint carries both the settle
        // line and the idle footer in one chunk, and the done edge (with its
        // attention toast) must not be swallowed. The machine keeps 'done'
        // sticky against later idle signals for the same reason.
        if (PATTERNS.idlePrompt.test(trimmed)) {
            if (finalStatus !== 'done')
                finalStatus = 'idle';
            continue;
        }
        // ●-prefixed families (tool headers, MCP tools) and the agent/skill lines
        // are gated on cheap substring checks — this loop runs for every line of
        // every terminal's output, and the common case matches nothing.
        if (trimmed.includes('●')) {
            // Current-format Bash progress header ("● Running 1 shell command…")
            if (PATTERNS.shellHeader.test(trimmed)) {
                tool = 'Bash';
                finalStatus = 'working';
                continue;
            }
            // MCP tool — checked before the generic tool header so "● plugin:x:y"
            // isn't swallowed by the capitalized-word match.
            const mcpMatch = trimmed.match(PATTERNS.mcpTool);
            if (mcpMatch) {
                tool = `${mcpMatch[1]}:${mcpMatch[2]}`;
                finalStatus = 'working';
                continue;
            }
            // Tool use header — a new tool call means the turn is in flight.
            const toolMatch = trimmed.match(PATTERNS.toolUse);
            if (toolMatch) {
                tool = toolMatch[1];
                finalStatus = 'working';
                continue;
            }
        }
        // Agent batch start / done ("Running 3 agents…", "3 Explore agents finished")
        if (trimmed.includes('agents')) {
            if (PATTERNS.agentBatchStart.test(trimmed)) {
                agents = [];
                agentLists.set(surfaceId, agents);
                agentsChanged = true;
                finalStatus = 'working';
                continue;
            }
            if (PATTERNS.agentBatchDone.test(trimmed)) {
                if (agents?.length && agents.some(a => !a.done)) {
                    agents.forEach(a => { a.done = true; });
                    agentsChanged = true;
                }
                continue;
            }
        }
        // Agent detail line ("├─ Research · 2 tool uses · 13.4k tokens")
        if (trimmed.includes('tokens')) {
            const detailMatch = trimmed.match(PATTERNS.agentDetail);
            if (detailMatch) {
                const name = detailMatch[1].trim();
                const toolUses = parseInt(detailMatch[2]);
                const tokens = detailMatch[3];
                if (!agents) {
                    agents = [];
                    agentLists.set(surfaceId, agents);
                }
                const existing = agents.find(a => a.name === name);
                if (existing) {
                    // Repaints re-emit identical rows constantly — only a real value
                    // change may trigger a broadcast.
                    if (existing.toolUses !== toolUses || existing.tokens !== tokens) {
                        existing.toolUses = toolUses;
                        existing.tokens = tokens;
                        agentsChanged = true;
                    }
                }
                else {
                    agents.push({ name, toolUses, tokens, done: false });
                    agentsChanged = true;
                }
                continue;
            }
        }
        // Agent done ("⎿  Done" after an agent entry)
        if (trimmed.includes('⎿') && PATTERNS.agentDone.test(trimmed)) {
            const lastAgent = agents?.[agents.length - 1];
            if (lastAgent && !lastAgent.done) {
                lastAgent.done = true;
                agentsChanged = true;
            }
            continue;
        }
        // Skill loaded
        if (trimmed.includes('Skill(')) {
            const skillMatch = trimmed.match(PATTERNS.skillLoad);
            if (skillMatch) {
                skill = skillMatch[1];
                continue;
            }
        }
    }
    // Emit at most one status signal per chunk, with any parsed details attached.
    const details = {};
    if (tool !== undefined)
        details.tool = tool;
    if (skill !== undefined)
        details.skill = skill;
    if (agentsChanged && agents)
        details.agents = [...agents];
    // Skill loads and agent progress lines only render mid-turn, so they count
    // as working evidence even without an explicit spinner in this chunk.
    const signaledWorking = finalStatus === 'working' ||
        (finalStatus !== 'done' && finalStatus !== 'idle' && (skill !== undefined || agentsChanged));
    if (finalStatus === 'done') {
        (0, surface_status_1.signal)(surfaceId, { type: 'done', via: 'pattern', ...details });
    }
    else if (signaledWorking) {
        (0, surface_status_1.signal)(surfaceId, { type: 'working', ...details });
    }
    // Waiting-for-input is SET when a prompt renders in the tail and CLEARED by
    // the machine on the next working/done edge. Any chunk carrying working or
    // done evidence discards the tail — otherwise a stale prompt still sitting
    // in the rolling window would immediately re-flip the surface back to
    // waiting (flapping the dot and re-firing attention).
    if (signaledWorking || finalStatus === 'done') {
        tails.set(surfaceId, '');
    }
    else {
        const tail = ((tails.get(surfaceId) ?? '') + clean).slice(-TAIL_MAX);
        tails.set(surfaceId, tail);
        if ((0, agent_detect_1.detectWaitingForInput)(tail)) {
            // A rendered permission/confirm prompt outranks the idle footer — the
            // costlier mistake is hiding an agent that needs the user.
            (0, surface_status_1.signal)(surfaceId, { type: 'waiting', via: 'pattern' });
        }
        else if (finalStatus === 'idle') {
            // Claude is at its input prompt with no turn in flight (startup banner
            // or idle footer) — claude-tier idle, so the tab dot stops showing the
            // shell's frozen 'running' from the preexec that launched claude.
            (0, surface_status_1.signal)(surfaceId, { type: 'idle' });
        }
        else {
            // No recognizable pattern — still refresh the keepalive so ConPTY
            // diff-repaints (which may not re-emit a full matchable line) can't
            // starve an in-flight turn into the watchdog.
            (0, surface_status_1.touch)(surfaceId);
        }
    }
}
/**
 * Clear parser state for a surface (when its terminal closes). The machine's
 * record is cleared separately via surface-status.clearSurface().
 */
function clearActivity(surfaceId) {
    agentLists.delete(surfaceId);
    tails.delete(surfaceId);
    partials.delete(surfaceId);
}

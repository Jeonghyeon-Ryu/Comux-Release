#!/usr/bin/env bash
# Stop hook. In an orchestrated worker (COMUX_ORCH_AGENT set by launch-agent.js):
# the evidence gate — no result file, no stopping — then completion, which
# starts whatever was waiting on this agent. In any other session: warn if an
# orchestration still has agents running.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -n "${COMUX_ORCH_AGENT:-}" ] && [ -n "${COMUX_ORCH_DIR:-}" ]; then
  node "$SCRIPT_DIR/orch.js" stop-hook
  exit 0
fi

source "$SCRIPT_DIR/orchestration-state.sh"
ORCH_DIR=$(find_active_orch)
[ -z "$ORCH_DIR" ] && exit 0

RUNNING=$(node "$JSON_TOOL" query "$ORCH_DIR/state.json" count-agents-by-status running 2>/dev/null)
if [ "$RUNNING" -gt 0 ] 2>/dev/null; then
  echo "WARNING: comux orchestration in progress with $RUNNING active agent(s)."
  echo "Exiting now will leave agents running unmonitored."
fi

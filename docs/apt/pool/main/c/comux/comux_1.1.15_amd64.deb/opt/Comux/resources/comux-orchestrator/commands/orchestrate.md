---
name: comux:orchestrate
description: Decompose a complex dev task into parallel subtasks and orchestrate multiple Claude Code agents across comux terminal panes. Usage: /comux:orchestrate <task description>
---

You are about to orchestrate a multi-agent task decomposition. Use the orchestrate skill to proceed.

The user's task: $ARGUMENTS

Invoke the Skill tool with skill "comux-orchestrator:orchestrate" now.

# comux zsh shim — login shells only. Pass the user's file through untouched.
if [ -f "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zlogin" ]; then
    source "${COMUX_ZDOTDIR_ORIG:-$HOME}/.zlogin"
fi

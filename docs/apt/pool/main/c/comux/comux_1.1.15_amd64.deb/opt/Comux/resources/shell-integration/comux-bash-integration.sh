#!/bin/bash
# comux Bash/Zsh Integration
# Sourced via COMUX_INTEGRATION=1 detection

export COMUX=1

# comux CLI shortcut — Claude Code and users can just type: comux browser open <url>
comux() { node "$COMUX_CLI" "$@"; }
export -f comux 2>/dev/null

# ── Transport ────────────────────────────────────────────────────────────────
# Reports go to comux over $COMUX_PIPE — a Unix socket on Linux/macOS, a named
# pipe on Windows — the same V1 line protocol the PowerShell integration speaks.
#
# This used to append the lines to /mnt/c/Users/$USER/AppData/Local/Temp/comux/
# messages: a path hardcoded for WSL that no part of comux has ever read. Every
# report from bash/zsh was therefore discarded, which is why cwd, git branch and
# shell state never appeared for these shells — most visibly on Linux/SSH, where
# bash IS the shell and there is no PowerShell integration to fall back on.
#
# bash cannot open a socket itself, so pick a helper ONCE here rather than probing
# on every prompt. The server is line-framed, so a whole prompt's worth of reports
# travels over a single connection.
_comux_send=""
if [ -n "${COMUX_PIPE:-}" ]; then
    case "${COMUX_PIPE:-}" in
        '\\'*|//*)
            # Windows named pipe: nc/socat cannot address it, node can.
            _comux_send="node"
            ;;
        *)
            # `nc -U` is openbsd-netcat; GNU netcat has no -U and must not be used.
            if command -v nc >/dev/null 2>&1 && nc -h 2>&1 | grep -q -- '-U'; then
                _comux_send="nc"
            elif command -v socat >/dev/null 2>&1; then
                _comux_send="socat"
            else
                _comux_send="node"
            fi
            ;;
    esac
    # The node fallback needs both the CLI path and node itself.
    if [ "$_comux_send" = "node" ]; then
        { [ -n "${COMUX_CLI:-}" ] && command -v node >/dev/null 2>&1; } || _comux_send=""
    fi
fi

# Send every line on stdin as one batch. Backgrounded and silenced: a report must
# never block, slow or dirty a prompt, and it must never matter if comux is gone.
# The reader side never closes the connection (it answers "ok" and waits for more),
# so the socket clients are given a 1s cap instead of being left to hang.
_comux_flush() {
    [ -n "$_comux_send" ] || { cat >/dev/null 2>&1; return 0; }
    case "$_comux_send" in
        nc)    nc -U -w 1 "$COMUX_PIPE" >/dev/null 2>&1 & ;;
        socat) socat -t 1 - UNIX-CONNECT:"$COMUX_PIPE" >/dev/null 2>&1 & ;;
        node)  node "$COMUX_CLI" report >/dev/null 2>&1 & ;;
    esac
}

# Git Bash / MSYS report $PWD as /c/Users/... , which the Windows side of comux
# cannot resolve (the git poller would watch a path that does not exist). cygpath
# converts it back. Probed once: on Linux there is no cygpath and no cost.
_comux_cygpath=""
command -v cygpath >/dev/null 2>&1 && _comux_cygpath="1"
_comux_pwd() {
    if [ -n "$_comux_cygpath" ]; then
        cygpath -w "$PWD" 2>/dev/null || printf '%s' "$PWD"
    else
        printf '%s' "$PWD"
    fi
}

_comux_git_line() {
    local surface_id="$1"
    local branch
    branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
    if [ -n "$branch" ]; then
        local dirty=""
        [ -n "$(git status --porcelain 2>/dev/null)" ] && dirty="dirty"
        printf 'report_git_branch %s %s %s\n' "$surface_id" "$branch" "$dirty"
    else
        printf 'clear_git_branch %s\n' "$surface_id"
    fi
}

_comux_precmd() {
    local exit_code=$?
    local surface_id="${COMUX_SURFACE_ID:-}"
    [ -z "$surface_id" ] && return
    local state="idle"
    # 130 = SIGINT (Ctrl+C), 137 = SIGKILL, 143 = SIGTERM
    if [ "$exit_code" -eq 130 ] || [ "$exit_code" -eq 137 ] || [ "$exit_code" -eq 143 ]; then
        state="interrupted"
    fi
    {
        printf 'report_pwd %s %s\n' "$surface_id" "$(_comux_pwd)"
        _comux_git_line "$surface_id"
        printf 'report_shell_state %s %s\n' "$surface_id" "$state"
        printf 'ports_kick %s\n' "$surface_id"
    } | _comux_flush
}

# Report "running" before a command executes (pre-execution hook)
_comux_preexec() {
    local surface_id="${COMUX_SURFACE_ID:-}"
    [ -z "$surface_id" ] && return
    printf 'report_shell_state %s running\n' "$surface_id" | _comux_flush
}

# Install hooks. The :- defaults matter: a user with `set -u` in their rc would
# otherwise get "ZSH_VERSION: unbound variable" the moment comux sources this,
# breaking their shell startup.
if [ -n "${ZSH_VERSION:-}" ]; then
    # Zsh: native preexec + precmd
    autoload -Uz add-zsh-hook
    add-zsh-hook precmd _comux_precmd
    add-zsh-hook preexec _comux_preexec
elif [ -n "${BASH_VERSION:-}" ]; then
    # Bash: DEBUG trap as preexec, PROMPT_COMMAND as precmd
    _comux_bash_preexec_active=0
    trap '_comux_bash_preexec_active=1; _comux_preexec' DEBUG
    PROMPT_COMMAND="_comux_precmd; _comux_bash_preexec_active=0${PROMPT_COMMAND:+;$PROMPT_COMMAND}"
fi

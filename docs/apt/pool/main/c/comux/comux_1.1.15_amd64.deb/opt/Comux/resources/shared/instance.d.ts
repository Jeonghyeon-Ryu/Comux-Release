/** "-<name>" for an isolated instance (COMUX_INSTANCE, or any dev run); "" for the installed app. */
export declare function instanceSuffix(): string;
export declare function getPipePath(): string;
export declare function getAppDataDir(): string;

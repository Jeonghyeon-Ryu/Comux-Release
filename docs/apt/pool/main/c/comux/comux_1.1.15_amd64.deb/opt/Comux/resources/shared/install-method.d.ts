export type InstallMethod = 'zip' | 'deb' | 'appimage' | 'script' | 'tarball' | 'dev' | 'unknown';
export interface InstallInfo {
    method: InstallMethod;
    /** Shell command that upgrades this install, or null when there is no one-liner. */
    upgradeCommand: string | null;
    /** True only where comux can replace itself with no user action. */
    autoInstallable: boolean;
    /** Directory the install lives in — shown to the user, not used for logic. */
    root: string;
}
export declare const DOWNLOAD_PAGE = "https://jeonghyeon-ryu.github.io/Comux-Release/";
export interface DetectEnv {
    platform: NodeJS.Platform;
    /** process.execPath — the app binary for Electron, the node binary otherwise. */
    execPath: string;
    /** __dirname of this module once compiled (…/dist/shared). */
    moduleDir: string;
    home: string;
    /** Set by the AppImage runtime to the .AppImage path. */
    appImage?: string;
    /** Running inside Electron rather than plain Node. */
    electron: boolean;
    /** Electron's app.isPackaged; undefined outside Electron. */
    packaged?: boolean;
    exists?: (p: string) => boolean;
}
export declare function detectInstallMethod(partial?: Partial<DetectEnv>): InstallInfo;

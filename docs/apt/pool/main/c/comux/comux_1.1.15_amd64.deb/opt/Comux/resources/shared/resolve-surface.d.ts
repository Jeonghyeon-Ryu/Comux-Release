/**
 * Deciding which terminal a write should go to.
 *
 * Every external write path funnels through this: the pipe's `surface.send_text`
 * and `send_key`, and the REST `/terminals/:id/input`. The caller may name a
 * surface or leave it out, and "leave it out" has to mean the surface the user
 * is actually looking at.
 *
 * The decision is separated from HOW the host answers the two questions it asks
 * — the GUI reads the active surface out of the renderer over IPC and checks its
 * PtyManager; the daemon walks its SessionModel. Same injection style as
 * RestServerDeps and AgentSeedHost, and it makes the branch table testable
 * without an Electron window.
 */
export interface SurfaceResolverHost {
    /** The surface the user is on, or null. May reject — the host is remote. */
    getActiveSurfaceId: () => Promise<string | null | undefined>;
    /** Is there a live PTY behind this surface? */
    hasPty: (surfaceId: string) => boolean;
}
export type ResolvedSurface = {
    ok: true;
    id: `surf-${string}`;
} | {
    ok: false;
    error: string;
};
/**
 * Resolve `id` (or the active surface when absent) to a writable terminal.
 *
 * Every failure is a distinct message rather than a bare false: these strings
 * surface to a CLI user or an HTTP client as the entire explanation, and
 * "no surface" vs "that surface is a markdown pane" lead to different fixes.
 */
export declare function resolveSurfaceForWrite(id: string | undefined, host: SurfaceResolverHost): Promise<ResolvedSurface>;

/**
 * What a <webview> is allowed to ask for.
 *
 * `webviewTag` is on, so any script running in the host renderer — the whole
 * point of the markdown pane's sanitizer, and of a CSP if one is ever added —
 * can append a `<webview>` and choose its privileges through attributes. Those
 * attributes are attacker-controlled input; this is where they get overruled.
 *
 * Lifted out of the `will-attach-webview` handler in src/main/index.ts so it can
 * be tested without starting Electron, the same reason translateKeyName and
 * resolveSurfaceForWrite were lifted. The handler is one line of glue now.
 *
 * Nothing here can change how the REAL browser panel behaves: BrowserPane sets
 * only `src`, `partition` and style, so every preference forced below is one it
 * never asked for.
 */
/** The loose shapes Electron hands the will-attach-webview listener. */
export type WebviewPreferences = Record<string, unknown>;
export type WebviewParams = Record<string, unknown>;
export declare function hardenWebviewAttach(webPreferences: WebviewPreferences, params: WebviewParams): void;

"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitPoller = void 0;
const child_process_1 = require("child_process");
const util_1 = require("util");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const git_safe_1 = require("./git-safe");
const execFileAsync = (0, util_1.promisify)(child_process_1.execFile);
class GitPoller {
    watchers = new Map(); // cwd → watcher
    callback = null;
    onUpdate(callback) {
        this.callback = callback;
    }
    /**
     * Start watching a directory's .git/HEAD for branch changes.
     */
    watch(cwd) {
        if (this.watchers.has(cwd))
            return;
        const gitHead = path_1.default.join(cwd, '.git', 'HEAD');
        if (!fs_1.default.existsSync(gitHead))
            return;
        try {
            const watcher = fs_1.default.watch(gitHead, { persistent: false }, () => {
                this.pollGitState(cwd);
            });
            this.watchers.set(cwd, watcher);
            // Initial poll
            this.pollGitState(cwd);
        }
        catch {
            // Not a git repo or can't watch
        }
    }
    unwatch(cwd) {
        const watcher = this.watchers.get(cwd);
        if (watcher) {
            watcher.close();
            this.watchers.delete(cwd);
        }
    }
    unwatchAll() {
        for (const [cwd] of this.watchers) {
            this.unwatch(cwd);
        }
    }
    async pollGitState(cwd) {
        try {
            const { stdout: branch } = await execFileAsync('git', [...git_safe_1.SAFE_GIT_FLAGS, 'rev-parse', '--abbrev-ref', 'HEAD'], {
                cwd,
                windowsHide: true,
                timeout: 5000,
            });
            let dirty = false;
            try {
                const { stdout: status } = await execFileAsync('git', [...git_safe_1.SAFE_GIT_FLAGS, 'status', '--porcelain'], {
                    cwd,
                    windowsHide: true,
                    timeout: 5000,
                });
                dirty = status.trim().length > 0;
            }
            catch { }
            this.callback?.(cwd, { branch: branch.trim(), dirty });
        }
        catch {
            this.callback?.(cwd, { branch: null, dirty: false });
        }
    }
}
exports.GitPoller = GitPoller;

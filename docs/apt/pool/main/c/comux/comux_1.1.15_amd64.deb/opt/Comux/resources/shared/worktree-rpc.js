"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorktreeRpcError = exports.WORKTREE_METHODS = void 0;
exports.setupKeystrokes = setupKeystrokes;
exports.handleWorktreeRpc = handleWorktreeRpc;
const worktree_1 = require("./worktree");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
exports.WORKTREE_METHODS = ['worktree.create', 'worktree.list', 'worktree.remove', 'worktree.inspect'];
const ownerOf = (host, p) => host.workspaces().find((w) => w.worktree && (0, worktree_1.samePath)(w.worktree.path, p));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** JSON-RPC error carrying a WorktreeError's code, so the CLI can say why. */
class WorktreeRpcError extends Error {
    rpcCode;
    data;
    constructor(message, rpcCode, data) {
        super(message);
        this.rpcCode = rpcCode;
        this.data = data;
    }
}
exports.WorktreeRpcError = WorktreeRpcError;
function rpcError(e) {
    if (e instanceof WorktreeRpcError)
        return e;
    if (e instanceof worktree_1.WorktreeError) {
        const invalid = e.code === 'bad_branch' || e.code === 'not_a_repo' || e.code === 'not_found';
        return new WorktreeRpcError(e.message, invalid ? -32602 : -32000, { reason: e.code, ...(e.changes != null ? { changes: e.changes } : {}) });
    }
    return new WorktreeRpcError(e?.message || String(e), -32000);
}
/** Lines to type into a shell: one command per line works in every shell, `&&` does not (PowerShell 5.1). */
function setupKeystrokes(commands) {
    return commands.map((c) => `${c}\r`).join('');
}
async function handleWorktreeRpc(method, p, host) {
    try {
        switch (method) {
            case 'worktree.inspect': {
                const cwd = String(p.cwd || '');
                const repo = await (0, worktree_1.resolveRepo)(cwd);
                const config = (0, worktree_1.readWorktreeConfig)(repo.root);
                return {
                    repoRoot: repo.mainRoot,
                    sourceRoot: repo.root,
                    branch: repo.branch,
                    worktreeDir: (0, worktree_1.worktreeRootFor)(repo.mainRoot, config.dir),
                    setup: config.setup,
                    ...(config.error ? { configError: config.error } : {}),
                    includeFile: fs.existsSync(path.join(repo.root, worktree_1.WORKTREE_INCLUDE_FILE)),
                    configFile: worktree_1.WORKTREE_CONFIG_FILE,
                };
            }
            case 'worktree.create': {
                if (!p.branch)
                    throw new WorktreeRpcError('worktree.create needs a branch name', -32602);
                const r = await (0, worktree_1.createWorktree)({ cwd: String(p.cwd || ''), branch: String(p.branch), base: p.base, path: p.path });
                let workspaceId = null;
                let setupStarted = false;
                if (p.workspace !== false) {
                    const owner = ownerOf(host, r.path);
                    if (owner) {
                        workspaceId = owner.id;
                    }
                    else {
                        const made = host.createWorkspace({
                            title: String(p.title || r.branch),
                            cwd: r.path,
                            worktree: { path: r.path, branch: r.branch, repoRoot: r.repoRoot, ...(r.base ? { base: r.base } : {}) },
                        });
                        workspaceId = made.workspaceId;
                        // Setup only on a checkout made just now, and only when asked —
                        // the commands come from the repository (see shared/worktree.ts).
                        if (p.setup && !r.reused && r.setup.length > 0 && made.surfaceId) {
                            host.typeWhenReady(made.surfaceId, setupKeystrokes(r.setup));
                            setupStarted = true;
                        }
                    }
                    if (p.select !== false && workspaceId)
                        host.selectWorkspace(workspaceId);
                }
                return { ...r, workspaceId, setupStarted };
            }
            case 'worktree.list': {
                const repo = await (0, worktree_1.resolveRepo)(String(p.cwd || ''));
                const entries = await (0, worktree_1.listWorktrees)(repo.mainRoot);
                const worktrees = await Promise.all(entries.map(async (e) => {
                    const owner = ownerOf(host, e.path);
                    const main = (0, worktree_1.samePath)(e.path, repo.mainRoot);
                    const changes = p.status && !main && fs.existsSync(e.path) ? await (0, worktree_1.worktreeChanges)(e.path).catch(() => null) : undefined;
                    return {
                        path: e.path, branch: e.branch, head: e.head, main,
                        detached: e.detached, locked: e.locked, prunable: e.prunable,
                        workspaceId: owner?.id ?? null, workspaceTitle: owner?.title ?? null,
                        ...(changes !== undefined ? { changes } : {}),
                    };
                }));
                return { repoRoot: repo.mainRoot, worktrees };
            }
            case 'worktree.remove': {
                // Name it by path, branch or owning workspace — whichever the caller has.
                let target = p.path ? path.resolve(String(p.cwd || '.'), String(p.path)) : null;
                let owner = target ? ownerOf(host, target) : undefined;
                if (!target && p.workspaceId) {
                    owner = host.workspaces().find((w) => w.id === p.workspaceId);
                    if (!owner?.worktree)
                        throw new WorktreeRpcError(`Workspace ${p.workspaceId} is not on a comux worktree`, -32602);
                    target = owner.worktree.path;
                }
                if (!target && p.branch) {
                    const repo = await (0, worktree_1.resolveRepo)(String(p.cwd || ''));
                    const hit = (await (0, worktree_1.listWorktrees)(repo.mainRoot)).find((e) => e.branch === p.branch && !(0, worktree_1.samePath)(e.path, repo.mainRoot));
                    if (!hit)
                        throw new WorktreeRpcError(`No worktree has branch '${p.branch}' (see: comux worktree list)`, -32602);
                    target = hit.path;
                    owner = ownerOf(host, target);
                }
                if (!target)
                    throw new WorktreeRpcError('worktree.remove needs a path, --branch or --workspace', -32602);
                const repoHint = owner?.worktree?.repoRoot ?? (p.cwd ? String(p.cwd) : undefined);
                // Refuse BEFORE closing anything: a dirty worktree must keep its workspace.
                const { entry } = await (0, worktree_1.findWorktree)(target, repoHint);
                if (!p.force && fs.existsSync(entry.path)) {
                    const n = await (0, worktree_1.worktreeChanges)(entry.path);
                    if (n > 0)
                        throw new worktree_1.WorktreeError(`${n} uncommitted change(s) in ${entry.path} — commit them, or remove with --force`, 'dirty', n);
                }
                let closedWorkspace = null;
                if (owner && p.closeWorkspace !== false) {
                    host.closeWorkspace(owner.id);
                    closedWorkspace = owner.id;
                }
                // Its shells sit in that folder, and Windows will not delete a
                // directory that is some process's cwd. `afterClose`: the renderer
                // closed the workspace itself just before asking.
                if (closedWorkspace || p.afterClose)
                    await sleep(host.ptyReleaseMs);
                const r = await (0, worktree_1.removeWorktree)({ path: entry.path, force: !!p.force, deleteBranch: !!p.deleteBranch, repoHint });
                return { ...r, removed: true, closedWorkspace };
            }
        }
        throw new WorktreeRpcError(`Unknown method: ${method}`, -32601);
    }
    catch (e) {
        throw rpcError(e);
    }
}

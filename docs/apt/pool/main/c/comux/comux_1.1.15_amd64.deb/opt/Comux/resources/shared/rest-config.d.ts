import { RestApiConfig, RestEndpoint, RestEndpointMode, RestEndpointAgent } from './types';
export declare const VALID_MODES: RestEndpointMode[];
export declare const VALID_AGENTS: RestEndpointAgent[];
/**
 * Collapse an endpoint name to its persisted form: it becomes the URL path
 * segment of `POST /api/<name>`, so spaces and slashes can't survive.
 *
 * Exported because every caller that looks an endpoint up BY NAME has to match
 * what was written. `upsertEndpoint('my ep')` comparing raw would append a second
 * `my-ep`, which sanitizeEndpoints then silently drops as a duplicate — the edit
 * would just vanish.
 */
export declare function normalizeEndpointName(raw: string): string;
/** A port http.Server will actually accept. */
export declare function isValidPort(v: unknown): boolean;
/** Read the config (cached). Generates+persists a token on first run. */
export declare function getRestConfig(): RestApiConfig;
/** Overwrite the whole config and persist it. */
export declare function saveRestConfig(config: RestApiConfig): RestApiConfig;
/**
 * Merge a partial update (host/port/enabled/endpoints) into the saved config.
 *
 * Re-reads from disk FIRST. `getRestConfig()` memoizes for the life of the
 * process and nothing watches the file, so merging over the cache meant a
 * long-lived host — the GUI, or comuxd — wrote back whatever it happened to read
 * at startup. Toggling one checkbox in Settings then silently reverted every
 * change made since: a rotated token, a `comux rest add-endpoint`, a hand-edited
 * host. On a file that holds the credential driving terminals, that is data loss.
 *
 * This narrows the window to the read-modify-write itself rather than closing it
 * — two processes saving at the same instant are still last-writer-wins — but
 * that window is microseconds instead of a whole session.
 */
export declare function updateRestConfig(partial: Partial<RestApiConfig>): RestApiConfig;
/** Roll a fresh token (invalidates all existing external credentials). */
export declare function regenerateRestToken(): RestApiConfig;
/**
 * Absolute path of rest-api.json. Printed by `comux rest status` because the path
 * carries the instance suffix (COMUX_INSTANCE, or `-dev` for an unpackaged run) —
 * without showing it, editing the prod config while a dev instance reads
 * `comux-dev` looks like the setting simply had no effect.
 */
export declare function restConfigPath(): string;
/**
 * Forget the cached config and re-read it from disk.
 *
 * `comux rest enable` rewrites the file from its OWN short-lived process, so a
 * long-lived host (the GUI, or comuxd) still holds whatever it cached at startup.
 * The `rest.reload` pipe method calls this and then re-runs startRestServer, which
 * is what lets the change land without restarting the daemon and dropping every
 * shell it owns.
 */
export declare function reloadRestConfig(): RestApiConfig;
/** The fields `comux rest add-endpoint` can set. Omitted fields keep their
 *  previous value on an update, or take the safe default on a create. */
export interface EndpointSpec {
    name: string;
    agent?: RestEndpointAgent;
    mode?: RestEndpointMode;
    cwd?: string;
    prompt?: string;
}
/**
 * Add an endpoint, or merge `spec`'s provided fields into the existing one with
 * that name. Pure — the caller persists through updateRestConfig, which
 * re-validates the result (so a bad agent/mode can't slip in this way either).
 */
export declare function upsertEndpoint(endpoints: RestEndpoint[], spec: EndpointSpec): RestEndpoint[];
/** Drop the endpoint with this name. `removed` is null when nothing matched, so
 *  the caller can report "no such endpoint" instead of a silent no-op. */
export declare function removeEndpoint(endpoints: RestEndpoint[], name: string): {
    endpoints: RestEndpoint[];
    removed: RestEndpoint | null;
};

#!/usr/bin/env node
// launch-agent.js — start one orchestrated agent in this terminal.
//
//   node launch-agent.js <prompt-file> [--cli claude|codex|gemini|opencode]
//                        [--orch-dir DIR --orch-agent ID]
//
// The agent runs INTERACTIVELY (full TUI) so the user can watch and step in.
// --orch-dir/--orch-agent become COMUX_ORCH_DIR/COMUX_ORCH_AGENT in the
// agent's environment: that is how its Claude Code hooks (Stop, PostToolUse)
// know which orchestration and which plan entry they belong to. comux's own
// COMUX_AGENT_ID is comux's id for the process, not the plan's.
//
// COMUX_AGENT_CMD=opencode still selects opencode when --cli is not given.

const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const argv = process.argv.slice(2);
const flag = (n) => { const i = argv.indexOf(n); return i === -1 ? undefined : argv[i + 1]; };
const promptFile = argv[0];
if (!promptFile || promptFile.startsWith('--')) {
  console.error('Usage: node launch-agent.js <prompt-file> [--cli claude|codex|gemini|opencode] [--orch-dir DIR --orch-agent ID]');
  process.exit(1);
}
if (!fs.existsSync(promptFile)) {
  console.error(`Prompt file not found: ${promptFile}`);
  process.exit(1);
}

const cli = (flag('--cli') || process.env.COMUX_AGENT_CMD || 'claude').toLowerCase();
const env = { ...process.env };
if (flag('--orch-dir')) env.COMUX_ORCH_DIR = flag('--orch-dir');
if (flag('--orch-agent')) env.COMUX_ORCH_AGENT = flag('--orch-agent');

const prompt = fs.readFileSync(promptFile, 'utf8');
// Claude takes the whole prompt as an argument (proven up to Windows' 32K
// command line). The others are often npm `.cmd` shims, which go through
// cmd.exe and its 8K line limit — so they get a short pointer to the file.
const pointer = `Read the file ${path.resolve(promptFile)} — it is your complete mission. Carry it out exactly, including writing the result file it names.`;

/** Run a CLI with stdio inherited; `.cmd` shims need a shell on Windows. */
function run(bin, args) {
  const isWin = process.platform === 'win32';
  let r = spawnSync(bin, args, { stdio: 'inherit', env });
  if (isWin && r.error && (r.error.code === 'ENOENT' || r.error.code === 'EINVAL')) {
    // Every argument here is a flag or the one-line pointer: safe to quote for cmd.exe.
    const line = [bin, ...args].map((a) => `"${String(a).replace(/"/g, '""')}"`).join(' ');
    r = spawnSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `"${line}"`], { stdio: 'inherit', env, windowsVerbatimArguments: true });
  }
  if (r.error) { console.error(`${bin}: ${r.error.message}`); return 127; }
  return r.status == null ? 1 : r.status;
}

let code;
switch (cli) {
  case 'codex':
    // Same autonomy the claude worker gets (it is watched in its own pane).
    code = run('codex', ['--dangerously-bypass-approvals-and-sandbox', '--', pointer]);
    break;
  case 'gemini':
    code = run('gemini', ['--approval-mode', 'yolo', '-i', pointer]);
    break;
  case 'opencode':
    // opencode run streams formatted progress; '--' stops flag parsing.
    code = run('opencode', ['run', '--', pointer]);
    break;
  default:
    // --dangerously-skip-permissions: auto-approve tools (interactive mode).
    // '--' stops Commander.js variadic flags from consuming the prompt.
    // NOTE: do NOT use --bare — it skips keychain/OAuth ("Not logged in").
    code = run('claude', ['--dangerously-skip-permissions', '--', prompt]);
}
process.exit(code);

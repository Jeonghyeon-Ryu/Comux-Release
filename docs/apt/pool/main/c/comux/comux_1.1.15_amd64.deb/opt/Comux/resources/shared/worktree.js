"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_COPY_LIMITS = exports.WORKTREE_INCLUDE_FILE = exports.WORKTREE_CONFIG_FILE = exports.WorktreeError = exports.branchSlug = void 0;
exports.samePath = samePath;
exports.worktreeRootFor = worktreeRootFor;
exports.uniqueChildPath = uniqueChildPath;
exports.resolveRepo = resolveRepo;
exports.parseWorktreeList = parseWorktreeList;
exports.listWorktrees = listWorktrees;
exports.worktreeChanges = worktreeChanges;
exports.readWorktreeConfig = readWorktreeConfig;
exports.listIncludeFiles = listIncludeFiles;
exports.copyIncludeFiles = copyIncludeFiles;
exports.createWorktree = createWorktree;
exports.findWorktree = findWorktree;
exports.removeWorktree = removeWorktree;
/**
 * Git worktrees for comux workspaces: one branch and one checkout per task, so
 * parallel agents never edit the same files.
 *
 * Electron-free — both hosts (main and comuxd) run it. The CLI never does: it
 * sends its own cwd and the host runs git, so a worktree made over SSH lands
 * on the daemon's disk, not the client's.
 *
 * Layout: worktrees go BESIDE the main checkout, in `<repo>.worktrees/<slug>`.
 * Inside the repo they would show up in every file watcher, search and
 * `git status` of the parent; under the app-data dir they would be invisible
 * to the user's editor. A repo can move them with `.comux/worktree.json`.
 *
 * Two optional files in the source checkout drive a new worktree:
 *  - `.worktreeinclude` — gitignore-syntax list of UNTRACKED files to copy in
 *    (`.env`, local config). Same name Claude Code, Orca and Paseo read.
 *  - `.comux/worktree.json` — `{ "setup": [...], "setupWindows": [...],
 *    "dir": "../elsewhere" }`. Setup commands are never run implicitly: the
 *    caller must ask (`--setup` / the dialog's checkbox), because they come
 *    from the repository and a clone is not consent to run its scripts.
 */
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const git_safe_1 = require("./git-safe");
const worktree_names_1 = require("./worktree-names");
Object.defineProperty(exports, "branchSlug", { enumerable: true, get: function () { return worktree_names_1.branchSlug; } });
class WorktreeError extends Error {
    code;
    changes;
    constructor(message, code = 'git', changes) {
        super(message);
        this.code = code;
        this.changes = changes;
        this.name = 'WorktreeError';
    }
}
exports.WorktreeError = WorktreeError;
/**
 * SAFE_GIT_FLAGS keep a repo's own config from running commands (fsmonitor,
 * hooks) — comux runs git in folders it did not choose. `core.longpaths`
 * because a worktree path is the repo path PLUS a sibling dir, and Windows
 * git still caps at MAX_PATH without it.
 */
function runGit(args, cwd, timeoutMs = 120_000) {
    return new Promise((resolve) => {
        (0, child_process_1.execFile)('git', [...git_safe_1.SAFE_GIT_FLAGS, '-c', 'core.longpaths=true', ...args], { cwd, timeout: timeoutMs, maxBuffer: 64 * 1024 * 1024, windowsHide: true, encoding: 'utf8' }, (err, stdout, stderr) => {
            const e = err;
            resolve({
                stdout: String(stdout ?? ''),
                stderr: String(stderr ?? ''),
                code: e ? (typeof e.code === 'number' ? e.code : -1) : 0,
                missing: e?.code === 'ENOENT',
            });
        });
    });
}
function firstLine(s) {
    return s.split(/\r?\n/).map((l) => l.replace(/^(fatal|error): /, '').trim()).find(Boolean) ?? '';
}
async function git(args, cwd, timeoutMs) {
    const r = await runGit(args, cwd, timeoutMs);
    if (r.missing)
        throw new WorktreeError('git is not installed or not on PATH', 'no_git');
    if (r.code !== 0)
        throw new WorktreeError(firstLine(r.stderr) || `git ${args[0]} failed`, 'git');
    return r.stdout;
}
// ─── paths ────────────────────────────────────────────────────────────────────
/** Same file system path? Case-insensitive on Windows, where git prints `C:/x` and node `C:\x`. */
function samePath(a, b) {
    const na = path.resolve(a);
    const nb = path.resolve(b);
    return process.platform === 'win32' ? na.toLowerCase() === nb.toLowerCase() : na === nb;
}
/** The folder new worktrees of this repo go in. */
function worktreeRootFor(mainRoot, dir) {
    if (dir)
        return path.resolve(mainRoot, dir);
    return path.join(path.dirname(mainRoot), `${path.basename(mainRoot)}.worktrees`);
}
/** `<root>/<slug>`, or `<slug>-2`, `-3`… when that folder is already taken. */
function uniqueChildPath(root, slug, exists = fs.existsSync) {
    let candidate = path.join(root, slug);
    for (let n = 2; exists(candidate); n++)
        candidate = path.join(root, `${slug}-${n}`);
    return candidate;
}
async function resolveRepo(cwd) {
    if (!cwd || !fs.existsSync(cwd))
        throw new WorktreeError(`Folder not found: ${cwd || '(none)'}`, 'not_a_repo');
    const top = await runGit(['rev-parse', '--show-toplevel'], cwd);
    if (top.missing)
        throw new WorktreeError('git is not installed or not on PATH', 'no_git');
    if (top.code !== 0)
        throw new WorktreeError(`Not inside a git repository: ${cwd}`, 'not_a_repo');
    const root = path.resolve(top.stdout.trim());
    // --path-format needs git 2.31; older git prints the dir relative to cwd.
    let common = await runGit(['rev-parse', '--path-format=absolute', '--git-common-dir'], cwd);
    if (common.code !== 0)
        common = await runGit(['rev-parse', '--git-common-dir'], cwd);
    const commonDir = path.resolve(cwd, common.stdout.trim().split(/\r?\n/).pop() || '.git');
    const mainRoot = path.basename(commonDir).toLowerCase() === '.git' ? path.dirname(commonDir) : root;
    const head = await runGit(['symbolic-ref', '--quiet', '--short', 'HEAD'], root);
    return { root, mainRoot, branch: head.code === 0 ? head.stdout.trim() || null : null };
}
/** Parse `git worktree list --porcelain`. Paths are returned as git printed them. */
function parseWorktreeList(out) {
    const entries = [];
    let cur = null;
    for (const raw of out.split(/\r?\n/)) {
        const line = raw.trimEnd();
        if (!line) {
            if (cur)
                entries.push(cur);
            cur = null;
            continue;
        }
        const sp = line.indexOf(' ');
        const key = sp === -1 ? line : line.slice(0, sp);
        const val = sp === -1 ? '' : line.slice(sp + 1);
        if (key === 'worktree') {
            if (cur)
                entries.push(cur);
            cur = { path: val, head: null, branch: null, bare: false, detached: false, locked: false, prunable: false };
            continue;
        }
        if (!cur)
            continue;
        if (key === 'HEAD')
            cur.head = val;
        else if (key === 'branch')
            cur.branch = val.replace(/^refs\/heads\//, '');
        else if (key === 'bare')
            cur.bare = true;
        else if (key === 'detached')
            cur.detached = true;
        else if (key === 'locked')
            cur.locked = true;
        else if (key === 'prunable')
            cur.prunable = true;
    }
    if (cur)
        entries.push(cur);
    return entries;
}
async function listWorktrees(cwd) {
    const out = await git(['worktree', 'list', '--porcelain'], cwd);
    return parseWorktreeList(out).map((e) => ({ ...e, path: path.resolve(e.path) }));
}
/** Tracked-file changes + untracked files (ignored files do not count). */
async function worktreeChanges(dir) {
    const out = await git(['status', '--porcelain'], dir);
    return out.split(/\r?\n/).filter(Boolean).length;
}
exports.WORKTREE_CONFIG_FILE = path.join('.comux', 'worktree.json');
exports.WORKTREE_INCLUDE_FILE = '.worktreeinclude';
function asCommands(v) {
    if (typeof v === 'string')
        return v.trim() ? [v.trim()] : [];
    if (Array.isArray(v))
        return v.filter((x) => typeof x === 'string' && !!x.trim()).map((x) => x.trim());
    return null;
}
function readWorktreeConfig(root, platform = process.platform) {
    const file = path.join(root, exports.WORKTREE_CONFIG_FILE);
    let raw;
    try {
        raw = fs.readFileSync(file, 'utf8');
    }
    catch {
        return { setup: [] };
    }
    let json;
    try {
        json = JSON.parse(raw);
    }
    catch (e) {
        return { setup: [], error: `${exports.WORKTREE_CONFIG_FILE}: ${e.message}` };
    }
    if (!json || typeof json !== 'object')
        return { setup: [], error: `${exports.WORKTREE_CONFIG_FILE}: expected an object` };
    // PowerShell 5.1 has no `&&` and different builtins, so a repo can give
    // Windows its own list; otherwise the shared one is used everywhere.
    const setup = (platform === 'win32' ? asCommands(json.setupWindows) : null) ?? asCommands(json.setup) ?? [];
    const dir = typeof json.dir === 'string' && json.dir.trim() ? json.dir.trim() : undefined;
    return { setup, dir };
}
/** Untracked files in `sourceRoot` that `.worktreeinclude` asks to carry over. */
async function listIncludeFiles(sourceRoot) {
    const inc = path.join(sourceRoot, exports.WORKTREE_INCLUDE_FILE);
    if (!fs.existsSync(inc))
        return [];
    // --others --ignored with ONLY this exclude file (no --exclude-standard) is
    // exactly "untracked files these patterns match". Tracked files are already
    // in the new checkout and are never listed.
    const out = await git(['ls-files', '-z', '--others', '--ignored', `--exclude-from=${inc}`], sourceRoot);
    return out.split('\0').filter(Boolean);
}
exports.DEFAULT_COPY_LIMITS = { maxFiles: 5000, maxBytes: 512 * 1024 * 1024 };
/** Copy `files` (relative) from one checkout to another. Never overwrites. */
async function copyIncludeFiles(sourceRoot, destRoot, files, limits = exports.DEFAULT_COPY_LIMITS) {
    let copied = 0;
    let skipped = 0;
    let bytes = 0;
    for (const rel of files) {
        const src = path.join(sourceRoot, rel);
        const dst = path.join(destRoot, rel);
        let st;
        try {
            st = await fs.promises.stat(src);
        }
        catch {
            continue;
        }
        if (!st.isFile())
            continue;
        if (copied >= limits.maxFiles || bytes + st.size > limits.maxBytes) {
            skipped++;
            continue;
        }
        if (fs.existsSync(dst))
            continue;
        try {
            await fs.promises.mkdir(path.dirname(dst), { recursive: true });
            await fs.promises.copyFile(src, dst);
            copied++;
            bytes += st.size;
        }
        catch {
            skipped++;
        }
    }
    return { copied, skipped, bytes };
}
async function createWorktree(o) {
    const branch = (o.branch || '').trim().replace(/^refs\/heads\//, '');
    if (!branch)
        throw new WorktreeError('A branch name is required', 'bad_branch');
    const repo = await resolveRepo(o.cwd);
    const fmt = await runGit(['check-ref-format', '--branch', branch], repo.root);
    if (fmt.code !== 0)
        throw new WorktreeError(`Not a valid branch name: ${branch}`, 'bad_branch');
    const config = readWorktreeConfig(repo.root);
    const base0 = {
        branch, repoRoot: repo.mainRoot, sourceRoot: repo.root,
        setup: config.setup, ...(config.error ? { configError: config.error } : {}),
    };
    // Idempotent: asking twice for the same branch returns the first checkout,
    // so an orchestrator retry does not fail on "already checked out".
    const entries = await listWorktrees(repo.root);
    const holder = entries.find((e) => e.branch === branch);
    if (holder) {
        if (samePath(holder.path, repo.mainRoot)) {
            throw new WorktreeError(`Branch '${branch}' is checked out in the main checkout (${repo.mainRoot}) — pick another branch name`, 'in_use');
        }
        return { ...base0, path: holder.path, base: null, createdBranch: false, reused: true, copied: 0, copySkipped: 0 };
    }
    let target;
    if (o.path) {
        target = path.resolve(o.cwd, o.path);
        if (fs.existsSync(target) && fs.readdirSync(target).length > 0) {
            throw new WorktreeError(`Folder already exists and is not empty: ${target}`, 'path_exists');
        }
    }
    else {
        target = uniqueChildPath(worktreeRootFor(repo.mainRoot, config.dir), (0, worktree_names_1.branchSlug)(branch));
    }
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const local = (await runGit(['show-ref', '--verify', '--quiet', `refs/heads/${branch}`], repo.root)).code === 0;
    let args;
    let base;
    let createdBranch;
    if (local) {
        args = ['worktree', 'add', target, branch];
        base = null;
        createdBranch = false;
    }
    else if (!o.base && await uniqueRemoteBranch(repo.root, branch)) {
        // `git worktree add <path> <name>` with no local <name> but exactly one
        // remote-tracking <remote>/<name> creates the local branch tracking it —
        // what someone typing a teammate's branch name means.
        args = ['worktree', 'add', target, branch];
        base = await uniqueRemoteBranch(repo.root, branch);
        createdBranch = true;
    }
    else {
        base = o.base?.trim() || 'HEAD';
        // --no-track: from `origin/main`, -b would make origin/main the upstream,
        // and a later plain `git push` would aim the agent's work at main.
        args = ['worktree', 'add', '--no-track', '-b', branch, target, base];
        createdBranch = true;
    }
    await git(args, repo.root);
    let copied = 0;
    let copySkipped = 0;
    try {
        const files = await listIncludeFiles(repo.root);
        const r = await copyIncludeFiles(repo.root, target, files, o.copyLimits);
        copied = r.copied;
        copySkipped = r.skipped;
    }
    catch { /* the checkout exists; a failed copy is not worth undoing it */ }
    return { ...base0, path: target, base, createdBranch, reused: false, copied, copySkipped };
}
async function uniqueRemoteBranch(root, branch) {
    const r = await runGit(['for-each-ref', '--format=%(refname:short)', `refs/remotes/*/${branch}`], root);
    const refs = r.stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    return refs.length === 1 ? refs[0] : null;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** Find the worktree a path names, from inside it or from its repository. */
async function findWorktree(target, repoHint) {
    const abs = path.resolve(target);
    const from = fs.existsSync(abs) ? abs : repoHint;
    if (!from)
        throw new WorktreeError(`No worktree at ${abs}`, 'not_found');
    const repo = await resolveRepo(from);
    const entry = (await listWorktrees(repo.mainRoot)).find((e) => samePath(e.path, abs));
    if (!entry)
        throw new WorktreeError(`No worktree at ${abs}`, 'not_found');
    if (samePath(entry.path, repo.mainRoot))
        throw new WorktreeError(`${abs} is the main checkout, not a worktree`, 'not_found');
    return { entry, mainRoot: repo.mainRoot };
}
async function removeWorktree(o) {
    const { entry, mainRoot } = await findWorktree(o.path, o.repoHint);
    const target = entry.path;
    if (!o.force && fs.existsSync(target)) {
        const n = await worktreeChanges(target);
        if (n > 0)
            throw new WorktreeError(`${n} uncommitted change(s) in ${target} — commit them, or remove with --force`, 'dirty', n);
    }
    const retries = o.retries ?? 5;
    const delay = o.retryDelayMs ?? 1000;
    let lastErr = '';
    for (let attempt = 0; attempt <= retries; attempt++) {
        // After a failed attempt the checkout may be half-deleted, which git
        // reads as dirty — cleanliness was already checked above, so retries
        // force.
        const force = o.force || attempt > 0;
        const r = await runGit(['worktree', 'remove', ...(force ? ['--force'] : []), target], mainRoot);
        if (r.code === 0) {
            lastErr = '';
            break;
        }
        lastErr = firstLine(r.stderr);
        if (attempt < retries)
            await sleep(delay * (attempt + 1));
    }
    if (lastErr) {
        // git may have dropped its record yet left a locked folder behind.
        const still = (await listWorktrees(mainRoot)).some((e) => samePath(e.path, target));
        if (still)
            throw new WorktreeError(`Could not remove ${target}: ${lastErr}`, 'busy');
    }
    if (fs.existsSync(target)) {
        try {
            await fs.promises.rm(target, { recursive: true, force: true, maxRetries: 3, retryDelay: 500 });
        }
        catch { /* leave it; git no longer tracks it */ }
    }
    await runGit(['worktree', 'prune'], mainRoot);
    let branchDeleted = false;
    let branchKept;
    if (o.deleteBranch && entry.branch) {
        const r = await runGit(['branch', '-d', entry.branch], mainRoot);
        if (r.code === 0)
            branchDeleted = true;
        else
            branchKept = firstLine(r.stderr) || 'git branch -d failed';
    }
    return { path: target, branch: entry.branch, branchDeleted, ...(branchKept ? { branchKept } : {}) };
}

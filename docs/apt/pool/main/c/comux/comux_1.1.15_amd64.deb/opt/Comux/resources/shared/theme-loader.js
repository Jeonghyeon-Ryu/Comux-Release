"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseThemeFileContent = parseThemeFileContent;
exports.loadBundledThemes = loadBundledThemes;
exports.getThemeByName = getThemeByName;
exports.getDefaultTheme = getDefaultTheme;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
/**
 * Parse a Ghostty-style theme file (key = value pairs) into a ThemeConfig.
 * Returns null if the content cannot be meaningfully parsed.
 */
function parseThemeFileContent(name, content) {
    const values = {};
    for (const rawLine of content.split('\n')) {
        const line = rawLine.trim();
        if (!line || line.startsWith('#'))
            continue;
        const eqIdx = line.indexOf('=');
        if (eqIdx === -1)
            continue;
        const key = line.slice(0, eqIdx).trim();
        const value = line.slice(eqIdx + 1).trim();
        values[key] = value;
    }
    // Parse palette entries: "palette = N=RRGGBB" or "palette = N=#RRGGBB"
    const palette = new Array(16).fill('');
    // Re-iterate to handle multiple "palette" keys
    for (const rawLine of content.split('\n')) {
        const line = rawLine.trim();
        if (!line || line.startsWith('#'))
            continue;
        const eqIdx = line.indexOf('=');
        if (eqIdx === -1)
            continue;
        const key = line.slice(0, eqIdx).trim();
        const value = line.slice(eqIdx + 1).trim();
        if (key === 'palette') {
            // Format: N=color or N=#color
            const innerEq = value.indexOf('=');
            if (innerEq !== -1) {
                const idx = parseInt(value.slice(0, innerEq).trim(), 10);
                const color = value.slice(innerEq + 1).trim();
                if (!isNaN(idx) && idx >= 0 && idx <= 15) {
                    palette[idx] = normalizeColor(color);
                }
            }
        }
    }
    // Fill missing palette entries with empty string (caller can fill defaults)
    const background = normalizeColor(values['background'] || '');
    const foreground = normalizeColor(values['foreground'] || '');
    if (!background && !foreground)
        return null;
    return {
        name,
        background: background || '#000000',
        foreground: foreground || '#ffffff',
        cursor: normalizeColor(values['cursor-color'] || values['cursor'] || foreground || '#ffffff'),
        cursorText: normalizeColor(values['cursor-text'] || ''),
        selectionBackground: normalizeColor(values['selection-background'] || ''),
        selectionForeground: normalizeColor(values['selection-foreground'] || ''),
        palette,
        fontFamily: values['font-family'] || 'Cascadia Mono',
        fontSize: parseFloat(values['font-size'] || '13') || 13,
        backgroundOpacity: parseFloat(values['background-opacity'] || '1') || 1.0,
    };
}
function normalizeColor(color) {
    if (!color)
        return '';
    const c = color.trim();
    if (c.startsWith('#'))
        return c;
    // Bare hex like 272822
    if (/^[0-9a-fA-F]{6}$/.test(c))
        return `#${c}`;
    return c;
}
/**
 * Scans resources/themes/ for Ghostty-format theme files and returns a Map
 * of theme name → ThemeConfig.
 */
function getThemesDir() {
    try {
        const { app } = require('electron');
        if (app.isPackaged) {
            return path.join(process.resourcesPath, 'themes');
        }
    }
    catch {
        // Not running in Electron (e.g., during tests)
    }
    return path.join(__dirname, '../../resources/themes');
}
function scanThemesDir(dir) {
    const result = new Map();
    let entries;
    try {
        entries = fs.readdirSync(dir);
    }
    catch {
        return result;
    }
    for (const entry of entries) {
        const filePath = path.join(dir, entry);
        try {
            if (!fs.statSync(filePath).isFile())
                continue;
        }
        catch {
            continue;
        }
        const themeName = path.parse(entry).name;
        try {
            const content = fs.readFileSync(filePath, 'utf-8');
            const theme = parseThemeFileContent(themeName, content);
            if (theme)
                result.set(themeName, theme);
        }
        catch {
            continue;
        }
    }
    return result;
}
function loadBundledThemes() {
    // Primary: resolved path (resourcesPath when packaged, ../../resources/themes in dev)
    const primary = scanThemesDir(getThemesDir());
    if (primary.size > 0)
        return primary;
    // Fallback: always try the source-relative path in case resourcesPath resolution fails
    return scanThemesDir(path.join(__dirname, '../../resources/themes'));
}
/**
 * Resolve a theme by name. Tries bundled themes first, then falls back to
 * the built-in Monokai default. Name lookup is case-insensitive.
 */
function getThemeByName(name) {
    if (!name)
        return getDefaultTheme();
    const bundled = loadBundledThemes();
    // Exact match
    const direct = bundled.get(name);
    if (direct)
        return direct;
    // Case-insensitive match
    const target = name.toLowerCase();
    for (const [key, theme] of bundled) {
        if (key.toLowerCase() === target)
            return theme;
    }
    return getDefaultTheme();
}
/**
 * Returns the built-in Monokai default theme.
 */
function getDefaultTheme() {
    return {
        name: 'Monokai',
        background: '#272822',
        foreground: '#fdfff1',
        cursor: '#c0c1b5',
        cursorText: '',
        selectionBackground: '#57584f',
        selectionForeground: '#fdfff1',
        palette: [
            '#272822', // 0  black
            '#f92672', // 1  red
            '#a6e22e', // 2  green
            '#f4bf75', // 3  yellow
            '#66d9ef', // 4  blue
            '#ae81ff', // 5  magenta
            '#a1efe4', // 6  cyan
            '#f8f8f2', // 7  white
            '#75715e', // 8  bright black
            '#f92672', // 9  bright red
            '#a6e22e', // 10 bright green
            '#f4bf75', // 11 bright yellow
            '#66d9ef', // 12 bright blue
            '#ae81ff', // 13 bright magenta
            '#a1efe4', // 14 bright cyan
            '#f9f8f5', // 15 bright white
        ],
        fontFamily: 'Cascadia Mono',
        fontSize: 13,
        backgroundOpacity: 1.0,
    };
}

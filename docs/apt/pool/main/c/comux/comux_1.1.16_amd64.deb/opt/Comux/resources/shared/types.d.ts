import type { TokenBuckets } from './token-buckets';
export type { TokenBuckets };
export type WorkspaceId = `ws-${string}`;
export type PaneId = `pane-${string}`;
export type SurfaceId = `surf-${string}`;
export type WindowId = `win-${string}`;
export type SplitNode = {
    type: 'leaf';
    paneId: PaneId;
    surfaces: SurfaceRef[];
    activeSurfaceIndex: number;
} | {
    type: 'branch';
    direction: 'horizontal' | 'vertical';
    ratio: number;
    children: [SplitNode, SplitNode];
};
export type SurfaceType = 'terminal' | 'browser' | 'markdown' | 'diff' | 'dashboard';
export interface SurfaceRef {
    id: SurfaceId;
    type: SurfaceType;
    customTitle?: string;
    shell?: string;
    /** Per-surface color scheme override (bundled theme name or user-defined scheme name). */
    colorScheme?: string;
}
export interface WorkspaceInfo {
    id: WorkspaceId;
    title: string;
    customColor?: string;
    pinned: boolean;
    shell: string;
    splitTree: SplitNode;
    unreadCount: number;
    gitBranch?: string;
    gitDirty?: boolean;
    cwd?: string;
    prNumber?: number;
    prStatus?: 'open' | 'merged' | 'closed';
    prLabel?: string;
    ports?: number[];
    notificationText?: string;
    shellState?: 'idle' | 'running' | 'interrupted';
    browserUrl?: string;
    /** Whether the browser panel is open for this workspace (per-workspace visibility). */
    browserPanelOpen?: boolean;
    /** Active file shown in the code panel for this workspace (per-workspace, like browserUrl). */
    codeFilePath?: string;
    /** All files open as tabs in the code panel for this workspace; codeFilePath is the active one. */
    codeOpenFiles?: string[];
    /** Whether the code panel is open for this workspace (per-workspace visibility). */
    codePanelOpen?: boolean;
    /**
     * Set when comux created this workspace on its own git worktree. Distinct
     * from `cwd`, which follows wherever the shell cd's — this is the checkout
     * the workspace OWNS, offered for removal when the workspace closes.
     */
    worktree?: WorkspaceWorktree;
}
/** The git worktree a workspace was created on (shared/worktree.ts). */
export interface WorkspaceWorktree {
    /** Absolute path of the worktree checkout. */
    path: string;
    /** Branch checked out in it. */
    branch: string;
    /** Main checkout of the repository the worktree hangs off. */
    repoRoot: string;
    /** Ref the branch was created from, when comux created the branch. */
    base?: string;
}
export interface SurfaceInfo {
    id: SurfaceId;
    type: SurfaceType;
    title?: string;
}
/** Claude-tier status of a surface, owned by the main-process state machine.
 *  'idle' = Claude is sitting at its input prompt (launched but no turn in
 *  flight); 'done' = a turn actually completed; 'unknown' = no live Claude
 *  state (fall back to the surface's shell state). */
export type ClaudeSurfaceStatus = 'working' | 'waiting' | 'done' | 'idle' | 'unknown';
export type ShellReportState = 'idle' | 'running' | 'interrupted';
/** One subagent's progress as parsed from Claude Code's agent table. */
export interface AgentActivity {
    name: string;
    toolUses: number;
    tokens: string;
    done: boolean;
}
/** Snapshot broadcast on CLAUDE_ACTIVITY (and returned by the snapshot IPC). */
export interface SurfaceActivitySnapshot {
    status: ClaudeSurfaceStatus;
    /** Last shell state reported by this surface's shell integration, if any. */
    shellState: ShellReportState | null;
    /** True once this surface has shown any Claude-tier evidence (vs a plain shell). */
    claude: boolean;
    agents: AgentActivity[];
    activeSkill: string | null;
    lastTool: string | null;
    lastUpdate: number;
}
export interface PaneInfo {
    id: PaneId;
    surfaces: SurfaceInfo[];
    activeSurfaceId: SurfaceId;
}
export interface WindowInfo {
    id: WindowId;
    bounds: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    workspaceIds: WorkspaceId[];
    activeWorkspaceId: WorkspaceId;
}
export interface ThemeConfig {
    name: string;
    background: string;
    foreground: string;
    cursor: string;
    cursorText: string;
    selectionBackground: string;
    selectionForeground: string;
    palette: string[];
    fontFamily: string;
    fontSize: number;
    backgroundOpacity: number;
}
export interface NotificationInfo {
    id: string;
    surfaceId: SurfaceId;
    workspaceId: WorkspaceId;
    paneId?: PaneId;
    text: string;
    title?: string;
    timestamp: number;
    read: boolean;
}
export type AgentId = `agent-${string}`;
export interface AgentInfo {
    agentId: AgentId;
    surfaceId: SurfaceId;
    paneId: PaneId;
    workspaceId: WorkspaceId;
    label: string;
    cmd: string;
    status: 'spawning' | 'running' | 'exited';
    exitCode?: number;
    pid?: number;
    spawnTime: number;
}
export interface AgentSpawnParams {
    cmd: string;
    label: string;
    cwd?: string;
    env?: Record<string, string>;
    paneId?: PaneId;
    workspaceId?: WorkspaceId;
}
export interface AgentBatchParams {
    agents: AgentSpawnParams[];
    strategy: 'distribute' | 'stack' | 'split';
    workspaceId?: WorkspaceId;
}
export interface CDPSnapshot {
    tree: string;
    refCount: number;
}
export interface ShellInfo {
    name: string;
    command: string;
    args: string[];
    available: boolean;
}
export interface SidebarMetadata {
    gitBranch?: string;
    gitDirty?: boolean;
    cwd?: string;
    prNumber?: number;
    prStatus?: string;
    prLabel?: string;
    ports?: number[];
    notificationText?: string;
    shellState?: 'idle' | 'running' | 'interrupted';
    statusEntries?: Record<string, string>;
    progress?: {
        value: number;
        label?: string;
    };
    logs?: Array<{
        level: string;
        message: string;
        timestamp: number;
    }>;
}
export declare const IPC_CHANNELS: {
    readonly PTY_CREATE: "pty:create";
    readonly PTY_WRITE: "pty:write";
    readonly PTY_RESIZE: "pty:resize";
    readonly PTY_KILL: "pty:kill";
    readonly PTY_HAS: "pty:has";
    readonly PTY_DATA: "pty:data";
    readonly PTY_EXIT: "pty:exit";
    readonly WORKSPACE_CREATE: "workspace:create";
    readonly WORKSPACE_CLOSE: "workspace:close";
    readonly WORKSPACE_SELECT: "workspace:select";
    readonly WORKSPACE_RENAME: "workspace:rename";
    readonly WORKSPACE_LIST: "workspace:list";
    readonly WORKSPACE_REORDER: "workspace:reorder";
    readonly WORKSPACE_MOVE_TO_WINDOW: "workspace:moveToWindow";
    readonly SURFACE_CREATE: "surface:create";
    readonly SURFACE_CLOSE: "surface:close";
    readonly SURFACE_FOCUS: "surface:focus";
    readonly SURFACE_LIST: "surface:list";
    readonly SURFACE_READ_TEXT: "surface:readText";
    readonly SURFACE_SEND_TEXT: "surface:sendText";
    readonly SURFACE_SEND_KEY: "surface:sendKey";
    readonly SURFACE_TRIGGER_FLASH: "surface:triggerFlash";
    readonly PANE_SPLIT: "pane:split";
    readonly PANE_CLOSE: "pane:close";
    readonly PANE_FOCUS: "pane:focus";
    readonly PANE_ZOOM: "pane:zoom";
    readonly PANE_LIST: "pane:list";
    readonly NOTIFICATION_FIRE: "notification:fire";
    readonly NOTIFICATION_LIST: "notification:list";
    readonly NOTIFICATION_CLEAR: "notification:clear";
    readonly NOTIFICATION_JUMP: "notification:jump";
    readonly SETTINGS_GET: "settings:get";
    readonly SETTINGS_SET: "settings:set";
    readonly SETTINGS_CHANGED: "settings:changed";
    readonly WINDOW_CREATE: "window:create";
    readonly WINDOW_CLOSE: "window:close";
    readonly WINDOW_FOCUS: "window:focus";
    readonly WINDOW_LIST: "window:list";
    readonly WINDOW_MINIMIZE: "window:minimize";
    readonly WINDOW_MAXIMIZE: "window:maximize";
    readonly WINDOW_IS_MAXIMIZED: "window:isMaximized";
    readonly CONFIG_GET_THEME: "config:getTheme";
    readonly CONFIG_GET_THEME_LIST: "config:getThemeList";
    readonly CONFIG_IMPORT_WT: "config:importWindowsTerminal";
    readonly CONFIG_IMPORT_GHOSTTY: "config:importGhostty";
    readonly CONFIG_GET_USER_CONFIG: "config:getUserConfig";
    readonly CONFIG_RELOAD_USER_CONFIG: "config:reloadUserConfig";
    readonly CONFIG_USER_CONFIG_UPDATED: "config:userConfigUpdated";
    readonly SYSTEM_GET_SHELLS: "system:getShells";
    readonly SYSTEM_OPEN_EXTERNAL: "system:openExternal";
    readonly SYSTEM_SELECT_DIRECTORY: "system:selectDirectory";
    readonly SYSTEM_REPORT_ERROR: "system:reportError";
    readonly METADATA_UPDATE: "metadata:update";
    readonly AGENT_SPAWN: "agent:spawn";
    readonly AGENT_SPAWN_BATCH: "agent:spawn-batch";
    readonly AGENT_STATUS: "agent:status";
    readonly AGENT_LIST: "agent:list";
    readonly AGENT_KILL: "agent:kill";
    readonly AGENT_UPDATE: "agent:update";
    readonly CDP_ATTACH: "cdp:attach";
    readonly BROWSER_PICK: "browser:pick";
    readonly CDP_DETACH: "cdp:detach";
    readonly CDP_NAVIGATE: "cdp:navigate";
    readonly CDP_SNAPSHOT: "cdp:snapshot";
    readonly CDP_CLICK: "cdp:click";
    readonly CDP_TYPE: "cdp:type";
    readonly CDP_FILL: "cdp:fill";
    readonly CDP_SCREENSHOT: "cdp:screenshot";
    readonly CDP_GET_TEXT: "cdp:get-text";
    readonly CDP_EVAL: "cdp:eval";
    readonly CDP_WAIT: "cdp:wait";
    readonly BROWSER_CLEAR_CACHE: "browser:clear-cache";
    readonly GET_ACTIVE_WORKSPACE: "get-active-workspace";
    readonly HOOK_EVENT: "hook:event";
    readonly CLAUDE_ACTIVITY: "claude:activity";
    readonly CLAUDE_ACTIVITY_SNAPSHOT: "claude:activity-snapshot";
    readonly SESSION_LOAD_AUTO: "session:load-auto";
    readonly SESSION_SAVE_NOW: "session:save-now";
    readonly DIFF_GET_FILES: "diff:get-files";
    readonly DIFF_GET_DIFF: "diff:get-diff";
    readonly DIFF_UPDATE: "diff:update";
    readonly FILE_LIST_DIR: "file:list-dir";
    readonly FILE_READ: "file:read";
    readonly FILE_WRITE: "file:write";
    readonly FILE_SEARCH: "file:search";
    readonly FILE_CREATE: "file:create";
    readonly FILE_MKDIR: "file:mkdir";
    readonly FILE_RENAME: "file:rename";
    readonly FILE_MOVE: "file:move";
    readonly FILE_COPY: "file:copy";
    readonly FILE_TRASH: "file:trash";
    readonly FILE_REVEAL: "file:reveal";
    readonly FILE_WATCH_START: "file:watch-start";
    readonly FILE_WATCH_STOP: "file:watch-stop";
    readonly FILE_CHANGED: "file:changed";
    readonly GIT_FILE_STATUS: "git:file-status";
    readonly WORKTREE_RPC: "worktree:rpc";
    readonly GIT_AI_RPC: "git-ai:rpc";
    readonly ORCHESTRATION_UPDATE: "orchestration:update";
    readonly ORCHESTRATION_CLEAR: "orchestration:clear";
    readonly UPDATE_AVAILABLE: "update:available";
    readonly UPDATE_GET_LATEST: "update:get-latest";
    readonly UPDATE_OPEN_RELEASE: "update:open-release";
    readonly UPDATE_INSTALL: "update:install";
    readonly UPDATE_PROGRESS: "update:progress";
    readonly UPDATE_PROMPT: "update:prompt";
    readonly UPDATE_LAST_FAILURE: "update:last-failure";
    readonly REST_GET_CONFIG: "rest:get-config";
    readonly REST_SET_CONFIG: "rest:set-config";
    readonly REST_GET_STATUS: "rest:get-status";
    readonly REST_REGEN_TOKEN: "rest:regenerate-token";
    readonly REST_GET_LOGS: "rest:get-logs";
    readonly REST_CLEAR_LOGS: "rest:clear-logs";
    readonly ATTENTION_GET_CONFIG: "attention:get-config";
    readonly ATTENTION_SET_CONFIG: "attention:set-config";
    readonly USAGE_GET: "usage:get";
    readonly USAGE_UPDATE: "usage:update";
    readonly USAGE_LIMITS_GET: "usage:limits-get";
    readonly USAGE_LIMITS_UPDATE: "usage:limits-update";
    readonly SYSTEM_METRICS: "system:metrics";
    readonly LLM_TOKENS_UPDATE: "llm:tokens:update";
    readonly LLM_METER_GET: "llm:meter:get";
    readonly LLM_METER_SET_ENABLED: "llm:meter:set-enabled";
    readonly TOOL_USAGE_GET: "tool-usage:get";
    readonly TOOL_USAGE_UPDATE: "tool-usage:update";
    readonly CODE_HOVER: "code:hover";
    readonly CODE_DEFINITION: "code:definition";
    readonly CODE_DID_OPEN: "code:did-open";
    readonly CODE_DID_CHANGE: "code:did-change";
    readonly CODE_DID_CLOSE: "code:did-close";
    readonly CODE_STATUS: "code:status";
    readonly CORE_COMMAND: "core:command";
    readonly CORE_STATE_UPDATE: "core:state-update";
    readonly CORE_REQUEST_STATE: "core:request-state";
};
/** LSP-style position: 0-based line and character (UTF-16 code units). */
export interface CodePosition {
    line: number;
    character: number;
}
/** A source range, LSP-style (both ends 0-based). */
export interface CodeRange {
    start: CodePosition;
    end: CodePosition;
}
/** Hover result: the declaration/type text plus the range it applies to. */
export interface CodeHoverResult {
    /** Plain-text declaration, e.g. `const assignments: string[]`. */
    contents: string;
    /** The identifier range the hover describes, for underline/highlight. */
    range?: CodeRange;
}
/** Go-to-definition result: where the symbol under the cursor is declared. */
export interface CodeDefinitionResult {
    /** Absolute path of the file holding the definition. */
    targetPath: string;
    /** 0-based position of the definition within that file. */
    line: number;
    character: number;
}
/**
 * Per-language availability, pushed to the renderer so the UI can surface a
 * subtle "installing"/"unavailable" hint. Never blocks the editor — a language
 * that is `unavailable` simply has hover/definition inactive.
 */
export interface CodeStatus {
    /** 'typescript' | 'python' | 'java'. */
    language: string;
    state: 'installing' | 'ready' | 'unavailable';
    /** Optional human-readable detail (e.g. why it's unavailable). */
    message?: string;
}
/** Real Claude Code token usage, tallied from ~/.claude transcript logs. */
export interface TokenUsage {
    /** Tokens used today (local date). */
    today: TokenBuckets;
    /** Tokens in the active session — its main transcript AND the subagent
     *  transcripts spawned under it (they live in a directory named for the
     *  session id, so they attribute back to the conversation that ran them). */
    session: TokenBuckets;
    /** All-time tokens across every project/session. */
    total: TokenBuckets;
    /** When this snapshot was computed (ms). */
    updatedAt: number;
}
/** One rate-limit window from the Anthropic OAuth usage endpoint. */
export interface UsageLimitWindow {
    /** Percent of the window's quota consumed (0–100). */
    utilization: number;
    /** When the window resets (ms epoch), or null if not reported. */
    resetsAt: number | null;
}
/**
 * Subscription usage limits — the same data Claude Code's /usage shows.
 * `available` is false when there are no OAuth credentials (API-key billing),
 * the token is expired, or the endpoint failed; consumers then fall back to
 * the local transcript tallies only.
 */
export interface UsageLimits {
    available: boolean;
    /** Why limits are unavailable (for tooltips/logging). */
    reason?: 'no-oauth' | 'token-expired' | 'http-error' | 'rate-limited';
    /** Current 5-hour session block. */
    fiveHour: UsageLimitWindow | null;
    /** Current 7-day window (all models). */
    sevenDay: UsageLimitWindow | null;
    /** Current 7-day window for Opus, when the plan reports one. */
    sevenDayOpus: UsageLimitWindow | null;
    /** Subscription tier from the credentials file (pro/max/team/…), if known. */
    subscriptionType: string | null;
    updatedAt: number;
}
/** provider key → upstream origin override (e.g. a local sLLM under 'openai'). */
export type LlmUpstreamMap = Record<string, string>;
export interface LlmMeterConfig {
    /** ON by default (a missing config enables it; only an explicit false, i.e.
     *  the user toggled it off, disables it). Redirects each terminal's LLM base
     *  URL through comux's local proxy tap; toggle from the Fleet dashboard. */
    enabled: boolean;
    /** Optional upstream overrides for custom/local endpoints. */
    upstreams?: LlmUpstreamMap;
    /** Inject stream_options.include_usage into streaming OpenAI requests so their
     *  token usage is captured. Default true (undefined ⇒ on). */
    injectStreamUsage?: boolean;
}
export interface LlmProviderTotals {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
    requests: number;
}
export interface LlmSurfaceTotals extends LlmProviderTotals {
    provider: string;
    model: string | null;
    lastAt: number;
}
/** Live token totals aggregated from the proxy tap, broadcast to renderers. */
export interface LlmMeterSnapshot {
    enabled: boolean;
    total: LlmProviderTotals;
    byProvider: Record<string, LlmProviderTotals>;
    bySurface: Record<string, LlmSurfaceTotals>;
    updatedAt: number;
}
export interface ToolUsageEntry {
    tool: string;
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
    /** Every token the model processed: input + cacheRead + cacheWrite + output.
     *  cacheRead is INCLUDED — a cache hit is cheaper, not absent. */
    total: number;
    requests: number;
    /** False when this tool leaves nothing to measure. Reported rather than
     *  omitted, because a missing row reads as "unused" when the truth is
     *  "unmeasurable" — and those are very different claims. */
    available: boolean;
    /** Why measurement is impossible, when `available` is false. */
    reason?: 'no-log-dir' | 'no-token-logs';
    updatedAt: number;
}
export interface ToolUsageSnapshot {
    byTool: Record<string, ToolUsageEntry>;
    updatedAt: number;
}
/** Snapshot of host CPU/RAM usage, polled in main and pushed to the renderer. */
export interface SystemMetrics {
    /** Overall CPU utilization, 0–100 (%). */
    cpu: number;
    /** RAM utilization, 0–100 (%). */
    mem: number;
    /** Used RAM in bytes. */
    memUsed: number;
    /** Total RAM in bytes. */
    memTotal: number;
}
/**
 * Config for the external REST API server (HTTP in the main process) that lets
 * outside clients inject chat/commands into a specific terminal. Persisted to
 * appData (rest-api.json) and read by the main process. The token authenticates
 * every request (Bearer header); it is auto-generated on first run.
 */
export interface RestApiConfig {
    enabled: boolean;
    host: string;
    port: number;
    token: string;
    /** User-defined dynamic endpoints, each reachable at POST /api/<name>. */
    endpoints: RestEndpoint[];
}
/** Payload shape for an outgoing Attention Router webhook. */
export type WebhookFormat = 'discord' | 'slack' | 'ntfy' | 'raw';
/**
 * Attention Router config. When an agent pauses at a permission prompt or
 * finishes a turn, route that moment to an OS toast and/or a webhook so you can
 * step away from a fleet of agents without one silently blocking.
 */
export interface AttentionConfig {
    enabled: boolean;
    /** Fire when an agent pauses waiting for input (permission/confirm prompt). */
    onWaiting: boolean;
    /** Fire when an agent finishes a turn (isDone rising edge). */
    onDone: boolean;
    /** Suppress alerts while the comux window is focused (you're already watching). */
    onlyWhenUnfocused: boolean;
    /** Show a native OS toast (click focuses + jumps to the surface). */
    toast: boolean;
    /** POST to this URL on each alert (empty = disabled). */
    webhookUrl: string;
    /** How to shape the webhook JSON body for the target service. */
    webhookFormat: WebhookFormat;
}
/**
 * Permission/automation mode applied to the auto-launched agent session. The
 * three levels map to each CLI's nearest equivalent (see buildAgentCommand):
 * - plan   → read-only / manual approval
 * - accept → auto-accept edits (sandboxed)
 * - auto   → full auto / bypass approvals
 */
export type RestEndpointMode = 'plan' | 'accept' | 'auto';
/** Which agent CLI the endpoint launches. */
export type RestEndpointAgent = 'claude' | 'codex' | 'gemini';
/**
 * A user-defined remote endpoint. POSTing `{ "text": "..." }` to
 * `/api/<name>` composes the configured prompt with the input and sends it to
 * the chosen agent — launching a fresh agent session in `cwd` with `mode` if
 * one isn't already running for this endpoint.
 */
export interface RestEndpoint {
    /** Stable internal id (ep-<uuid>). */
    id: string;
    /** URL slug — the endpoint answers at POST /api/<name>. */
    name: string;
    /** Which agent CLI to run (claude / codex / gemini). */
    agent: RestEndpointAgent;
    /** Prompt template. `{input}` is replaced with the request's text; if the
     *  placeholder is absent, the input is appended after the prompt. */
    prompt: string;
    /** Working directory the agent is launched in when auto-starting. */
    cwd: string;
    /** Permission/automation mode for the auto-launched session. */
    mode: RestEndpointMode;
}
/**
 * One recorded REST API usage event, shown in the titlebar "API logs" dialog.
 * Persisted to appData (rest-api-logs.json), capped to a rolling window.
 */
export interface RestApiLogEntry {
    /** Stable id (log-<uuid>). */
    id: string;
    /** When the request arrived (epoch ms). */
    timestamp: number;
    /** Client IP (X-Forwarded-For first hop when behind a tunnel, else socket). */
    ip: string;
    /** Which API was used: a dynamic endpoint name, 'terminals' for the generic
     *  input endpoint, or '—' for an unauthorized attempt. */
    api: string;
    /** HTTP method. */
    method: string;
    /** Request path. */
    path: string;
    /** The input text the client sent (truncated for storage). */
    input: string;
    /** Estimated token count of the text actually transmitted to the agent. */
    tokens: number;
    /** HTTP status returned. */
    status: number;
    /** Target terminal surface, when the call injected into one. */
    surfaceId?: string;
}
/** A single entry returned by FILE_LIST_DIR — one file or directory. */
export interface DirEntry {
    name: string;
    path: string;
    isDir: boolean;
}
/** Result of a file-tree mutation (create/rename/move/copy/trash/…). */
export type FsOpResult = {
    ok: true;
    path?: string;
} | {
    ok: false;
    error: string;
};
/** Raw per-file git status. `code` is the 2-char XY from `git status --porcelain`. */
export interface GitFileStatus {
    path: string;
    code: string;
}
/** Result of GIT_FILE_STATUS. */
export type GitStatusResult = {
    statuses: GitFileStatus[];
    error?: string;
};
/** Coarse decoration letter the renderer derives from an XY status code. */
export type GitDeco = 'M' | 'A' | 'U' | 'D' | 'R';
/** Payload pushed on FILE_CHANGED when a watched tree changes. */
export interface FileChangedEvent {
    root: string;
    paths: string[];
    /** The watched root vanished (or the watcher errored) — the watch is dead;
     *  this is the final event for it. */
    rootGone?: boolean;
}
export type OrchAgentStatus = 'pending' | 'running' | 'exited' | 'failed';
export type OrchWaveStatus = 'pending' | 'running' | 'complete' | 'failed';
export type OrchRunStatus = 'pending' | 'running' | 'complete' | 'failed';
export interface OrchestrationAgent {
    id: string;
    label: string;
    subtask?: string;
    files?: string[];
    excludeFiles?: string[];
    paneId?: string | null;
    surfaceId?: string | null;
    status: OrchAgentStatus;
    exitCode?: number | null;
    toolUses?: number;
    resultFile?: string;
    startedAt?: string | null;
    finishedAt?: string | null;
    lastTool?: string;
    /** Plan ids this agent waits for (orch.js schedules by these, not by wave). */
    dependsOn?: string[];
    /** CLI it runs on (claude, codex, gemini, opencode) and why it was chosen. */
    cli?: string;
    category?: string | null;
    /** Worktree mode: its branch, and how merging it into the main checkout went. */
    branch?: string;
    mergeStatus?: 'merged' | 'empty' | 'conflict';
    failReason?: string;
}
export interface OrchestrationWave {
    index: number;
    status: OrchWaveStatus;
    blockedBy?: number[];
    agents: OrchestrationAgent[];
}
export interface OrchestrationReviewer {
    status: OrchRunStatus | 'ready';
    agentId?: string | null;
    reportFile?: string;
    mode?: 'session' | 'agent';
    cli?: string | null;
    verdict?: string;
}
export interface OrchestrationState {
    id: string;
    task: string;
    status: OrchRunStatus;
    startedAt: string;
    finishedAt?: string;
    cwd?: string;
    workspaceId?: string | null;
    dashboardSurfaceId?: string | null;
    useWorktrees?: boolean;
    waves: OrchestrationWave[];
    reviewer?: OrchestrationReviewer;
    _orchDir?: string;
}

/**
 * Keys pressed inside a browser <webview> that comux has to decide itself.
 *
 * A key the page does not consume does not just die: Electron hands a guest's
 * unhandled keys to its EMBEDDER, and on Windows/Linux the embedder's window
 * runs them against the default application menu. Those menu items act on the
 * BrowserWindow, not on the page:
 *
 *   Ctrl+W          Window > Close  → BrowserWindow.close() — with one window,
 *                                     that quits comux and every shell in it
 *   Ctrl+R          View > Reload   → the whole comux UI reloads
 *   Ctrl+Shift+R    Force Reload    → same, ignoring cache
 *
 * (Verified against Electron 33's role table: `close` and `reload`/`forcereload`
 * are all `windowMethod`s.) The host renderer never sees these keys, because
 * webview input does not bubble into the host DOM, so its shortcut handler
 * cannot preventDefault them the way it does for a terminal.
 *
 * `before-input-event` runs before both the page and the menu, so this decides
 * every such key there. Pure — no electron import — so it is unit-tested.
 */
/** The fields of Electron's `Input` this reads. */
export interface WebviewKeyInput {
    type: string;
    key: string;
    code?: string;
    control: boolean;
    shift: boolean;
    alt: boolean;
    meta: boolean;
    isAutoRepeat?: boolean;
}
export type WebviewKeyRoute = 
/** Swallow it and replay it as a keydown on the host document, where
 *  useKeyboardShortcuts handles it like any other comux shortcut. */
{
    action: 'host';
    key: string;
    ctrlKey: boolean;
    altKey: boolean;
}
/** Swallow it and reload the page itself — what a browser does. */
 | {
    action: 'reload';
    ignoreCache: boolean;
}
/** Swallow it and do nothing (a held key's auto-repeat). */
 | {
    action: 'swallow';
}
/** Not ours: leave it to the page. */
 | null;
export declare function routeWebviewKey(input: WebviewKeyInput): WebviewKeyRoute;

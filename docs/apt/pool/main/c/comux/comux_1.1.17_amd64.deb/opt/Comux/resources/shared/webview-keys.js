"use strict";
/**
 * Keys pressed inside a browser <webview> that comux has to decide itself.
 *
 * A key the page does not consume does not just die: Electron hands a guest's
 * unhandled keys to its EMBEDDER, and on Windows/Linux the embedder's window
 * runs them against the default application menu. Those menu items act on the
 * BrowserWindow, not on the page:
 *
 *   Ctrl+W          Window > Close  → BrowserWindow.close() — with one window,
 *                                     that quits comux and every shell in it
 *   Ctrl+R          View > Reload   → the whole comux UI reloads
 *   Ctrl+Shift+R    Force Reload    → same, ignoring cache
 *
 * (Verified against Electron 33's role table: `close` and `reload`/`forcereload`
 * are all `windowMethod`s.) The host renderer never sees these keys, because
 * webview input does not bubble into the host DOM, so its shortcut handler
 * cannot preventDefault them the way it does for a terminal.
 *
 * `before-input-event` runs before both the page and the menu, so this decides
 * every such key there. Pure — no electron import — so it is unit-tested.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.routeWebviewKey = routeWebviewKey;
/**
 * Whether the key is `letter`, as the menu accelerator would see it.
 *
 * Accelerators match the virtual-key code, so Ctrl+W fires on a Korean or
 * Cyrillic layout too, where `key` is the layout's own character (or "Process"
 * under an IME). Fall back to the physical key then — but never when the
 * layout produced a different LATIN letter: AZERTY's physical KeyW is "z", and
 * swallowing that would take Ctrl+Z (undo) away from French users.
 */
function isLetter(input, letter) {
    const key = input.key.toLowerCase();
    if (key === letter)
        return true;
    return input.code === `Key${letter.toUpperCase()}` && !/^[a-z]$/.test(key);
}
function routeWebviewKey(input) {
    // Real OS key presses arrive as 'rawKeyDown' (Chromium's RawKeyDown), not
    // 'keyDown' — accept both or everything gets filtered out.
    if (input.type !== 'keyDown' && input.type !== 'rawKeyDown')
        return null;
    if (input.meta)
        return null;
    const { control, shift, alt } = input;
    // Alt+Arrow moves pane focus, and must work while focus is in a page.
    if (alt && !control && !shift && input.key.startsWith('Arrow')) {
        return { action: 'host', key: input.key, ctrlKey: false, altKey: true };
    }
    // Ctrl+Alt is AltGr on Windows — a character, not a shortcut.
    if (!control || alt)
        return null;
    // Ctrl+W: comux's close-tab, which useKeyboardShortcuts aims at the browser
    // the focus is in. Auto-repeat must still be swallowed — letting it through
    // would reach the menu and close the window after all.
    if (!shift && isLetter(input, 'w')) {
        return input.isAutoRepeat ? { action: 'swallow' } : { action: 'host', key: 'w', ctrlKey: true, altKey: false };
    }
    // Ctrl+R / Ctrl+Shift+R: reload the PAGE, as in any browser.
    if (isLetter(input, 'r')) {
        return input.isAutoRepeat ? { action: 'swallow' } : { action: 'reload', ignoreCache: shift };
    }
    return null;
}

"use strict";
/**
 * Agent resume — bring Claude Code conversations back after comux restarts.
 *
 * comux restores the layout, each terminal's scrollback and its cwd, but PTYs die
 * on quit, so a terminal that was running Claude came back as a bare prompt and
 * the conversation was gone unless the user remembered `claude --resume`. This
 * module records WHICH Claude session each terminal holds, so the host can type
 * `claude --resume <id>` into the respawned shell.
 *
 * Where the facts come from:
 *  - The session id rides on every Claude Code hook (`session_id` in the stdin
 *    JSON; comux-hook.js forwards it as `sessionId`). The latest one wins, which
 *    also follows `/clear` and `/resume` inside Claude once the next hook fires.
 *  - The session is OVER when the shell reports it owns the terminal again
 *    (`idle`/`interrupted` from the prompt hook). The shell cannot draw a prompt
 *    while Claude holds the console, so that report is the exit.
 *
 * Two rules that are easy to break:
 *  - `freeze()` before the host kills its PTYs on quit. Every kill fires an exit
 *    that would `forget()` the surface, and the quit-time save lands AFTER the
 *    kill — without the freeze the one save that matters would hold nothing.
 *  - `arm()` marks a resumed entry `launching`: the respawned shell's FIRST
 *    prompt reports `idle` too, possibly after the command was typed, and that
 *    must not read as "Claude exited". The `running` report for the typed
 *    command (PSReadLine's Enter handler) ends the launch window.
 *
 * Pure and electron-free; the GUI host wires it in src/main/agent-resume.ts.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentSessionTracker = void 0;
exports.isValidSessionId = isValidSessionId;
exports.buildResumeCommand = buildResumeCommand;
exports.sanitizeSessions = sanitizeSessions;
exports.collectSurfaceIds = collectSurfaceIds;
/** Ids are typed into a shell, so only plain token characters are accepted —
 *  never quoting, spaces or shell metacharacters. Claude's ids are UUIDs. */
const SESSION_ID_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{7,127}$/;
/** Permission mode → the flag that starts Claude in it. 'default' needs none;
 *  an unknown mode is dropped rather than passed through to the command line. */
const PERMISSION_FLAGS = {
    bypassPermissions: '--dangerously-skip-permissions',
    acceptEdits: '--permission-mode acceptEdits',
    plan: '--permission-mode plan',
};
function isValidSessionId(id) {
    return typeof id === 'string' && SESSION_ID_RE.test(id);
}
/**
 * The command line that reopens a session. The same text works in PowerShell,
 * cmd and POSIX shells: it holds no quotes and the id is validated above.
 */
function buildResumeCommand(s) {
    if (s.agent !== 'claude' || !isValidSessionId(s.sessionId))
        return null;
    const flag = s.permissionMode ? PERMISSION_FLAGS[s.permissionMode] : undefined;
    return ['claude', flag, '--resume', s.sessionId].filter(Boolean).join(' ');
}
/** Validate a `surfaceAgents` map read back from disk; drops anything malformed. */
function sanitizeSessions(raw) {
    const out = {};
    if (!raw || typeof raw !== 'object')
        return out;
    for (const [surfaceId, v] of Object.entries(raw)) {
        if (!v || typeof v !== 'object')
            continue;
        const e = v;
        if (e.agent !== 'claude' || !isValidSessionId(e.sessionId))
            continue;
        const s = { agent: 'claude', sessionId: e.sessionId };
        if (typeof e.transcriptPath === 'string' && e.transcriptPath)
            s.transcriptPath = e.transcriptPath;
        if (typeof e.permissionMode === 'string' && e.permissionMode)
            s.permissionMode = e.permissionMode;
        out[surfaceId] = s;
    }
    return out;
}
/** Every surface id in a (serialized) split tree. */
function collectSurfaceIds(node, into = new Set()) {
    if (!node || typeof node !== 'object')
        return into;
    const n = node;
    if (n.type === 'leaf' && Array.isArray(n.surfaces)) {
        for (const s of n.surfaces)
            if (typeof s?.id === 'string')
                into.add(s.id);
    }
    else if (Array.isArray(n.children)) {
        for (const c of n.children)
            collectSurfaceIds(c, into);
    }
    return into;
}
class AgentSessionTracker {
    entries = new Map();
    frozen = false;
    /** A Claude Code hook arrived from this surface. */
    noteHook(p) {
        if (this.frozen || !p?.surfaceId || !isValidSessionId(p.sessionId))
            return;
        const prev = this.entries.get(p.surfaceId);
        const same = prev?.sessionId === p.sessionId;
        const entry = { agent: 'claude', sessionId: p.sessionId, launching: false };
        const transcriptPath = p.transcriptPath || (same ? prev?.transcriptPath : undefined);
        const permissionMode = p.permissionMode || (same ? prev?.permissionMode : undefined);
        if (transcriptPath)
            entry.transcriptPath = transcriptPath;
        if (permissionMode)
            entry.permissionMode = permissionMode;
        this.entries.set(p.surfaceId, entry);
    }
    /** The surface's shell reported its state (prompt hook / Enter handler). */
    noteShellState(surfaceId, state) {
        if (this.frozen)
            return;
        const e = this.entries.get(surfaceId);
        if (!e)
            return;
        if (state === 'running') {
            e.launching = false;
            return;
        }
        if (e.launching)
            return; // the prompt the resume command was typed at
        if (state === 'idle' || state === 'interrupted')
            this.entries.delete(surfaceId);
    }
    /** A resume was typed into this surface: hold the session through its launch. */
    arm(surfaceId, s) {
        if (this.frozen)
            return;
        this.entries.set(surfaceId, { ...s, launching: true });
    }
    /** The surface's PTY is gone (tab closed, shell exited). */
    forget(surfaceId) {
        if (this.frozen)
            return;
        this.entries.delete(surfaceId);
    }
    /** Quitting: keep what is known now; later exits and reports change nothing. */
    freeze() { this.frozen = true; }
    get(surfaceId) {
        const e = this.entries.get(surfaceId);
        return e ? strip(e) : undefined;
    }
    snapshot() {
        const out = {};
        for (const [id, e] of this.entries)
            out[id] = strip(e);
        return out;
    }
}
exports.AgentSessionTracker = AgentSessionTracker;
function strip(e) {
    const { launching: _launching, ...rest } = e;
    return rest;
}

/**
 * Agent resume — bring Claude Code conversations back after comux restarts.
 *
 * comux restores the layout, each terminal's scrollback and its cwd, but PTYs die
 * on quit, so a terminal that was running Claude came back as a bare prompt and
 * the conversation was gone unless the user remembered `claude --resume`. This
 * module records WHICH Claude session each terminal holds, so the host can type
 * `claude --resume <id>` into the respawned shell.
 *
 * Where the facts come from:
 *  - The session id rides on every Claude Code hook (`session_id` in the stdin
 *    JSON; comux-hook.js forwards it as `sessionId`). The latest one wins, which
 *    also follows `/clear` and `/resume` inside Claude once the next hook fires.
 *  - The session is OVER when the shell reports it owns the terminal again
 *    (`idle`/`interrupted` from the prompt hook). The shell cannot draw a prompt
 *    while Claude holds the console, so that report is the exit.
 *
 * Two rules that are easy to break:
 *  - `freeze()` before the host kills its PTYs on quit. Every kill fires an exit
 *    that would `forget()` the surface, and the quit-time save lands AFTER the
 *    kill — without the freeze the one save that matters would hold nothing.
 *  - `arm()` marks a resumed entry `launching`: the respawned shell's FIRST
 *    prompt reports `idle` too, possibly after the command was typed, and that
 *    must not read as "Claude exited". The `running` report for the typed
 *    command (PSReadLine's Enter handler) ends the launch window.
 *
 * Pure and electron-free; the GUI host wires it in src/main/agent-resume.ts.
 */
export interface ResumableSession {
    agent: 'claude';
    sessionId: string;
    /** Claude's transcript (`~/.claude/projects/<slug>/<id>.jsonl`). A session that
     *  never got a message has none, and there is nothing to resume. */
    transcriptPath?: string;
    /** Claude's permission mode when last seen, so the resume keeps it. */
    permissionMode?: string;
}
export declare function isValidSessionId(id: unknown): id is string;
/**
 * The command line that reopens a session. The same text works in PowerShell,
 * cmd and POSIX shells: it holds no quotes and the id is validated above.
 */
export declare function buildResumeCommand(s: ResumableSession): string | null;
/** Validate a `surfaceAgents` map read back from disk; drops anything malformed. */
export declare function sanitizeSessions(raw: unknown): Record<string, ResumableSession>;
/** Every surface id in a (serialized) split tree. */
export declare function collectSurfaceIds(node: unknown, into?: Set<string>): Set<string>;
export interface HookSessionParams {
    surfaceId?: string;
    sessionId?: string;
    transcriptPath?: string;
    permissionMode?: string;
}
export declare class AgentSessionTracker {
    private entries;
    private frozen;
    /** A Claude Code hook arrived from this surface. */
    noteHook(p: HookSessionParams): void;
    /** The surface's shell reported its state (prompt hook / Enter handler). */
    noteShellState(surfaceId: string, state: string): void;
    /** A resume was typed into this surface: hold the session through its launch. */
    arm(surfaceId: string, s: ResumableSession): void;
    /** The surface's PTY is gone (tab closed, shell exited). */
    forget(surfaceId: string): void;
    /** Quitting: keep what is known now; later exits and reports change nothing. */
    freeze(): void;
    get(surfaceId: string): ResumableSession | undefined;
    snapshot(): Record<string, ResumableSession>;
}
